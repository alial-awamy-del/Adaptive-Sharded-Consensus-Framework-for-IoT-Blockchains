#!/usr/bin/env python3
"""Verify SHA256 of tracked Python and notebook artifacts against release manifest."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'SOURCE_MANIFEST.json').read_text())
failed=[]
for rel,expected in manifest.items():
 p=root/rel
 observed=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else 'MISSING'
 if observed!=expected: failed.append(rel)
print(f'Checked {len(manifest)} source artifacts; mismatches: {len(failed)}')
for item in failed: print('FAIL',item)
raise SystemExit(1 if failed else 0)
