#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent, capacity-constrained inter-shard *aggregate* simulation.

NOT a packet-level / transaction-level DES, nor an implementation of an actual
2-phase-commit consensus protocol. Counts and completions are epoch-aggregated
approximations. All service, contention, and communication parameters are
scenario assumptions and must be disclosed when interpreting the results.

Design: shard count [2,4,8,16,32,64] x cross-shard ratio [5,10,15,25,35%]
        x 10 independent scenario seeds by default. 30 seconds, 80,000 offered TPS.

Outputs: per_run.csv, summary_by_configuration.csv, table18_by_shard.csv,
         statistical_tests.csv, config.json, README.txt.
"""
import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

SHARD_COUNTS = (2, 4, 8, 16, 32, 64)
CROSS_RATIOS = (0.05, 0.10, 0.15, 0.25, 0.35)
DEVICE_COUNTS = {"sensor": 600, "gateway": 250, "edge": 100, "cloud": 50}
# Assumed *effective processing capacities* (work-units/s), not empirical specs.
VALIDATOR_CAPACITY = {"gateway": 120.0, "edge": 350.0, "cloud": 650.0}
CONFIG = {
    "scenario": "independent aggregate fluid/bulk-service inter-shard model",
    "node_population": DEVICE_COUNTS,
    "sensor_role": "transaction generation only, never a validator",
    "effective_capacity_work_units_per_s_by_validator_class": VALIDATOR_CAPACITY,
    "cross_source_work_units": 1.15,
    "cross_target_work_units": 1.00,
    "retry_work_units_per_conflict": 0.65,
    "lock_slots_per_node_per_epoch": 16,
    "base_local_confirmation_ms": 2.0,
    "base_network_ms": 5.0,
    "network_delay_per_log2_shards_ms": 0.22,
    "commit_coordination_ms": 2.0,
    "message_count_per_cross_transaction": 4,
    "protocol_header_kb_per_message": 0.25,
    "validator_metadata_kb_per_validator_per_cross_tx": 0.08,
    "model_warning": "Epoch-level fluid capacity model, not a transaction-level atomic 2PC or full consensus model. Outcomes are conditional on explicitly assumed costs.",
}


def _balanced_node_counts(num_shards, rng):
    """Random node-to-shard assignments, conserving each device population exactly."""
    counts = {}
    for kind, total in DEVICE_COUNTS.items():
        # Separate multinomial class assignment (heterogeneity is real in the model).
        counts[kind] = rng.multinomial(total, np.full(num_shards, 1.0 / num_shards))
    return counts


def _run_one(shards, ratio, seed, duration, epoch_s, offered_tps):
    rng = np.random.default_rng(seed)
    n_epochs = int(round(duration / epoch_s))
    if not np.isclose(n_epochs * epoch_s, duration):
        raise ValueError("duration must be a multiple of epoch")
    node_counts = _balanced_node_counts(shards, rng)
    validator_counts = sum((node_counts[k] for k in VALIDATOR_CAPACITY), start=np.zeros(shards, dtype=int))
    total_nodes = sum(node_counts.values(), start=np.zeros(shards, dtype=int))
    cap_per_s = sum((node_counts[k] * VALIDATOR_CAPACITY[k] for k in VALIDATOR_CAPACITY), start=np.zeros(shards))
    # Remote orchestration and more committees add modeled per-shard overhead.
    # Explicit assumption; not an empirically calibrated consensus cost.
    coordination_factor = 1.0 / (1.0 + 0.012 * np.log2(shards))
    cap_epoch = cap_per_s * epoch_s * coordination_factor
    # No phantom processing on shards with no validators.
    backlog_work = np.zeros(shards, dtype=float)
    total_arrivals = 0
    total_completed_est = 0.0
    total_cross = 0
    total_conflicts = 0
    sync_kb = 0.0
    total_coord_delay_weighted = 0.0
    total_local_latency_weighted = 0.0
    total_cross_latency_weighted = 0.0
    total_local = 0
    peak_pending_est = 0.0
    peak_shard_rho = 0.0
    overloaded_epochs = 0
    peak_backlog_work = 0.0
    # Per-cell randomized message payload 0.5--2 KB (measured via sampled means).
    for _ in range(n_epochs):
        arrivals = int(rng.poisson(offered_tps * epoch_s))
        total_arrivals += arrivals
        sources = rng.multinomial(arrivals, np.full(shards, 1.0 / shards))
        cross_source = rng.binomial(sources, ratio)
        local = sources - cross_source
        cross_count = int(cross_source.sum())
        total_cross += cross_count
        total_local += int(local.sum())

        # Uniform-destination *marginal approximation*, with source excluded.
        # Target allocation is stochastic at the shard-count level, not an
        # explicit pair-level transaction trace.
        if cross_count:
            weights = (cross_count - cross_source).astype(float) / max(1, shards - 1)
            weights /= weights.sum()
            cross_target = rng.multinomial(cross_count, weights)
        else:
            cross_target = np.zeros(shards, dtype=int)

        # Contentions arise from overlapping cross-shard locks. The collision
        # probability depends on target load and available lock slots, not a
        # hardcoded linear multiple of the cross-shard ratio.
        lock_slots = np.maximum(1, total_nodes * CONFIG["lock_slots_per_node_per_epoch"])
        collision_prob = -np.expm1(-np.maximum(0, cross_target - 1) / lock_slots)
        conflicts = rng.binomial(cross_target, collision_prob)
        conflict_count = int(conflicts.sum())
        total_conflicts += conflict_count
        # Approximate equal source / target retry charge.
        retry_source = cross_source * (conflict_count / max(1, cross_count))
        work_new = (local + CONFIG["cross_source_work_units"] * cross_source
                    + CONFIG["cross_target_work_units"] * cross_target
                    + CONFIG["retry_work_units_per_conflict"] * (conflicts + retry_source))
        available = backlog_work + work_new
        served = np.minimum(available, cap_epoch)
        fraction_served = np.divide(served, available, out=np.ones_like(served), where=available > 0)
        backlog_work = np.maximum(0.0, available - served)
        peak_backlog_work = max(peak_backlog_work, float(backlog_work.sum()))
        utilization = np.divide(work_new, cap_epoch, out=np.full(shards, np.inf), where=cap_epoch > 0)
        peak_shard_rho = max(peak_shard_rho, float(np.max(utilization)))
        overloaded_epochs += int(np.any(utilization >= 1.0))

        # Fluid processor-sharing completion approximation. The joint success
        # of cross transactions is approximated by source/target service shares,
        # NOT simulated atomic 2PC completion. Do not call it observed TPS.
        local_completed = float(np.sum(local * fraction_served))
        if cross_count:
            dest_success = float(np.dot(cross_target, fraction_served) / cross_count)
            cross_completed = float(np.sum(cross_source * fraction_served) * dest_success)
        else:
            cross_completed = 0.0
        total_completed_est += local_completed + cross_completed
        peak_pending_est = max(peak_pending_est, total_arrivals - total_completed_est)

        # Mean shard delay proxy from previous and current backlog, bounded only
        # by supplied finite workloads; it is not measured transaction latency.
        wait_ms = np.divide(backlog_work, cap_per_s, out=np.full(shards, duration), where=cap_per_s > 0) * 1000.0
        wait_ms = np.minimum(wait_ms, duration * 1000.0)
        local_latency = CONFIG["base_local_confirmation_ms"] + wait_ms
        extra_network = (CONFIG["base_network_ms"]
                         + CONFIG["network_delay_per_log2_shards_ms"] * np.log2(shards))
        cross_latency = (local_latency + extra_network
                         + CONFIG["commit_coordination_ms"]
                         + float(np.dot(cross_target, wait_ms) / max(1, cross_count))
                         + (conflict_count / max(1, cross_count)) * 12.5)
        total_local_latency_weighted += float(np.dot(local, local_latency))
        total_cross_latency_weighted += float(np.dot(cross_source, cross_latency))
        total_coord_delay_weighted += cross_count * (extra_network + CONFIG["commit_coordination_ms"])
        if cross_count:
            mean_payload_kb = float(rng.uniform(0.5, 2.0))
            mean_validators = float(np.dot(cross_target, validator_counts) / cross_count)
            per_message_kb = mean_payload_kb + CONFIG["protocol_header_kb_per_message"]
            kb = cross_count * (CONFIG["message_count_per_cross_transaction"] * per_message_kb
                              + mean_validators * CONFIG["validator_metadata_kb_per_validator_per_cross_tx"])
            kb += conflict_count * 2 * per_message_kb
            sync_kb += kb

    goodput = total_completed_est / duration
    return {
        "seed": int(seed), "shards": int(shards), "cross_ratio_target": ratio,
        "cross_ratio_actual": total_cross / max(1, total_arrivals),
        "duration_s": duration, "epochs": n_epochs,
        "offered_tps_configured": offered_tps,
        "generated_tx": int(total_arrivals), "cross_tx": int(total_cross),
        "goodput_est_tps": goodput,
        "completion_fraction_est": total_completed_est / max(1, total_arrivals),
        "pending_tx_est": max(0.0, total_arrivals - total_completed_est),
        "peak_pending_tx_est": peak_pending_est,
        "cross_shard_delay_proxy_ms": total_cross_latency_weighted / max(1, total_cross),
        "local_delay_proxy_ms": total_local_latency_weighted / max(1, total_local),
        "coordination_delay_assumption_ms": total_coord_delay_weighted / max(1, total_cross),
        "sync_overhead_mb": sync_kb / 1024.0,
        "conflict_pct_of_cross_tx": 100.0 * total_conflicts / max(1, total_cross),
        "total_conflicts": int(total_conflicts),
        "overloaded_epoch_fraction": overloaded_epochs / n_epochs,
        "peak_shard_arrival_load_ratio": peak_shard_rho,
        "peak_queued_work_units": peak_backlog_work,
        "min_shard_validators": int(validator_counts.min()),
        "max_shard_validators": int(validator_counts.max()),
        "total_validator_nodes": int(validator_counts.sum()),
    }


def _holm(pvals):
    p = np.asarray(pvals, dtype=float)
    order = np.argsort(p)
    adj = np.zeros(len(p))
    largest = 0.0
    for rank, idx in enumerate(order):
        largest = max(largest, float(p[idx]) * (len(p) - rank))
        adj[idx] = min(1.0, largest)
    return adj


def summarize(df):
    metrics = ["goodput_est_tps", "completion_fraction_est", "pending_tx_est",
               "cross_shard_delay_proxy_ms", "sync_overhead_mb", "conflict_pct_of_cross_tx",
               "overloaded_epoch_fraction", "peak_shard_arrival_load_ratio"]
    rows = []
    for (s, r), sub in df.groupby(["shards", "cross_ratio_target"], sort=True):
        row = {"shards": int(s), "cross_ratio_pct": float(r * 100), "n_runs": len(sub)}
        for metric in metrics:
            row[metric + "_mean"] = float(sub[metric].mean())
            row[metric + "_sd"] = float(sub[metric].std(ddof=1))
        rows.append(row)
    return pd.DataFrame(rows), metrics


def statistics(df, metrics):
    # Explicit two-factor design: independent runs within each cell.
    # Input ratio is a manipulated factor; effects are CONDITIONAL on cost model.
    all_rows = []
    for metric in metrics:
        working = df.copy()
        working["shard_factor"] = working["shards"].astype(str)
        working["ratio_factor"] = (working["cross_ratio_target"] * 100).round(2).astype(str)
        try:
            fit = ols(f"{metric} ~ C(shard_factor) * C(ratio_factor)", data=working).fit()
            table = anova_lm(fit, typ=2)
            for term, item in [("shard_count", "C(shard_factor)"),
                               ("cross_ratio", "C(ratio_factor)"),
                               ("interaction", "C(shard_factor):C(ratio_factor)")]:
                all_rows.append({"metric": metric, "test": "two_factor_ANOVA_type_II",
                                 "contrast": term, "statistic": float(table.loc[item, "F"]),
                                 "p": float(table.loc[item, "PR(>F)"]), "p_holm": np.nan})
        except Exception as e:
            all_rows.append({"metric": metric, "test": "ANOVA_FAILED",
                             "contrast": str(e), "statistic": np.nan, "p": np.nan, "p_holm": np.nan})
        # Independently generated runs: per ratio, contrast shard counts with
        # Kruskal--Wallis; adjusted across 5 ratios within each metric.
        tmp = []
        for r in CROSS_RATIOS:
            groups = [df.loc[(df.shards == s) &
                             (np.isclose(df.cross_ratio_target, r)), metric].values
                      for s in SHARD_COUNTS]
            if all(len(v) > 0 for v in groups):
                stat, p = stats.kruskal(*groups)
                tmp.append((r, stat, p))
        adjusted = _holm([x[2] for x in tmp]) if tmp else []
        for (r, stat, p), adj in zip(tmp, adjusted):
            all_rows.append({"metric": metric, "test": "Kruskal_by_ratio",
                             "contrast": f"shards_at_{r:.2f}_cross_ratio", "statistic": stat,
                             "p": p, "p_holm": float(adj)})
    return pd.DataFrame(all_rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=10)
    parser.add_argument("--duration", type=float, default=30.0)
    parser.add_argument("--epoch", type=float, default=0.05)
    parser.add_argument("--offered-tps", type=float, default=80000.0)
    parser.add_argument("--seed-base", type=int, default=20261108)
    parser.add_argument("--out", type=Path, default=Path("inter_shard_v2_results"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    for s in SHARD_COUNTS:
        for r in CROSS_RATIOS:
            for run in range(args.runs):
                seed = args.seed_base + 100000 * SHARD_COUNTS.index(s) + 1000 * CROSS_RATIOS.index(r) + run
                row = _run_one(s, r, seed, args.duration, args.epoch, args.offered_tps)
                row["run"] = run + 1
                rows.append(row)
            print(f"Completed {s:2d} shards, {r*100:2.0f}% cross-shard: {args.runs} runs", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(args.out / "per_run.csv", index=False)
    summary, metrics = summarize(df)
    summary.to_csv(args.out / "summary_by_configuration.csv", index=False)
    summary.to_csv(args.out / "table18_by_shard.csv", index=False)
    stats_df = statistics(df, metrics) if args.runs >= 3 else pd.DataFrame()
    stats_df.to_csv(args.out / "statistical_tests.csv", index=False)
    metadata = {"parameters": CONFIG, "design": {
        "shard_counts": SHARD_COUNTS, "cross_ratios": CROSS_RATIOS,
        "runs_per_cell": args.runs, "duration_s": args.duration,
        "epoch_s": args.epoch, "offered_tps": args.offered_tps,
        "seed_base": args.seed_base, "statistical_caveat":
        "Factorial ANOVA on independent seeded model runs. Run residual/variance diagnostics before inferential manuscript claims. Configured costs create expected dependencies; p-values do not establish empirical protocol scalability."}}
    (args.out / "config.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    (args.out / "README.txt").write_text(
        "INTER-SHARD V2: independent aggregate capacity-constrained MODEL.\n"
        "Replaces circular score S=1-min(0.5,1.5*r) with estimated completion fraction.\n"
        "All results are conditional on assumed device capacities, coordination costs,\n"
        "finite lock contention, and fluid processor-sharing approximation.\n"
        "No real transactions are individually committed; cross-shard atomicity\n"
        "is approximated. Metrics ending _est or _proxy are approximations.\n"
        "Do not treat old Table 18 numbers as directly comparable to this new model.\n"
        "Report shard count and cross ratio separately. No equivalence to Section 5.1.\n", encoding="utf-8")
    print("Saved:", args.out.resolve())
    print(summary[["shards", "cross_ratio_pct", "completion_fraction_est_mean", "goodput_est_tps_mean"]].to_string(index=False))


if __name__ == "__main__":
    main()
