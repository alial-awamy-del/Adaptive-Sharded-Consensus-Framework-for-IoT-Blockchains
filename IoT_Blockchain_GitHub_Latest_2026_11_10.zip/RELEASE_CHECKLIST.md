# Release checklist / قائمة التحقق قبل النشر

- [ ] Re-run each script with declared seeds and runtime environment.
- [ ] Check generated logs for `accounting_gap != 0`; investigate and rerun after verified correction.
- [ ] Reconcile integrated baseline (Section 5.1) and node-scalability tables from the **same** experiment configuration.
- [ ] Confirm source code, offered workload, measured arrivals and attack inclusion for Tables 10 and 14.
- [ ] Identify `μ`, aggregate per-shard capacities, system-wide validator counts and raw `ρ` in Table 4 and equations.
- [ ] Reconcile energy metrics by device population, activity state and time base; disclose 100 μWh/tx target difference.
- [ ] Verify EWMA indicator, α, threshold, sampling level and ground-truth semantics; do not mislabel epoch detection.
- [ ] Document attack attempt counts and mean ± SD for each **implemented** attack; do not invent unsupported attacks.
- [ ] Verify 2.8M and 15M City simulation tables using raw ten-seed run outputs.
- [ ] Correct any inconsistency between published claims and executed model.
- [ ] Attach raw results, configs, requirements lockfile and code hash to a versioned release if permitted.
- [ ] Select a license (if reuse is intended), check rights to all files and remove sensitive data.
- [ ] Create release tag, obtain archival DOI, and only then revise the data/code availability statement.
