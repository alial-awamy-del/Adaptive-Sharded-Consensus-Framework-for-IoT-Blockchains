# Latest source guide (2026-11-10)

This repository collects **research simulation code**, not verified physical blockchain implementations. The versions selected below are the latest available source variants in this conversation's uploaded files. Timestamps of copied files do not establish source-code chronology.

| Research area | Preferred code to inspect | Other retained code |
| --- | --- | --- |
| Integrated 80K TPS baseline and load scaling | `experiments/integrated/integrated_engine_user_supplied.py` (verbatim `الكوددد.txt`) | `integrated_engine_original.py`, `run_reviewer_audit_v3.py`, `run_node_scaling_capacity_audit.py` |
| Validator weight sensitivity | `experiments/validator_sensitivity/validator_weight_sensitivity_v3_deadline_fixed.py` | `validator_weight_sensitivity_v3.py` |
| Markov trust experiment | `experiments/markov/Markov_Section_522_Final_Audit.py` | original and Option B scripts |
| Queue scheduling | `experiments/queue_scheduling/queue_scheduling_v3.py` | — |
| Consensus energy | `experiments/energy/consensus_energy_v3.py` | notebook and accounting script |
| Cross-shard communication | `experiments/inter_shard/inter_shard_v4_sensitivity.py` (later sensitivity analysis) and `inter_shard_v4_CORRECTED.py` (core V4) | earlier V2/V3 in `legacy/` |
| Smart City 2.8M/15M | `experiments/smart_city/smart_city_both_scenarios_uploaded.py` (uploaded version) | copied `smart_city_both_scenarios.py` and historical reconstruction/audit |
| Separate consensus comparison | `experiments/consensus_comparison/consensus_comparison_colab.py` | notebook |

## Critical reproducibility qualifications

- These sources have been **syntax-checked**, not verified by a complete 10-seed run for each configuration in this package-building step.
- Manuscript Table 18 sensitivity/model assumptions and smart-city historical numerical discrepancies are under editorial review; do **not** claim complete numerical replication.
- Section 5.1 80K baseline and Section 5.3.1 1000-node row refer to the same 10 runs. Other datasets and standalone scripts should not be combined without verifying experiment boundaries.
- The main integrated engine uses nominal throughput capacity separate from synthetic per-transaction latency; its capacity multiplier 1.35 is not a hardware-measured microbatch multiplier.
- Smart-city 15M is a **reconstruction** from described settings; original historic 15M source not confirmed.
- Some source models use assumed attack success, energy, throughput and queue relationships. They are simulation assumptions, not measured protocol security or deployment performance.
- Avoid posting manuscript source or personal information. No license is included; add a license only after choosing reuse permissions.
- For publication, separately archive executable environment, exact seed list, configurations and raw output CSVs, and obtain a repository DOI (e.g., Zenodo) before citing a DOI.

## Quick syntax check

```bash
python -m compileall -q experiments
```

## GitHub upload

Unzip this bundle, open the **folder contents** as repository root, review the release checklist, then commit and push. Scripts are the primary artifacts; do not claim their output is verified until all audits are closed.
