# -*- coding: utf-8 -*-
"""V3: audited priority multi-server event simulation and energy surrogate for Colab.

This code is NOT an implementation of PoA, Raft, PBFT, DPoS-PBFT or PoV-DRoP.
Protocol message and verification workloads are specified assumptions, not validated
packet traces. The output must be identified as simulated estimates, not measurements.

Accounting uses mutually exclusive activity durations and no additive message-Joule
charge on top of radio duty; this avoids the prior prototype's double-count risk.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from numba import njit

CLASSES=("sensor","gateway","edge","cloud")
PRIORITIES=("CRITICAL","HIGH","MEDIUM","LOW")
PROTOCOLS=("Proposed_Hybrid","DPoS_PBFT_Hybrid","PoA","Raft","PBFT_lite")
ABLATION="Proposed_Fixed_Committee"
# Exactly the original manuscript's modeled class power states (W) and factors.
POWER_W=np.array([[.0005,.05,.15],[2.5,4.5,6.0],[1.,8.,4.],[20.,60.,20.]],float) # sleep,compute,radio
CORRECTION=np.array([.12,.85,1.6,3.2],float)
NOMINAL_CAPACITY=np.array([10.,100.,500.,2000.]) # tx/s per validator
EDGE_BONUS=np.array([0.,1.35,1.75,.40])
SOURCE_WEIGHTS=np.array([.60,.25,.10,.05])
TRAFFIC_WEIGHTS=np.array([.10,.20,.30,.40])
DEADLINES=np.array([.1,.2,.5,1.0])
APP_COMPUTE=np.array([.02,.04,.04,.04])
APP_RADIO=np.array([.01,.02,.02,.02])

@dataclass(frozen=True)
class Config:
    num_nodes:int=1000
    num_shards:int=10
    epoch_s:float=.05
    seconds:float=30.
    offered_tps:float=80000.
    runs:int=10
    seed:int=20261107
    deployment_mode:str="edge_dominant"
    attack_start:int=120
    attack_end:int=220
    pre_start:int=100
    pre_end:int=119
    mu_scale:float=1.35
    batch_tx:int=250
    control_bytes:int=512
    link_bytes_per_s:float=25e6
    verification_time_s:float=.000035 # assumed per verification, not measured
    election_time_s:float=.000025     # assumed per committee vote, not measured
    radio_amplification:float=1.0     # controls double-ended airtime estimate
    overhead_factor:float=2.
    network_factor:float=1.3
    security_factor:float=1.0
    energy_target_wh_per_tx:float=.0001
    committee_min:int=12
    committee_max:int=24
    committee_initial:int=16
    capacity_up_rho:float=.82
    capacity_down_rho:float=.30
    capacity_target_rho:float=.55
    save_epoch:bool=True
    include_ablation:bool=True
    validate_queue_reference:bool=True

    @property
    def epochs(self): return round(self.seconds/self.epoch_s)


def check_config(c:Config):
    assert c.num_nodes>=10*c.num_shards and c.runs>=1
    assert c.num_shards>0 and c.offered_tps>0 and c.seconds>0
    assert math.isclose(c.epochs*c.epoch_s,c.seconds,abs_tol=1e-9)
    assert c.pre_end<c.attack_start<=c.attack_end<=c.epochs
    assert c.committee_min<=c.committee_initial<=c.committee_max
    assert c.network_factor>=1 and c.overhead_factor>0 and c.security_factor>0
    assert c.deployment_mode=='edge_dominant' or c.deployment_mode=='cloud_assisted'
    assert c.link_bytes_per_s>0 and c.batch_tx>=1
    assert c.verification_time_s>0 and c.election_time_s>=0


def make_scenario(c:Config,rep:int):
    """Common random numbers: same hardware, shards, arrivals and attacks per replicate."""
    rng=np.random.default_rng(c.seed+rep*100003)
    dev=rng.choice(4,c.num_nodes,p=SOURCE_WEIGHTS)
    shard=np.arange(c.num_nodes)%c.num_shards
    rng.shuffle(shard)
    members=[np.flatnonzero(shard==s) for s in range(c.num_shards)]
    trust=rng.uniform(.5,1.,c.num_nodes)
    t=np.arange(1,c.epochs+1)
    attack=(t>=c.attack_start)&(t<=c.attack_end)
    total=rng.poisson(c.offered_tps*c.epoch_s,c.epochs)
    arrival_mult=np.where(attack,rng.uniform(1.1,1.25,c.epochs),1.)
    service_mult=np.where(attack,rng.uniform(.86,.98,c.epochs),1.)
    net_mult=np.where(attack,rng.uniform(1.05,1.20,c.epochs),1.)
    power_mult=np.where(attack,rng.uniform(1.02,1.12,c.epochs),1.)
    arrivals=np.zeros((c.epochs,c.num_shards,4),np.int64)
    for e in range(c.epochs):
        by_shard=rng.multinomial(int(round(total[e]*arrival_mult[e])),np.full(c.num_shards,1/c.num_shards))
        for s in range(c.num_shards):
            arrivals[e,s]=rng.multinomial(by_shard[s],TRAFFIC_WEIGHTS)
    return dict(dev=dev,shard=shard,members=members,trust=trust,attack=attack,
                arrivals=arrivals,service_mult=service_mult,net_mult=net_mult,
                power_mult=power_mult,scenario_seed=c.seed+rep*100003)


def select_committee(sc,s,desired,protocol,c):
    """Committee ranking proxy: common caps for every protocol, sensors never eligible."""
    dev=sc['dev']; nodes=sc['members'][s]; eligible=nodes[dev[nodes]!=0]
    if len(eligible)==0:return np.empty(0,np.int64)
    bonuses=EDGE_BONUS if c.deployment_mode=='edge_dominant' else np.array([0.,1.,1.,1.])
    scores=NOMINAL_CAPACITY[dev[eligible]]*bonuses[dev[eligible]]
    if protocol in (PROTOCOLS[0],ABLATION):scores=scores*(.5+sc['trust'][eligible])
    elif protocol==PROTOCOLS[1]:scores=scores*(.75+.5*sc['trust'][eligible])
    order=eligible[np.argsort(-scores,kind='stable')]
    # same soft distribution constraints for all arms
    caps={1:math.ceil(.34*desired),2:math.ceil(.48*desired),3:math.ceil(.24*desired)}
    chosen=[]; count={1:0,2:0,3:0}
    for i in order:
        d=int(dev[i])
        if count[d]<caps[d] and len(chosen)<desired:
            chosen.append(int(i));count[d]+=1
    for i in order:
        if len(chosen)>=min(desired,len(eligible)):break
        if int(i) not in chosen:chosen.append(int(i))
    return np.array(chosen,dtype=np.int64)


def communication_operations(protocol,k,blocks,completed):
    """Illustrative (messages, election votes, verifications); NOT network traces.

    Every arm uses identical batch definition; consensus-type-specific message
    patterns differ. Detailed protocol mechanisms are not implemented.
    """
    if k<=0:return 0,0,0
    b=blocks
    if protocol in (PROTOCOLS[0],ABLATION):
        return b*3*(k-1),k,completed*math.ceil(2*k/3)
    if protocol==PROTOCOLS[1]:
        return b*(2*k*(k-1)+2*(k-1)),k,completed*math.ceil(2*k/3)
    if protocol==PROTOCOLS[2]:return b*2*(k-1),0,completed
    if protocol==PROTOCOLS[3]:return b*2*(k-1)+(k-1),0,2*completed
    if protocol==PROTOCOLS[4]:return b*(2*k*(k-1)+3*(k-1)),0,k*completed
    raise KeyError(protocol)


def phase(epoch,c):
    if c.pre_start<=epoch<=c.pre_end:return 'PRE'
    if c.attack_start<=epoch<=c.attack_end:return 'DURING'
    if epoch>c.attack_end:return 'POST'
    return 'OTHER'


def energy_ledger(sc,c,committees,shard_processed,shard_msgs,shard_votes,shard_verifications,attack_power,attack_net):
    """Per-node disjoint states. Etotal=sum_i sum_state P_eff[i,state]*tau[i,state]/3600.

    Background: sleep baseline + non-consensus APP increments above sleep;
    Consensus-attributable: increased compute/radio time caused by consensus
    versus sleep counterfactual. No extra J/message or J/verification charge.

    Limitations: homogeneous task time per verification and bandwidth airtime,
    unknown true CPU occupancy, no direct measurement. Other modeled security
    activities enter P_eff via a documented factor, not additional state time.
    """
    dev=sc['dev']; n=len(dev)
    committee_ids=np.concatenate([v for v in committees if len(v)]) if any(len(v) for v in committees) else np.empty(0,np.int64)
    is_validator=np.zeros(n,dtype=bool);is_validator[committee_ids]=True
    comp_app=APP_COMPUTE[dev]*c.epoch_s
    rad_app=APP_RADIO[dev]*c.epoch_s
    comp_con=np.zeros(n);rad_con=np.zeros(n)
    for s,ids in enumerate(committees):
        k=len(ids)
        if not k:continue
        # Operations are pooled across committee members; fractional balanced CPU time.
        compute_work=(shard_verifications[s]*c.verification_time_s+
                      shard_votes[s]*c.election_time_s)
        radio_work=(shard_msgs[s]*c.control_bytes*c.radio_amplification /
                    c.link_bytes_per_s)*attack_net
        comp_con[ids]+=compute_work/k
        rad_con[ids]+=radio_work/k
    # Queue/app fractions held fixed, actual validator work added on top.
    # Bounded epoch time: unexecuted control work incurs a modeled backlog penalty,
    # and is NOT charged as energy consumed in this epoch.
    spare=np.maximum(0.,c.epoch_s-comp_app-rad_app)
    want=comp_con+rad_con
    scale=np.ones(n)
    np.divide(spare,want,out=scale,where=want>0)
    scale=np.minimum(scale,1.)
    unserved_work_s=float(np.sum(want*(1.-scale)))
    comp_con*=scale;rad_con*=scale
    t_compute=comp_app+comp_con
    t_radio=rad_app+rad_con
    t_sleep=c.epoch_s-t_compute-t_radio
    assert np.all(t_sleep>=-1e-9)
    assert np.allclose(t_sleep+t_compute+t_radio,c.epoch_s,atol=1e-10)
    # Power factors apply to active processing/communication only; no attack
    # multiplier on sleep. Security factor is explicit, default 1.0.
    p=POWER_W[dev]*CORRECTION[dev,None]*c.overhead_factor
    p_sleep=p[:,0]
    p_comp=p[:,1]*c.network_factor*c.security_factor*attack_power
    p_radio=p[:,2]*c.network_factor*c.security_factor*attack_power
    energy_sleep=float(np.sum(p_sleep*t_sleep)/3600.)
    energy_comp=float(np.sum(p_comp*t_compute)/3600.)
    energy_radio=float(np.sum(p_radio*t_radio)/3600.)
    energy_sys=energy_sleep+energy_comp+energy_radio
    # Additive *attribution* (not second debit): the energy above sleep due to
    # consensus activities; background absorbs all remaining modeled energy.
    energy_cons=float(np.sum((p_comp-p_sleep)*comp_con+(p_radio-p_sleep)*rad_con)/3600.)
    energy_background=energy_sys-energy_cons
    assert energy_cons>=-1e-10 and energy_background>=-1e-10
    by_class={}
    for d,name in enumerate(CLASSES):
        mask=dev==d
        by_class[name]=float(np.sum((p_sleep*t_sleep+p_comp*t_compute+p_radio*t_radio)[mask])/3600.)
    return dict(total=energy_sys,consensus=energy_cons,background=energy_background,
                sleep=energy_sleep,compute=energy_comp,radio=energy_radio,
                active_validators=int(is_validator.sum()),unserved_control_work_s=unserved_work_s,
                **{f'device_{d}':v for d,v in by_class.items()})



# -----------------------------------------------------------------------------
# V3: priority scheduling is implemented by arrival/completion EVENTS, not a
# priority multiplier applied to Erlang-C. One job per validator, no preemption.
# Conditional Poisson arrival times are uniform within each epoch; service
# demand is Exp(1) per transaction, scaled by the heterogeneous server's rate.
# Additional protocol overhead makes the actual surrogate M/G/c-like, not exact
# homogeneous M/M/c; we report Erlang-C only for an isolated reference case.
# -----------------------------------------------------------------------------
@njit(cache=True)
def advance_des(t_arr, priority, service_exp, ptr, next_link,
                heads, tails, finish, server_job, started_at,
                n_active, rates, extra_service, stop, deadlines):
    """Advance one shard to time stop with four non-preemptive strict priorities.

    Numba only accelerates the exact transaction-event loop; it does not change
    queue discipline. Each transaction is an individual job, never a weight batch.
    """
    arrived=0; done=0; latency=0.; waiting=0.; misses=0
    critical_sum=0.;critical_n=0
    by_priority=np.zeros(4,np.int64)
    class_latency=np.zeros(4,np.float64)
    class_wait=np.zeros(4,np.float64)
    class_starts=np.zeros(4,np.int64)
    n=len(t_arr); ns=len(finish)
    while True:
        at=t_arr[ptr] if ptr<n and t_arr[ptr]<stop-1e-12 else np.inf
        ft=np.inf; fserver=-1
        for j in range(ns):
            if server_job[j]>=0 and finish[j]<ft:
                ft=finish[j];fserver=j
        if at==np.inf and (ft==np.inf or ft>=stop-1e-12):
            break
        if at<=ft:
            idx=ptr;ptr+=1;arrived+=1
            p=priority[idx]
            if heads[p]<0:
                heads[p]=idx
            else:
                next_link[tails[p]]=idx
            tails[p]=idx
            now=at
            idle=-1
            for j in range(n_active):
                if server_job[j]<0:
                    idle=j;break
            if idle<0:
                continue
            # dispatch highest-priority waiting job onto a newly free server
            qp=-1
            for q in range(4):
                if heads[q]>=0:
                    qp=q;break
            if qp>=0:
                job=heads[qp];heads[qp]=next_link[job]
                if heads[qp]<0:tails[qp]=-1
                next_link[job]=-1
                server_job[idle]=job;started_at[idle]=now
                waiting+=now-t_arr[job]
                class_wait[qp]+=now-t_arr[job];class_starts[qp]+=1
                finish[idle]=now+service_exp[job]/max(rates[idle],1e-12)+extra_service
        else:
            now=ft;job=server_job[fserver];p=priority[job]
            server_job[fserver]=-1;finish[fserver]=np.inf
            done+=1;by_priority[p]+=1
            latency+=now-t_arr[job]
            class_latency[p]+=now-t_arr[job]
            if now-t_arr[job]>deadlines[p]:misses+=1
            if p==0:
                critical_sum+=now-t_arr[job];critical_n+=1
            # a retiring server finishes its current job but gets no new one
            if fserver<n_active:
                qp=-1
                for q in range(4):
                    if heads[q]>=0:
                        qp=q;break
                if qp>=0:
                    nxt=heads[qp];heads[qp]=next_link[nxt]
                    if heads[qp]<0:tails[qp]=-1
                    next_link[nxt]=-1
                    server_job[fserver]=nxt;started_at[fserver]=now
                    waiting+=now-t_arr[nxt]
                    class_wait[qp]+=now-t_arr[nxt];class_starts[qp]+=1
                    finish[fserver]=now+service_exp[nxt]/max(rates[fserver],1e-12)+extra_service
    # activate newly available idle capacity at epoch boundary too: this is
    # invoked *after* changing n_active, so queued work could remain at stop.
    return ptr,arrived,done,latency,waiting,misses,critical_sum,critical_n,by_priority,class_latency,class_wait,class_starts


@njit(cache=True)
def dispatch_at_boundary(t_arr,service_exp,next_link,heads,tails,finish,
                         server_job,started_at,n_active,rates,extra_service,now):
    """When pool grows, dispatch queued transactions immediately at the boundary."""
    waiting=0.
    class_wait=np.zeros(4,np.float64)
    class_starts=np.zeros(4,np.int64)
    for j in range(n_active):
        if server_job[j]>=0:continue
        qp=-1
        for q in range(4):
            if heads[q]>=0:
                qp=q;break
        if qp<0:break
        job=heads[qp];heads[qp]=next_link[job]
        if heads[qp]<0:tails[qp]=-1
        next_link[job]=-1
        server_job[j]=job;started_at[j]=now
        waiting+=now-t_arr[job]
        class_wait[qp]+=now-t_arr[job];class_starts[qp]+=1
        finish[j]=now+service_exp[job]/max(rates[j],1e-12)+extra_service
    return waiting,class_wait,class_starts


def erlang_c_reference(lam, mu, c):
    """Exact, stable homogeneous M/M/c reference only where rho < 1."""
    rho=lam/(c*mu)
    if not 0<=rho<1:
        raise ValueError('Erlang-C steady state is undefined for rho >= 1')
    a=lam/mu
    terms=np.array([k*math.log(a)-math.lgamma(k+1) if a>0 else (-np.inf if k>0 else 0.)
                    for k in range(c)],float)
    last=c*math.log(a)-math.lgamma(c+1)-math.log1p(-rho) if a>0 else -np.inf
    m=max(float(np.max(terms)),last)
    prob=math.exp(last-m)/(math.exp(last-m)+float(np.exp(terms-m).sum())) if a>0 else 0.
    return prob/(c*mu-lam)


def make_event_streams(c,sc):
    """Poisson event times: conditional on epoch count, unordered events are
    uniform in that epoch. Sorted arrival sequence shared by all protocols.
    Each transaction also owns a shared Exp(1) service demand across arms.
    """
    rng=np.random.default_rng(sc['scenario_seed']+77117)
    out=[]
    for s in range(c.num_shards):
        time_chunks=[];p_chunks=[];exp_chunks=[]
        for e in range(c.epochs):
            count=sc['arrivals'][e,s]
            n=int(count.sum())
            if n==0:continue
            times=(e+rng.random(n))*c.epoch_s
            p=np.repeat(np.arange(4,dtype=np.int8),count)
            dem=rng.exponential(1.,n)
            order=np.argsort(times,kind='stable')
            time_chunks.append(times[order]);p_chunks.append(p[order]);exp_chunks.append(dem[order])
        if time_chunks:
            t=np.concatenate(time_chunks)
            pr=np.concatenate(p_chunks)
            ex=np.concatenate(exp_chunks)
        else:
            t=np.empty(0,float);pr=np.empty(0,np.int8);ex=np.empty(0,float)
        out.append((t,pr,ex))
    return out


def select_static_committees(sc,c,protocol):
    """Pick a reproducible ordering of up to committee_max eligible validators."""
    return [select_committee(sc,s,c.committee_max,protocol,c) for s in range(c.num_shards)]


def service_overhead(protocol,k,c,attack_net):
    """Explicit modeled extra latency *per transaction*, additive to the Exp
    service time, using CPU and radio control operations amortized by batching.
    No hardware measurements are implied.
    """
    if k<=0:return 0.
    m,v,vr=communication_operations(protocol,k,1,c.batch_tx)
    cpu=(vr*c.verification_time_s+v*c.election_time_s)/max(1,k*c.batch_tx)
    radio=(m*c.control_bytes*c.radio_amplification*attack_net /c.link_bytes_per_s)/max(1,k*c.batch_tx)
    return cpu+radio


def simulate(protocol,c,sc,rep,events=None):
    assert protocol in PROTOCOLS+(ABLATION,)
    if events is None:events=make_event_streams(c,sc)
    # An actual multi-server DES per shard, each node has its own exponential
    # service rate. Class priorities are non-preemptive and FIFO within class.
    ranking=select_static_committees(sc,c,protocol)
    sizes=np.full(c.num_shards,c.committee_initial,np.int64)
    states=[]
    for s in range(c.num_shards):
        t,pr,exp=events[s];k=c.committee_max
        states.append(dict(times=t,priority=pr,demand=exp,ptr=0,
           link=np.full(len(t),-1,np.int64),heads=np.full(4,-1,np.int64),
           tails=np.full(4,-1,np.int64),finish=np.full(k,np.inf),
           jobs=np.full(k,-1,np.int64),started=np.zeros(k,float),
           arrived=0,confirmed=0))
    totals={k:0. for k in ('total','consensus','background','sleep','compute','radio',
                    'device_sensor','device_gateway','device_edge','device_cloud','unserved_control_work_s')}
    msgs=votes=verifs=generated=confirmed=missed=0
    lat_sum=critical_sum=wait_sum=0.;critical_n=0
    total_class_latency=np.zeros(4,float);total_class_wait=np.zeros(4,float)
    total_class_confirmed=np.zeros(4,np.int64);total_class_started=np.zeros(4,np.int64)
    phases={k:dict(energy=0.,consensus=0.,tx=0,seconds=0.,latency_sum=0.) for k in ('PRE','DURING','POST')}
    epochs=[]
    for e in range(c.epochs):
        ep=e+1;now=e*c.epoch_s;stop=(e+1)*c.epoch_s
        incoming=sc['arrivals'][e];generated+=int(incoming.sum())
        shard_processed=np.zeros(c.num_shards,np.int64)
        shard_msgs=np.zeros(c.num_shards,np.int64)
        shard_votes=np.zeros(c.num_shards,np.int64)
        shard_verifs=np.zeros(c.num_shards,np.int64)
        commits=[]; n_served=0;epoch_lat=0.;epoch_miss=0; epoch_wait=0.
        for s in range(c.num_shards):
            state=states[s];committee_all=ranking[s]
            if len(committee_all)<c.committee_min:
                raise RuntimeError(f'Shard {s} has too few eligible non-sensor validator nodes')
            current=int(sizes[s]);active=committee_all[:current]
            base_cap=float(np.sum(NOMINAL_CAPACITY[sc['dev'][active]])*c.mu_scale)
            # capacity reference uses offered arrivals + outstanding work, not
            # a clipped rho or a fabricated finite waiting-time formula.
            pending=int(state['arrived']-state['confirmed'])
            prior_epoch_arrivals=(int(sc['arrivals'][e-1,s].sum()) if e>0 else c.offered_tps*c.epoch_s/c.num_shards)
            rho=(prior_epoch_arrivals+pending)/(max(base_cap,1e-9)*c.epoch_s)
            if protocol==PROTOCOLS[0]:
                if rho>=c.capacity_up_rho:
                    sizes[s]=min(c.committee_max,int(sizes[s])+2)
                elif rho<c.capacity_down_rho and pending==0:
                    sizes[s]=max(c.committee_min,int(sizes[s])-1)
            k=min(int(sizes[s]),len(committee_all));active=committee_all[:k]
            # fixed-comparator arms have the SAME initial committee size;
            # only Proposed uses scaling (framework comparison); ablation
            # holds the proposed selection ranking and committee size fixed.
            rates=NOMINAL_CAPACITY[sc['dev'][active]]*c.mu_scale*float(sc['service_mult'][e])
            extra=service_overhead(protocol,k,c,float(sc['net_mult'][e]))
            state['ptr'],arrived,done,lat,wq,miss,cr_lat,cr_n,byp,clat,cwait,cstarts=advance_des(
                state['times'],state['priority'],state['demand'],state['ptr'],
                state['link'],state['heads'],state['tails'],state['finish'],
                state['jobs'],state['started'],k,rates,extra,stop,DEADLINES)
            # Activate idle validators at the epoch boundary; otherwise a pool
            # enlargement would wait until the next arrival/completion.
            boundary_wait,boundary_class_wait,boundary_class_starts=dispatch_at_boundary(state['times'],state['demand'],state['link'],
                 state['heads'],state['tails'],state['finish'],state['jobs'],
                 state['started'],k,rates,extra,stop)
            wq+=boundary_wait
            total_class_latency+=clat;total_class_wait+=cwait+boundary_class_wait
            total_class_confirmed+=byp;total_class_started+=cstarts+boundary_class_starts
            state['arrived']+=arrived;state['confirmed']+=done
            shard_processed[s]=done;n_served+=done
            epoch_lat+=lat;epoch_wait+=wq;epoch_miss+=miss
            critical_sum+=cr_lat;critical_n+=cr_n
            blocks=math.ceil(done/c.batch_tx) if done else 0
            m,v,vr=communication_operations(protocol,k,blocks,done)
            shard_msgs[s]=m;shard_votes[s]=v;shard_verifs[s]=vr
            commits.append(active)
            # Confirm no completed transaction can exceed total arrivals.
            assert state['confirmed']<=state['arrived']
        en=energy_ledger(sc,c,commits,shard_processed,shard_msgs,
                         shard_votes,shard_verifs,float(sc['power_mult'][e]),float(sc['net_mult'][e]))
        for key in totals:totals[key]+=en[key]
        msgs+=int(shard_msgs.sum());votes+=int(shard_votes.sum());verifs+=int(shard_verifs.sum())
        confirmed+=n_served;lat_sum+=epoch_lat;wait_sum+=epoch_wait;missed+=epoch_miss
        ph=phase(ep,c)
        if ph in phases:
            a=phases[ph];a['energy']+=en['total'];a['consensus']+=en['consensus']
            a['tx']+=n_served;a['seconds']+=c.epoch_s;a['latency_sum']+=epoch_lat
        if c.save_epoch:
            epochs.append(dict(replicate=rep,protocol=protocol,epoch=ep,phase=ph,
              attack=int(sc['attack'][e]),arrived=int(incoming.sum()),confirmed=n_served,
              pending=generated-confirmed,active_validators=en['active_validators'],
              energy_wh=en['total'],consensus_wh=en['consensus'],background_wh=en['background'],
              sleep_wh=en['sleep'],compute_wh=en['compute'],radio_wh=en['radio'],
              unserved_control_work_s=en['unserved_control_work_s'],messages=int(shard_msgs.sum()),
              latency_ms=epoch_lat/max(1,n_served)*1000.,
              deadline_misses=epoch_miss))
        assert abs(en['total']-en['sleep']-en['compute']-en['radio'])<1e-8
        assert abs(en['total']-en['consensus']-en['background'])<1e-8
        assert abs(en['total']-sum(en[f'device_{d}'] for d in CLASSES))<1e-8
    pending=sum(int(st['arrived']-st['confirmed']) for st in states)
    assert confirmed+pending==generated
    assert abs(totals['total']-sum(totals[x] for x in ('sleep','compute','radio')))<1e-7
    assert abs(totals['total']-totals['consensus']-totals['background'])<1e-7
    out=dict(replicate=rep,scenario_seed=sc['scenario_seed'],protocol=protocol,
          deployment=c.deployment_mode,offered_tps=c.offered_tps,
          nodes=c.num_nodes,shards=c.num_shards,seconds=c.seconds,
          generated=generated,confirmed=confirmed,pending=pending,
          throughput_tps=confirmed/c.seconds,
          latency_mean_ms=1000*lat_sum/max(1,confirmed),
          critical_latency_ms=1000*critical_sum/max(1,critical_n),
          deadline_miss_ratio=missed/max(1,confirmed),messages=msgs,votes=votes,
          verifications=verifs,energy_total_wh=totals['total'],
          energy_consensus_wh=totals['consensus'],energy_background_wh=totals['background'],
          energy_sleep_wh=totals['sleep'],energy_compute_wh=totals['compute'],
          energy_radio_wh=totals['radio'],
          energy_sensor_wh=totals['device_sensor'],energy_gateway_wh=totals['device_gateway'],
          energy_edge_wh=totals['device_edge'],energy_cloud_wh=totals['device_cloud'],
          unserved_control_work_s=totals['unserved_control_work_s'],
          energy_total_uwh_per_tx=1e6*totals['total']/max(1,confirmed),
          energy_consensus_uwh_per_tx=1e6*totals['consensus']/max(1,confirmed),
          target_energy_uwh_per_tx=c.energy_target_wh_per_tx*1e6,
          below_target=int(totals['consensus']/max(1,confirmed)<=c.energy_target_wh_per_tx))
    for q,label in enumerate(PRIORITIES):
        out[f'{label.lower()}_confirmed']=int(total_class_confirmed[q])
        out[f'{label.lower()}_latency_ms']=1000*float(total_class_latency[q])/max(1,int(total_class_confirmed[q]))
        # Wait is measured for jobs that STARTED, including those unfinished.
        out[f'{label.lower()}_wait_started_ms']=1000*float(total_class_wait[q])/max(1,int(total_class_started[q]))
    for k,v in phases.items():
        name=k.lower();out[f'{name}_energy_rate_wh_per_s']=v['energy']/max(v['seconds'],1e-12)
        out[f'{name}_consensus_energy_rate_wh_per_s']=v['consensus']/max(v['seconds'],1e-12)
        out[f'{name}_energy_uwh_per_tx']=v['energy']*1e6/max(1,v['tx'])
        out[f'{name}_confirmed']=v['tx']
    out['attack_energy_rate_change_pct']=100*(out['during_energy_rate_wh_per_s']/max(out['pre_energy_rate_wh_per_s'],1e-12)-1)
    return out,epochs


def paired_tests(df,metric,protocols):
    """Paired by scenario seed; Holm adjusted within each metric's comparisons."""
    mat=df.pivot(index='replicate',columns='protocol',values=metric)
    result=[]
    for p in protocols:
        if p==PROTOCOLS[0]:continue
        d=(mat[p]-mat[PROTOCOLS[0]]).to_numpy()
        n=len(d);mean=float(d.mean());sd=float(d.std(ddof=1)) if n>1 else float('nan')
        if n>1 and sd>1e-13:
            pval=float(stats.ttest_1samp(d,0).pvalue)
        else:
            pval=1.
        interval=float(stats.t.ppf(.975,n-1)*sd/math.sqrt(n)) if n>1 else float('nan')
        result.append(dict(metric=metric,contrast=f'{p} - {PROTOCOLS[0]}',replicates=n,
                           mean_difference=mean,ci95_low=mean-interval,
                           ci95_high=mean+interval,p_raw=pval))
    idx=np.argsort([x['p_raw'] for x in result]);adj=0.
    for rank,i in enumerate(idx):
        adj=max(adj,min(1.,(len(result)-rank)*result[i]['p_raw']))
        result[i]['p_holm']=adj
    return pd.DataFrame(result)


def queue_unit_tests():
    """Numerical queue discipline + basic Erlang-C benchmark tests."""
    # Critical job arrives while one long Low job is in service; it cannot
    # preempt. After Low finishes, Critical takes the freed server before a
    # previously waiting Medium job.
    ta=np.array([0.,.01,.02],float)
    priority=np.array([3,2,0],np.int8)
    ex=np.array([1.,1.,1.],float)
    link=np.full(3,-1,np.int64);heads=np.full(4,-1,np.int64)
    tails=np.full(4,-1,np.int64);finish=np.full(1,np.inf)
    jobs=np.full(1,-1,np.int64);started=np.zeros(1,float)
    ptr,a,d,lat,wq,miss,cr,cn,byp,*_=advance_des(ta,priority,ex,0,link,heads,tails,
                          finish,jobs,started,1,np.array([1.]),0.,3.1,DEADLINES)
    assert a==3 and d==3 and cn==1
    assert 1.9<cr<2.1, 'Critical must wait for Low completion and then receive service'
    assert byp[0]==1 and byp[2]==1 and byp[3]==1
    # At t=2.5, Critical and Low must have completed, Medium must still wait.
    link=np.full(3,-1,np.int64);heads=np.full(4,-1,np.int64)
    tails=np.full(4,-1,np.int64);finish=np.full(1,np.inf)
    jobs=np.full(1,-1,np.int64);started=np.zeros(1,float)
    _,_,partial_done,_,_,_,_,_,partial,*_=advance_des(ta,priority,ex,0,link,heads,tails,
                          finish,jobs,started,1,np.array([1.]),0.,2.5,DEADLINES)
    assert partial_done==2 and partial[0]==1 and partial[3]==1 and partial[2]==0
    # Overloaded M/M/1 must accumulate unfinished transactions, not truncate rho.
    rng_over=np.random.default_rng(17)
    over_times=np.cumsum(rng_over.exponential(.5,600))
    over_dem=rng_over.exponential(1.,600)
    over_pr=np.zeros(600,np.int8)
    link=np.full(600,-1,np.int64);heads=np.full(4,-1,np.int64)
    tails=np.full(4,-1,np.int64);finish=np.full(1,np.inf)
    jobs=np.full(1,-1,np.int64);started=np.zeros(1,float)
    _,over_arr,over_done,*_=advance_des(over_times,over_pr,over_dem,0,link,heads,tails,
                        finish,jobs,started,1,np.array([1.]),0.,250.,DEADLINES)
    assert over_arr-over_done>100, 'Overloaded queue must accumulate backlog'
    # lambda 2.1, mu 1, c 3 (rho 0.7), stationary calibration benchmark
    lam=2.1;mu=1.;c=3;duration=7500.
    rng=np.random.default_rng(993)
    interarrival=rng.exponential(1/lam,23000)
    times=np.cumsum(interarrival)
    times=times[times<duration]
    pr=np.zeros(len(times),np.int8);dem=rng.exponential(1.,len(times))
    link=np.full(len(times),-1,np.int64);heads=np.full(4,-1,np.int64)
    tails=np.full(4,-1,np.int64);finish=np.full(c,np.inf)
    jobs=np.full(c,-1,np.int64);started=np.zeros(c,float)
    ptr,a,d,lat,wq,miss,cr,cn,byp,*_=advance_des(times,pr,dem,0,link,heads,tails,
                                     finish,jobs,started,c,np.ones(c),0.,duration,DEADLINES)
    analytic=erlang_c_reference(lam,mu,c)
    # Wq tracked for every start, including jobs that do not finish in-window;
    # compare after sufficiently long stationary warmup (here start-up fraction
    # is small). Loose stochastic tolerance appropriate for this short test.
    estimate=wq/max(1,d)
    assert abs(estimate-analytic)<max(.12,.3*analytic),(estimate,analytic)
    print(f'QUEUE CHECKS PASS: non-preemptive priority / Erlang-C reference ({estimate:.3f} vs {analytic:.3f} seconds)')


def smoke():
    queue_unit_tests()
    c=Config(seconds=1.,runs=1,attack_start=5,attack_end=8,
             pre_start=1,pre_end=4,save_epoch=True)
    check_config(c);sc=make_scenario(c,1);events=make_event_streams(c,sc)
    out=[]
    for p in PROTOCOLS+(ABLATION,):
        row,ep=simulate(p,c,sc,1,events)
        assert row['generated']==row['confirmed']+row['pending']
        assert row['energy_total_wh']>0 and row['energy_consensus_wh']>=0
        assert math.isclose(row['energy_total_wh'],row['energy_consensus_wh']+row['energy_background_wh'],abs_tol=1e-8)
        assert math.isclose(row['energy_total_wh'],sum(row[f'energy_{q}_wh'] for q in ('sleep','compute','radio')),abs_tol=1e-8)
        assert len(ep)==c.epochs
        out.append(row)
    a,_=simulate(PROTOCOLS[0],c,sc,1,events)
    b,_=simulate(PROTOCOLS[0],c,sc,1,events)
    assert a==b
    print('V3 SMOKE / EVENT QUEUE / MASS-BALANCE / ENERGY / DETERMINISM: PASS')
    return pd.DataFrame(out)


def main(c:Config,out_dir='consensus_v3_outputs'):
    check_config(c)
    if c.validate_queue_reference:queue_unit_tests()
    dst=Path(out_dir);dst.mkdir(parents=True,exist_ok=True)
    protocols=PROTOCOLS+((ABLATION,) if c.include_ablation else ())
    # Resumable, atomic per-replicate checkpointing: interruption does not lose
    # earlier replicates. Never reuse a folder if its configuration changed.
    manifest=json.dumps({'config':asdict(c),'protocols':list(protocols)},sort_keys=True)
    fingerprint=hashlib.sha256(manifest.encode()).hexdigest()
    marker=dst/'RUN_CONFIG_SHA256.txt'
    if marker.exists() and marker.read_text().strip()!=fingerprint:
        raise RuntimeError('Output folder contains results from DIFFERENT settings. Choose a new folder.')
    marker.write_text(fingerprint,encoding='utf-8')
    parts=dst/'per_replicate';parts.mkdir(exist_ok=True)
    runs=[];epochs=[]
    for r in range(1,c.runs+1):
        r_file=parts/f'replicate_{r:02d}.csv'
        e_file=parts/f'epochs_{r:02d}.csv'
        if r_file.is_file() and (not c.save_epoch or e_file.is_file()):
            existing=pd.read_csv(r_file)
            assert len(existing)==len(protocols) and set(existing.protocol)==set(protocols)
            runs.extend(existing.to_dict('records'))
            if c.save_epoch:epochs.extend(pd.read_csv(e_file).to_dict('records'))
            print(f'Replicate {r}/{c.runs} already complete; checkpoint reused',flush=True)
            continue
        sc=make_scenario(c,r)
        events=make_event_streams(c,sc)
        these_rows=[];these_epochs=[]
        for p in protocols:
            row,epochrows=simulate(p,c,sc,r,events)
            these_rows.append(row);these_epochs.extend(epochrows)
        # Write temp files then rename, making partial writes distinguishable.
        tmp=r_file.with_suffix('.tmp')
        pd.DataFrame(these_rows).to_csv(tmp,index=False,float_format='%.12g')
        tmp.replace(r_file)
        if c.save_epoch:
            tmp=e_file.with_suffix('.tmp')
            pd.DataFrame(these_epochs).to_csv(tmp,index=False,float_format='%.12g')
            tmp.replace(e_file)
        runs.extend(these_rows);epochs.extend(these_epochs)
        print(f'Replicate {r}/{c.runs} ({len(protocols)} arms) finished and saved',flush=True)
    df=pd.DataFrame(runs)
    df.to_csv(dst/'run_metrics.csv',index=False,float_format='%.12g')
    if c.save_epoch:pd.DataFrame(epochs).to_csv(dst/'epoch_metrics.csv',index=False,float_format='%.12g')
    fields=['throughput_tps','latency_mean_ms','critical_latency_ms','energy_total_wh',
            'energy_consensus_wh','energy_total_uwh_per_tx','energy_consensus_uwh_per_tx',
            'attack_energy_rate_change_pct','messages','verifications','pending',
            'deadline_miss_ratio','unserved_control_work_s']
    sums=df.groupby('protocol',sort=False)[fields].agg(['mean','std'])
    sums.columns=[a+'_'+b for a,b in sums.columns]
    sums.reset_index().to_csv(dst/'summary_mean_sample_sd.csv',index=False)
    paired=pd.concat([paired_tests(df,k,protocols) for k in ('energy_total_uwh_per_tx',
                'energy_consensus_uwh_per_tx','throughput_tps','latency_mean_ms')],ignore_index=True)
    paired.to_csv(dst/'paired_contrasts_holm.csv',index=False)
    meta=dict(configuration=asdict(c),protocols=protocols,power_w=POWER_W.tolist(),
        correction=CORRECTION.tolist(),capacity=NOMINAL_CAPACITY.tolist(),
        queue_model='Per-transaction discrete-event, four-class non-preemptive priority, hetero validator rates; FCFS within priority',
        reference='Exact Erlang-C only as homogeneous stationary M/M/c diagnostic; no fixed priority multipliers',
        service='Per-node Exp(base service) plus assumed deterministic protocol coordination work: heterogeneous M/G/c-like surrogate',
        security='assumed multiplicative activity energy factor; attacks are aggregate multipliers, not seven implemented attacks',
        comparison='framework comparison: proposed adaptive vs comparator fixed; fixed-committee ablation isolates scaling',
        energy='sum mutually exclusive sleep/compute/radio W*s/3600; consensus is incremental above sleep counterfactual',
        protocol_model='illustrative message-count proxies, NOT full protocol implementations',
        energy_target='design-level comparator only, not operational bound',
        deviations_from_v2='new priority DES, individual arrival times and service completions, true waiting and deadline counting')
    (dst/'assumptions.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False),encoding='utf-8')
    source_file=Path(globals().get('__file__','/content/consensus_energy_v3.py'))
    note=(hashlib.sha256(source_file.read_bytes()).hexdigest()+'  '+source_file.name+'\n'
          if source_file.is_file() else 'Executed as Colab cell; standalone SHA-256 unavailable\n')
    (dst/'SOURCE_SHA256.txt').write_text(note,encoding='utf-8')
    print(df.groupby('protocol',sort=False)[['energy_total_uwh_per_tx','energy_consensus_uwh_per_tx',
                                         'throughput_tps','latency_mean_ms','pending']].mean().round(4).to_string())
    return df


if __name__=='__main__':
    import argparse
    pa=argparse.ArgumentParser();pa.add_argument('--runs',type=int,default=10)
    pa.add_argument('--out',default='consensus_v3_outputs');pa.add_argument('--smoke',action='store_true')
    pa.add_argument('--seconds',type=float,default=30.)
    args,_unknown=pa.parse_known_args()
    if args.smoke:smoke()
    else:main(Config(runs=args.runs,seconds=args.seconds),args.out)
