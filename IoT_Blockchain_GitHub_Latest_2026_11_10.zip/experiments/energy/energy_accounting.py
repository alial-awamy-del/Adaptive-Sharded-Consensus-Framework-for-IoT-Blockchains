#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Auditable modeled IoT energy accounting, reconstructed from user-supplied models.

This is NOT the lost original implementation. Profiles and scenario factors are
assumptions from the archived code, not empirical device calibration.

Usage:
  python energy_accounting.py --demo
  python energy_accounting.py --self-test
  python energy_accounting.py --trace-csv MY_TRACE.csv --output-dir energy_output

Production trace CSV, one row per device-type x validator-role x epoch:
  run_id,epoch,protocol,phase,device_type,is_validator,count,duration_s,
  completed_tx,attack_power_multiplier
Here completed_tx must be the SAME epoch total on each row for that epoch;
this is checked. All device types/roles should be represented by disjoint rows.

No attempt is made to generate/force manuscript published numbers.
"""
from __future__ import annotations
import argparse
import csv
import math
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import mean, stdev
from typing import Iterable

DEVICE_PROFILES = {
    "sensor":  {"sleep": 0.0005, "compute": 0.05, "radio": 0.15, "correction": 0.12},
    "gateway": {"sleep": 2.5, "compute": 4.5, "radio": 6.0, "correction": 0.85},
    "edge":    {"sleep": 1.0, "compute": 8.0, "radio": 4.0, "correction": 1.6},
    "cloud":   {"sleep": 20.0, "compute": 60.0, "radio": 20.0, "correction": 3.2},
}
# Values from earlier simulation code. Assumptions; sensitivity analysis needed.
NETWORK_FACTOR = 1.3       # applies to active compute and radio
GENERAL_OVERHEAD = 2.0     # applies to all activities (legacy assumption)
CONSENSUS_FACTOR = 1.5     # incremental consensus compute factor = 1.5 - 1
# Protocol coefficients from archived model, not performance measurements.
PROTOCOLS = {
    "proposed": {"compute": 1.00, "radio": 1.00, "consensus": 1.00},
    "poa":      {"compute": 0.85, "radio": 0.90, "consensus": 0.85},
    "raft":     {"compute": 0.95, "radio": 1.10, "consensus": 0.95},
    "pbft_lite":{"compute": 1.20, "radio": 1.35, "consensus": 1.30},
}
VALIDATOR_ACTIVITY = {"sleep": 0.10, "compute": 0.60, "radio": 0.30}
CLIENT_ACTIVITY = {"sleep": 0.95, "compute": 0.04, "radio": 0.01}
# Explicit *assumed* fraction of validator radio activity attributable to
# consensus messaging. It does NOT create extra radio energy in this model.
CONSENSUS_RADIO_FRACTION = 0.50

@dataclass(frozen=True)
class DeviceGroup:
    device_type: str
    is_validator: bool
    count: int

@dataclass(frozen=True)
class EpochRecord:
    run_id: str
    epoch: int
    protocol: str
    phase: str
    duration_s: float
    completed_tx: int
    attack_power_multiplier: float
    groups: tuple[DeviceGroup, ...]


def _check_finite_nonneg(x: float, name: str, *, strictly_positive=False):
    if not math.isfinite(x) or (x <= 0 if strictly_positive else x < 0):
        raise ValueError(f"Invalid {name}: {x!r}")


def energy_for_epoch(rec: EpochRecord, *, radio_consensus_fraction=CONSENSUS_RADIO_FRACTION,
                     network_factor=NETWORK_FACTOR, overhead=GENERAL_OVERHEAD,
                     consensus_factor=CONSENSUS_FACTOR) -> dict:
    """Calculate all energy components without double counting.

    'Consensus-attributed' is a modeled accounting partition (not measured).
    Baseline compute and radio energy are partitioned into ordinary and
    consensus portions, with a separate positive incremental compute overhead.
    Attacks raise active energy and the increment is recorded separately.
    """
    if rec.protocol not in PROTOCOLS:
        raise ValueError(f"Unknown protocol: {rec.protocol}")
    if rec.phase not in {"pre", "during", "post", "normal"}:
        raise ValueError(f"Unknown phase: {rec.phase}")
    _check_finite_nonneg(rec.duration_s, "duration_s", strictly_positive=True)
    _check_finite_nonneg(rec.attack_power_multiplier, "attack multiplier", strictly_positive=True)
    _check_finite_nonneg(radio_consensus_fraction, "radio fraction")
    if radio_consensus_fraction > 1:
        raise ValueError("radio_consensus_fraction must be <= 1")
    for v, n in [(network_factor, 'network_factor'), (overhead, 'overhead'),
                 (consensus_factor, 'consensus_factor')]:
        _check_finite_nonneg(v, n, strictly_positive=True)
    if consensus_factor < 1:
        raise ValueError("consensus_factor must be >= 1 for positive incremental model")
    if rec.completed_tx < 0:
        raise ValueError("Negative processed transactions")
    coeff = PROTOCOLS[rec.protocol]
    sums = defaultdict(float)
    device_totals = defaultdict(float)
    n_nodes = 0
    validator_count = 0
    for g in rec.groups:
        if g.device_type not in DEVICE_PROFILES or g.count < 0:
            raise ValueError(f"Invalid device group {g!r}")
        if g.is_validator and g.device_type == "sensor":
            raise ValueError("Sensors cannot be validators under the adopted architecture")
        prof = DEVICE_PROFILES[g.device_type]
        fractions = VALIDATOR_ACTIVITY if g.is_validator else CLIENT_ACTIVITY
        if not math.isclose(sum(fractions.values()), 1.0, abs_tol=1e-12):
            raise AssertionError("Invalid activity budget")
        factor = prof["correction"] * overhead * g.count * rec.duration_s / 3600.0
        sleep = prof["sleep"] * fractions["sleep"] * factor
        compute_base = prof["compute"] * fractions["compute"] * factor * network_factor
        radio_base = prof["radio"] * fractions["radio"] * factor * network_factor
        # Split baseline energy by *activity purpose*, not by changing device watts.
        if g.is_validator:
            ordinary_compute = compute_base
            ordinary_radio = radio_base * (1 - radio_consensus_fraction)
            consensus_radio = radio_base * radio_consensus_fraction * coeff["radio"]
            # Positive additional consensus compute work vs base compute duty-cycle.
            consensus_compute = compute_base * (consensus_factor - 1) * coeff["compute"] * coeff["consensus"]
        else:
            ordinary_compute, ordinary_radio = compute_base, radio_base
            consensus_radio = consensus_compute = 0.0
        active_pre_attack = ordinary_compute + ordinary_radio + consensus_compute + consensus_radio
        attack_increment = active_pre_attack * (rec.attack_power_multiplier - 1.0)
        if attack_increment < -1e-12:
            raise ValueError("Attack multiplier <1. Use >=1 for this overhead decomposition")
        sums["sleep_wh"] += sleep
        sums["ordinary_compute_wh"] += ordinary_compute
        sums["ordinary_radio_wh"] += ordinary_radio
        sums["consensus_compute_wh"] += consensus_compute
        sums["consensus_radio_wh"] += consensus_radio
        sums["attack_increment_wh"] += attack_increment
        device_totals[g.device_type] += sleep + active_pre_attack + attack_increment
        n_nodes += g.count
        validator_count += g.count if g.is_validator else 0
    total = sum(sums.values())
    if not math.isclose(total, sum(device_totals.values()), rel_tol=1e-10, abs_tol=1e-9):
        raise AssertionError("Energy conservation failed")
    consensus = sums["consensus_compute_wh"] + sums["consensus_radio_wh"]
    return {
        "run_id": rec.run_id, "epoch": rec.epoch, "protocol": rec.protocol, "phase": rec.phase,
        "duration_s": rec.duration_s, "completed_tx": rec.completed_tx,
        "node_count": n_nodes, "validator_count": validator_count,
        "total_wh": total, "consensus_attributed_wh": consensus,
        "nonconsensus_wh": total - consensus,
        "sleep_wh": sums["sleep_wh"], "ordinary_compute_wh": sums["ordinary_compute_wh"],
        "ordinary_radio_wh": sums["ordinary_radio_wh"],
        "consensus_compute_wh": sums["consensus_compute_wh"],
        "consensus_radio_wh": sums["consensus_radio_wh"],
        "attack_increment_wh": sums["attack_increment_wh"],
        **{f"device_{dev}_wh": device_totals[dev] for dev in DEVICE_PROFILES},
    }


def aggregate(rows: Iterable[dict], group_keys=("run_id", "protocol", "phase")) -> list[dict]:
    buckets = defaultdict(list)
    for row in rows:
        buckets[tuple(row[k] for k in group_keys)].append(row)
    out = []
    energy_keys = ("total_wh", "consensus_attributed_wh", "nonconsensus_wh", "sleep_wh",
                   "ordinary_compute_wh", "ordinary_radio_wh", "consensus_compute_wh",
                   "consensus_radio_wh", "attack_increment_wh") + tuple(f"device_{x}_wh" for x in DEVICE_PROFILES)
    for keys, vals in sorted(buckets.items()):
        d = dict(zip(group_keys, keys))
        d["epochs"] = len(vals)
        d["duration_s"] = sum(v["duration_s"] for v in vals)
        d["completed_tx"] = sum(v["completed_tx"] for v in vals)
        for k in energy_keys:
            d[k] = sum(v[k] for v in vals)
        d["total_uw_per_tx"] = 1e6 * d["total_wh"] / d["completed_tx"] if d["completed_tx"] else float('nan')
        d["consensus_uw_per_tx"] = 1e6 * d["consensus_attributed_wh"] / d["completed_tx"] if d["completed_tx"] else float('nan')
        d["total_wh_per_s"] = d["total_wh"] / d["duration_s"]
        d["completed_tps"] = d["completed_tx"] / d["duration_s"]
        out.append(d)
    return out


def comparison_summary(run_rows: Iterable[dict]) -> list[dict]:
    """Mean and sample SD across independent runs, not across epochs."""
    buckets = defaultdict(list)
    for r in run_rows:
        buckets[(r["protocol"], r["phase"])].append(r)
    result = []
    for (protocol, phase), v in sorted(buckets.items()):
        d = {"protocol": protocol, "phase": phase, "n_runs": len(v)}
        for metric in ("total_uw_per_tx", "consensus_uw_per_tx", "total_wh_per_s", "completed_tps"):
            vals = [row[metric] for row in v if math.isfinite(row[metric])]
            d[metric + "_mean"] = mean(vals) if vals else float('nan')
            d[metric + "_sample_sd"] = stdev(vals) if len(vals) > 1 else float('nan')
        result.append(d)
    return result


def read_trace_csv(path: Path) -> list[EpochRecord]:
    buckets = defaultdict(list)
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        required = {"run_id", "epoch", "protocol", "phase", "device_type", "is_validator", "count", "duration_s", "completed_tx", "attack_power_multiplier"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("Trace CSV is missing fields: " + ", ".join(sorted(required - set(reader.fieldnames or []))))
        for row in reader:
            key = (row["run_id"], int(row["epoch"]), row["protocol"])
            buckets[key].append(row)
    records = []
    for (run_id, epoch, protocol), group_rows in sorted(buckets.items()):
        metadata = [(r["phase"], float(r["duration_s"]), int(r["completed_tx"]), float(r["attack_power_multiplier"])) for r in group_rows]
        if any(x != metadata[0] for x in metadata):
            raise ValueError(f"Conflicting epoch metadata for {(run_id, epoch, protocol)}")
        phase, duration, completed, attack = metadata[0]
        groups = []
        seen = set()
        for r in group_rows:
            boolean = r["is_validator"].strip().lower()
            if boolean not in ('true','false','1','0'):
                raise ValueError(f"Invalid is_validator {boolean!r}")
            validator = boolean in ('true','1')
            pair = (r['device_type'], validator)
            if pair in seen:
                raise ValueError(f"Duplicate device/role group in epoch: {pair}")
            seen.add(pair)
            groups.append(DeviceGroup(r["device_type"], validator, int(r["count"])))
        records.append(EpochRecord(run_id, epoch, protocol, phase, duration, completed, attack, tuple(groups)))
    return records


def write_csv(path: Path, rows: list[dict]):
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def demo_trace():
    """Illustration ONLY: invented fixed device composition and validator counts.

    Do not cite demonstration outputs as original results or new empirical evidence.
    The same device roles/workload are reused across protocols for a paired,
    coefficient-only counterfactual energy comparison.
    """
    node_counts = {"sensor": 600, "gateway": 250, "edge": 100, "cloud": 50}
    validators = {"sensor": 0, "gateway": 90, "edge": 70, "cloud": 20}
    groups = tuple(g for dev in node_counts for g in (
        DeviceGroup(dev, True, validators[dev]),
        DeviceGroup(dev, False, node_counts[dev] - validators[dev])
    ) if g.count > 0)
    for run in range(3):
        for protocol in PROTOCOLS:
            for epoch in range(1, 61):
                phase = 'pre' if epoch <= 20 else ('during' if epoch <= 40 else 'post')
                attack = 1.12 if phase == 'during' else 1.0
                # Deliberately deterministic and same across protocols (NOT actual simulator).
                completed = 4000 + ((epoch + run) % 3 - 1) * 10
                yield EpochRecord(f"demo_{run}", epoch, protocol, phase, 0.05, completed, attack, groups)


def self_test():
    groups = (DeviceGroup('gateway', True, 2), DeviceGroup('sensor', False, 3))
    r = EpochRecord('1', 1, 'proposed', 'pre', 0.05, 300, 1.0, groups)
    a = energy_for_epoch(r)
    assert a['total_wh'] > a['consensus_attributed_wh'] > 0
    assert a['attack_increment_wh'] == 0
    assert a['node_count'] == 5
    b = energy_for_epoch(EpochRecord('1', 1, 'proposed', 'during', 0.05, 300, 1.2, groups))
    assert b['total_wh'] > a['total_wh']
    assert b['attack_increment_wh'] > 0
    assert math.isclose(b['sleep_wh'], a['sleep_wh'])
    assert math.isclose(b['total_wh'] - b['attack_increment_wh'], a['total_wh'])
    summaries = aggregate([a,b])
    assert len(summaries) == 2
    assert all(x['total_wh'] >= x['consensus_attributed_wh'] for x in summaries)
    try:
        energy_for_epoch(EpochRecord('x', 1, 'proposed', 'pre', 0.05, 1, 1.0, (DeviceGroup('sensor', True, 1),)))
        raise AssertionError('Expected invalid sensor-validator exception')
    except ValueError:
        pass
    print('Self tests passed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--demo', action='store_true', help='Illustrative synthetic trace only; NOT paper results')
    source.add_argument('--trace-csv', type=Path, help='Actual epoch-level simulator trace with device roles')
    source.add_argument('--self-test', action='store_true')
    parser.add_argument('--output-dir', type=Path, default=Path('energy_output'))
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    records = list(demo_trace()) if args.demo else read_trace_csv(args.trace_csv)
    if not records:
        raise ValueError('No epoch records supplied')
    epoch_results = [energy_for_epoch(x) for x in records]
    by_run_phase = aggregate(epoch_results)
    by_run_total = aggregate(epoch_results, ('run_id','protocol'))
    summarized_phase = comparison_summary(by_run_phase)
    summarized_total = comparison_summary([{**row, 'phase':'all'} for row in by_run_total])
    target = args.output_dir
    write_csv(target / 'energy_epoch_detail.csv', epoch_results)
    write_csv(target / 'energy_run_phase.csv', by_run_phase)
    write_csv(target / 'energy_run_total.csv', by_run_total)
    write_csv(target / 'energy_phase_mean_sd.csv', summarized_phase)
    write_csv(target / 'energy_total_mean_sd.csv', summarized_total)
    print('MODELED energy accounting:', 'DEMO/ILLUSTRATIVE' if args.demo else 'USER SIMULATION TRACE')
    for row in summarized_total:
        print(f"{row['protocol']:<12} total={row['total_uw_per_tx_mean']:8.3f} µWh/tx; "
              f"consensus-attributed={row['consensus_uw_per_tx_mean']:8.3f} µWh/tx; "
              f"n={row['n_runs']}")
    print('Output directory:', target.resolve())

if __name__ == '__main__':
    main()
