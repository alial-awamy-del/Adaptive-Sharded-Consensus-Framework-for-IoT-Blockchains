"""Basic reproducibility, accounting and structural checks (not protocol validation)."""
from dataclasses import replace
import numpy as np
from consensus_comparison_colab import Config, PROTOCOLS, make_scenario, simulate, message_counts, validate_config


def run_tests():
    c=Config(runs=1,seconds=2.0,epoch_s=.05,attack_first_epoch=15,
             attack_last_epoch=25,pre_first_epoch=10,pre_last_epoch=14,
             save_epoch_metrics=True)
    validate_config(c)
    scenario=make_scenario(c,1)
    all_out=[]
    for protocol in PROTOCOLS:
        a,epochs=simulate(protocol,c,scenario,1)
        b,_=simulate(protocol,c,scenario,1)
        assert a==b, f'Non-reproducible: {protocol}'
        assert len(epochs)==40
        assert a['generated']==a['confirmed']+a['pending']
        assert abs(a['energy_system_wh']-a['energy_background_wh']-a['energy_consensus_wh']) < 1e-7
        assert abs(sum(x['energy_system_wh'] for x in epochs)-a['energy_system_wh']) < 1e-7
        assert abs(sum(x['energy_consensus_wh'] for x in epochs)-a['energy_consensus_wh']) < 1e-7
        assert a['confirmed']>0
        assert a['energy_consensus_wh']>=0
        assert a['system_uwh_per_tx'] >= a['consensus_uwh_per_tx']
        assert all(x['energy_system_wh']>=x['energy_consensus_wh']>=0 for x in epochs)
        assert all(x['attack']==int(15<=x['epoch']<=25) for x in epochs)
        all_out.append(a)
    # All protocols see exact same exogenous scenario.
    assert len({a['generated'] for a in all_out})==1
    # PBFT has more control traffic than PoA with the same committee and batches.
    assert message_counts('PBFT_lite_proxy',16,5,1)[0] > message_counts('PoA_proxy',16,5,1)[0]
    # Repeatable scenario generator.
    again=make_scenario(c,1)
    assert np.array_equal(scenario['arrivals'],again['arrivals'])
    print('PASS: reproducibility, common conditions, mass balance, energy balance, phases, model ordering')

if __name__ == '__main__': run_tests()
