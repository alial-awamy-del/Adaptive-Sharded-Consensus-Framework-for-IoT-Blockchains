# -*- coding: utf-8 -*-
"""Auditable, parameterized consensus-comparison *surrogate* for Google Colab.

IMPORTANT: NOT real implementations of PoA, Raft, PBFT-lite, DPoS-PBFT, or PoV-DRoP.
This is a workload/message-cost and capacity simulation. Its results are NEW and
MUST NOT be presented as reconstructions of prior published numbers. See README.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

PROTOCOLS = ("Proposed_Hybrid_proxy", "DPoS_PBFT_proxy", "PoA_proxy", "Raft_proxy", "PBFT_lite_proxy")
DEVICE_CLASSES = ("sensor", "gateway", "edge", "cloud")
CLASSES = ("CRITICAL", "HIGH", "MEDIUM", "LOW")
PRIORITY_FRACTIONS = np.array((.10, .20, .30, .40))
DEADLINE_S = np.array((.10, .20, .50, 1.00))
SERVICE_S = np.array((.001, .002, .005, .010))
# Source-file values; modeled power values, NOT measured hardware calibration.
POWER = {
    "sensor": dict(sleep=.0005, compute=.05, radio=.15, correction=.12, capacity=10),
    "gateway": dict(sleep=2.5, compute=4.5, radio=6., correction=.85, capacity=100),
    "edge": dict(sleep=1., compute=8., radio=4., correction=1.6, capacity=500),
    "cloud": dict(sleep=20., compute=60., radio=20., correction=3.2, capacity=2000),
}
# Baseline non-consensus duty fractions (sleep,compute,radio) - NEW assumptions.
BASE_DUTY = {"sensor": (.96,.03,.01), "gateway": (.70,.20,.10),
             "edge": (.45,.40,.15), "cloud": (.35,.50,.15)}

@dataclass(frozen=True)
class Config:
    nodes: int = 1000
    shards: int = 10
    seconds: float = 30.0
    epoch_s: float = .05
    offered_tps: int = 80000
    runs: int = 10
    seed: int = 20261107
    attack_first_epoch: int = 120
    attack_last_epoch: int = 220
    pre_first_epoch: int = 100
    pre_last_epoch: int = 119
    batch_size: int = 250
    service_scale: float = 1.35
    link_bytes_per_s_per_shard: float = 100e6
    control_message_bytes: int = 512
    control_energy_j_per_message: float = .0005
    verification_energy_j_per_operation: float = .0025
    election_energy_j_per_vote: float = .001
    network_impact_coefficient: float = .20
    network_factor: float = 1.3
    background_overhead_factor: float = 2.0
    device_weights: tuple = (.60, .25, .10, .05)
    deployment: str = "edge_dominant"
    sample_energy: bool = False
    save_epoch_metrics: bool = True

    @property
    def epochs(self):
        return round(self.seconds / self.epoch_s)


def validate_config(c: Config):
    assert c.deployment == "edge_dominant", "This experiment is edge_dominant only"
    assert c.nodes >= 10*c.shards and c.runs >= 1
    assert c.seconds > 0 and c.epoch_s > 0 and c.offered_tps > 0
    assert math.isclose(c.epochs*c.epoch_s, c.seconds, abs_tol=1e-9)
    assert c.pre_last_epoch < c.attack_first_epoch <= c.attack_last_epoch <= c.epochs
    assert len(c.device_weights) == 4 and abs(sum(c.device_weights) - 1) < 1e-10
    assert c.batch_size > 0 and c.link_bytes_per_s_per_shard > 0
    assert c.sample_energy is False, "No energy subsampling; sum all devices"


def make_scenario(c: Config, replicate: int) -> dict:
    """Immutable/common exogenous conditions, shared across all five protocols."""
    rng = np.random.default_rng(c.seed + replicate*100003)
    profiles = rng.choice(len(DEVICE_CLASSES), c.nodes, p=c.device_weights)
    rng.shuffle(profiles)
    # Equal-number sharding, random device assignment; fixed across protocols.
    shard_of_node = np.arange(c.nodes) % c.shards
    rng.shuffle(shard_of_node)
    members = tuple(np.flatnonzero(shard_of_node == sid) for sid in range(c.shards))
    reputation = rng.uniform(0.5, 1.0, c.nodes)
    # One statistically identical traffic matrix, repeated by all protocols.
    n = c.epochs
    total_per_epoch = rng.poisson(c.offered_tps*c.epoch_s, size=n)
    attacks = (np.arange(1,n+1) >= c.attack_first_epoch) & (np.arange(1,n+1) <= c.attack_last_epoch)
    # Attack loading and capacity penalties fixed per epoch, not protocol-specific.
    attack_arrival_mult = np.where(attacks, rng.uniform(1.10,1.25,n), 1.)
    attack_service_mult = np.where(attacks, rng.uniform(.86,.98,n), 1.)
    attack_net_mult = np.where(attacks, rng.uniform(1.05,1.20,n), 1.)
    arrival = np.zeros((n,c.shards,4),dtype=np.int64)
    for e in range(n):
        total = int(round(total_per_epoch[e]*attack_arrival_mult[e]))
        by_shard = rng.multinomial(total, np.ones(c.shards)/c.shards)
        for s in range(c.shards):
            arrival[e,s] = rng.multinomial(by_shard[s], PRIORITY_FRACTIONS)
    return dict(profiles=profiles, reputation=reputation, members=members,
                arrivals=arrival, attacks=attacks,
                service_mult=attack_service_mult, network_mult=attack_net_mult,
                seed=c.seed+replicate*100003)


def committee_for_shard(protocol: str, scenario: dict, sid: int, desired: int) -> np.ndarray:
    """Selection *proxy*; sensors excluded, cloud membership capped at ~24%."""
    nodes = scenario['members'][sid]
    profiles = scenario['profiles']
    rep = scenario['reputation']
    eligible = nodes[profiles[nodes] != 0]
    if len(eligible)==0:
        return np.zeros((0,), dtype=int)
    score = np.array([POWER[DEVICE_CLASSES[profiles[i]]]['capacity'] for i in eligible], float)
    # Edge-dominant policy, fixed and disclosed; not independent implementations.
    score *= np.choose(profiles[eligible], [0,1.35,1.75,.40])
    if protocol == 'Proposed_Hybrid_proxy':
        score *= (0.5+rep[eligible])   # trust-aware selection proxy
    elif protocol == 'DPoS_PBFT_proxy':
        score *= (0.75+0.5*rep[eligible])   # delegated ranking proxy
    order = eligible[np.argsort(-score,kind='stable')]
    max_cloud = math.ceil(.24*desired)
    max_edge = math.ceil(.48*desired)
    max_gateway = math.ceil(.34*desired)
    out=[]; count={1:0,2:0,3:0}; maxes={1:max_gateway,2:max_edge,3:max_cloud}
    for i in order:
        p=int(profiles[i]);
        if count[p] < maxes[p] and len(out)<desired:
            out.append(int(i)); count[p]+=1
    for i in order:
        if len(out)>=min(desired,len(eligible)): break
        if int(i) not in out: out.append(int(i))
    return np.asarray(out,dtype=int)


def message_counts(protocol: str, k:int, blocks:int, epoch:int) -> tuple[int,int,int]:
    """Return (control messages, elections/votes, signature verifications per accepted tx).

    Illustrative upper/lower bound-style communication patterns; NOT protocol implementations.
    No use of arbitrary per-protocol ENERGY MULTIPLIERS.
    """
    if k <= 0 or blocks <= 0: return (0,0,0)
    if protocol == 'Proposed_Hybrid_proxy':
        # linear-vote hybrid quorum path; committee adaptation priced each epoch
        return (blocks*(3*(k-1)), k, max(1,math.ceil(2*k/3)))
    if protocol == 'DPoS_PBFT_proxy':
        # Delegation plus two all-to-all Byzantine agreement phases
        return (blocks*(2*k*(k-1)+2*(k-1)), k, max(1,math.ceil(2*k/3)))
    if protocol == 'PoA_proxy':
        return (blocks*(2*(k-1)), 0, 1)
    if protocol == 'Raft_proxy':
        return (blocks*(2*(k-1))+(k-1), 0, 2)
    if protocol == 'PBFT_lite_proxy':
        return (blocks*(2*k*(k-1)+3*(k-1)), 0, k)
    raise KeyError(protocol)


def background_energy_wh(scenario: dict, c: Config) -> float:
    """Fixed background energy per epoch, including idle devices (all 1,000 nodes)."""
    total_power=0.0
    for d, name in enumerate(DEVICE_CLASSES):
        count=int(np.count_nonzero(scenario['profiles']==d))
        sleep,compute,radio=BASE_DUTY[name]
        p=POWER[name]
        watts=(sleep*p['sleep'] + compute*p['compute']*c.network_factor +
               radio*p['radio']*c.network_factor)*p['correction']*c.background_overhead_factor
        total_power += count*watts
    return total_power*c.epoch_s/3600.


def phase_label(epoch_1b:int,c:Config)->str:
    if c.pre_first_epoch <= epoch_1b <= c.pre_last_epoch: return 'PRE'
    if c.attack_first_epoch <= epoch_1b <= c.attack_last_epoch: return 'DURING'
    if epoch_1b > c.attack_last_epoch: return 'POST'
    return 'OTHER'


def simulate(protocol:str, c: Config, scenario:dict, rep:int) -> tuple[dict,list[dict]]:
    assert protocol in PROTOCOLS
    backlog=np.zeros((c.shards,4),dtype=np.int64)
    backlog_age=np.zeros((c.shards,4),dtype=float) # mean modeled age of pending tx, seconds
    consumed=0; generated=0; missed=0
    energy_sys=0.; energy_cons=0.; energy_bg=0.
    message_total=0; vote_total=0; verified_ops_total=0
    latency_weighted=0.; latency_by_priority=np.zeros(4); priority_processed=np.zeros(4,dtype=np.int64)
    phase={'PRE':dict(energy=0.,consensus=0.,tx=0,time=0.,latency_sum=0.),
           'DURING':dict(energy=0.,consensus=0.,tx=0,time=0.,latency_sum=0.),
           'POST':dict(energy=0.,consensus=0.,tx=0,time=0.,latency_sum=0.)}
    epochs=[]
    # Static committees for conventional controls; adaptive committee for Proposed.
    initial_sizes={'Proposed_Hybrid_proxy':16,'DPoS_PBFT_proxy':16,
                   'PoA_proxy':16,'Raft_proxy':16,'PBFT_lite_proxy':16}
    sizes=np.full(c.shards,initial_sizes[protocol],dtype=int)
    static = [committee_for_shard(protocol,scenario,s,int(sizes[s])) for s in range(c.shards)]
    per_epoch_bg=background_energy_wh(scenario,c)

    for e in range(c.epochs):
        epoch=e+1; arrivals=scenario['arrivals'][e]; attack=bool(scenario['attacks'][e])
        generated += int(arrivals.sum()); backlog += arrivals
        # No latency based on clipped utilization; overload persists as finite-time backlog.
        epoch_processed=0; epoch_latency=0.; epoch_cons_j=0.; epoch_msgs=0; epoch_votes=0
        for s in range(c.shards):
            before_shard = int(backlog[s].sum())
            if protocol=='Proposed_Hybrid_proxy':
                # Adaptive committee size, driven by offered load / real capacity,
                # with clipping to available non-sensor nodes; same hardware for all.
                current=static[s]
                cap_now=sum(POWER[DEVICE_CLASSES[scenario['profiles'][i]]]['capacity'] for i in current)*c.service_scale
                lam=float(backlog[s].sum())/c.epoch_s
                rho=lam/max(cap_now,1e-9)
                if rho>.82: sizes[s]=min(24,sizes[s]+2)
                elif rho<.30: sizes[s]=max(12,sizes[s]-1)
                static[s]=committee_for_shard(protocol,scenario,s,int(sizes[s]))
            committee=static[s]; k=len(committee)
            if k==0: continue
            nominal=sum(POWER[DEVICE_CLASSES[scenario['profiles'][i]]]['capacity'] for i in committee)*c.service_scale
            # Predict control traffic from the incoming batch, not outcome, to avoid circularity.
            expect_blocks=math.ceil(max(1,int(backlog[s].sum()))/c.batch_size)
            ctrl_expect,_,_=message_counts(protocol,k,expect_blocks,epoch)
            network_util=(ctrl_expect*c.control_message_bytes*scenario['network_mult'][e]) / (c.link_bytes_per_s_per_shard*c.epoch_s)
            # Conservative bounded capacity loss due to modeled link occupancy.
            available=nominal * float(scenario['service_mult'][e]) * max(.20,1-c.network_impact_coefficient*min(network_util,4))
            cap=int(max(0,math.floor(available*c.epoch_s)))
            # Common strict priority scheduling for every protocol: isolates consensus effects.
            for q in range(4):
                n=int(min(cap,backlog[s,q]));
                if n<=0: continue
                # Batch-scale mean waiting-age proxy: residual backlog and service latency.
                queue_delay=float(backlog_age[s,q]) + min(.1,max(0,backlog[s,q]-n)/max(available,1))
                confirmation_delay=queue_delay+SERVICE_S[q]+(.0015 if not attack else .0020)
                missed += n if confirmation_delay>DEADLINE_S[q] else 0
                priority_processed[q]+=n; latency_by_priority[q]+=n*confirmation_delay
                epoch_latency += n*confirmation_delay
                backlog[s,q]-=n; cap-=n; epoch_processed+=n
            # Message/control and verifier accounting for THIS shard's completed tx.
            accepted_s = before_shard - int(backlog[s].sum())
            blocks = math.ceil(accepted_s/c.batch_size) if accepted_s else 0
            msg, votes, replicas = message_counts(protocol,k,blocks,epoch)
            # Election/control activity is modeled even in an idle epoch for schemes
            # that invoke epoch-level committee selection.
            if not blocks and protocol in ('Proposed_Hybrid_proxy','DPoS_PBFT_proxy'):
                votes = k
            epoch_msgs += msg
            epoch_votes += votes
            verified_ops_total += accepted_s*replicas
            epoch_cons_j += (msg*c.control_energy_j_per_message*float(scenario['network_mult'][e])+
                             votes*c.election_energy_j_per_vote+
                             accepted_s*replicas*c.verification_energy_j_per_operation)
            # age outstanding by an epoch, and apply no synthetic deadline expiration here
            for q in range(4):
                if backlog[s,q]>0: backlog_age[s,q]+=c.epoch_s
                else: backlog_age[s,q]=0.
        bg=per_epoch_bg
        ce=epoch_cons_j/3600.
        energy_bg += bg; energy_cons += ce; energy_sys += bg+ce
        message_total += epoch_msgs; vote_total += epoch_votes
        consumed += epoch_processed; latency_weighted += epoch_latency
        phase_name=phase_label(epoch,c)
        if phase_name in phase:
            p=phase[phase_name]; p['energy']+=bg+ce; p['consensus']+=ce
            p['tx']+=epoch_processed; p['time']+=c.epoch_s; p['latency_sum']+=epoch_latency
        if c.save_epoch_metrics:
            epochs.append(dict(replicate=rep,protocol=protocol,epoch=epoch,time_s=epoch*c.epoch_s,
                               phase=phase_name,attack=int(attack),arrival=int(arrivals.sum()),
                               processed=epoch_processed,backlog=int(backlog.sum()),
                               energy_system_wh=bg+ce,energy_consensus_wh=ce,
                               energy_background_wh=bg,messages=epoch_msgs,votes=epoch_votes,
                               latency_mean_ms=epoch_latency/max(1,epoch_processed)*1000))
    assert consumed+int(backlog.sum())==generated, ('mass balance',consumed,backlog.sum(),generated)
    assert abs(energy_sys-energy_bg-energy_cons)<1e-8
    assert sum(p['tx'] for p in phase.values())<=consumed
    out=dict(replicate=rep,scenario_seed=scenario['seed'],protocol=protocol,mode=c.deployment,
             offered_tps=c.offered_tps,seconds=c.seconds,nodes=c.nodes,shards=c.shards,
             generated=generated,confirmed=consumed,pending=int(backlog.sum()),
             throughput_tps=consumed/c.seconds,deadline_misses=missed,
             deadline_miss_ratio=missed/max(1,consumed),
             latency_mean_ms=latency_weighted/max(1,consumed)*1000,
             energy_system_wh=energy_sys,energy_background_wh=energy_bg,
             energy_consensus_wh=energy_cons,
             system_uwh_per_tx=1e6*energy_sys/max(1,consumed),
             consensus_uwh_per_tx=1e6*energy_cons/max(1,consumed),
             messages=message_total,votes=vote_total,verification_operations=verified_ops_total)
    for i,cl in enumerate(CLASSES):
        out['latency_'+cl.lower()+'_ms']=latency_by_priority[i]/max(1,int(priority_processed[i]))*1000
    for label,p in phase.items():
        out[label.lower()+'_energy_rate_wh_per_s']=p['energy']/max(p['time'],1e-12)
        out[label.lower()+'_energy_uwh_per_tx']=p['energy']/max(1,p['tx'])*1e6
        out[label.lower()+'_confirmed']=p['tx']
        out[label.lower()+'_latency_ms']=p['latency_sum']/max(1,p['tx'])*1e3
    out['attack_energy_rate_change_pct']=100*(out['during_energy_rate_wh_per_s']/max(1e-12,out['pre_energy_rate_wh_per_s'])-1)
    return out,epochs


def paired_inference(df:pd.DataFrame, metric:str) -> pd.DataFrame:
    """Paired per-seed contrasts vs Proposed with Holm correction for 4 comparisons."""
    wide=df.pivot(index='replicate',columns='protocol',values=metric)
    results=[]
    for other in PROTOCOLS[1:]:
        differences=(wide[other]-wide[PROTOCOLS[0]]).to_numpy(dtype=float)
        n=len(differences)
        p=float(stats.ttest_1samp(differences,0.).pvalue) if n>1 and np.std(differences,ddof=1)>1e-14 else 1.
        sd=float(np.std(differences,ddof=1)) if n>1 else 0.
        half=float(stats.t.ppf(.975,n-1)*sd/math.sqrt(n)) if n>1 else float('nan')
        results.append(dict(metric=metric,contrast=f'{other} minus {PROTOCOLS[0]}',n=n,
                            mean_difference=float(np.mean(differences)),ci95_low=float(np.mean(differences)-half),
                            ci95_high=float(np.mean(differences)+half),raw_p=p))
    # Holm step-down multiple testing adjustment across four planned contrasts.
    order=np.argsort([r['raw_p'] for r in results]); running=0.
    for rank,j in enumerate(order):
        running=max(running,min(1.,(len(results)-rank)*results[j]['raw_p']))
        results[j]['holm_p']=running
    return pd.DataFrame(results)


def main(config:Config,output_dir:str='comparison_outputs'):
    validate_config(config)
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    records=[]; epochs=[]
    for rep in range(1,config.runs+1):
        scenario=make_scenario(config,rep)
        for protocol in PROTOCOLS:
            result, epoch_rows=simulate(protocol,config,scenario,rep)
            records.append(result); epochs.extend(epoch_rows)
        print(f'Replicate {rep}/{config.runs} completed (all 5 protocols, same scenario).',flush=True)
    df=pd.DataFrame(records)
    df.to_csv(out/'raw_run_metrics.csv',index=False,float_format='%.12g')
    if config.save_epoch_metrics:
        pd.DataFrame(epochs).to_csv(out/'epoch_level_metrics.csv',index=False,float_format='%.12g')
    cols=['throughput_tps','latency_mean_ms','latency_critical_ms','energy_system_wh',
          'energy_consensus_wh','system_uwh_per_tx','consensus_uwh_per_tx',
          'attack_energy_rate_change_pct','messages','votes','pending','deadline_miss_ratio']
    summary=df.groupby('protocol',sort=False)[cols].agg(['mean','std'])
    summary.columns=[f'{a}_{b}' for a,b in summary.columns]
    summary=summary.reset_index(); summary.to_csv(out/'summary_mean_sample_sd.csv',index=False)
    inference=pd.concat([paired_inference(df,x) for x in ['system_uwh_per_tx','consensus_uwh_per_tx',
                        'throughput_tps','latency_mean_ms']],ignore_index=True)
    inference.to_csv(out/'paired_contrasts_holm.csv',index=False)
    params=asdict(config)
    params['protocols']=list(PROTOCOLS)
    params['power_profiles']=POWER
    params['background_duty_fractions']=BASE_DUTY
    params['equations']={
       'background_wh':'sum_device((sleep_w*d_sleep + compute_w*d_compute*network_factor + radio_w*d_radio*network_factor)*correction*background_overhead_factor)*epoch_s/3600',
       'consensus_wh':'(control_messages*control_energy_J*attack_network_multiplier + election_votes*election_energy_J + verified_transactions*verification_replicas*verification_energy_J)/3600',
       'system_wh':'background_wh + consensus_wh',
       'transaction_balance':'generated = confirmed + pending (no modeled expiration)',
       'latency':'backlog-age proxy + residual queue/capacity + class processing time + network latency; NOT network packet latency'
    }
    (out/'configuration_and_assumptions.json').write_text(json.dumps(params,indent=2,ensure_ascii=False),encoding='utf-8')
    print('\n=== Summary (simulation surrogate; NOT measured protocol performance) ===')
    print(summary[['protocol','system_uwh_per_tx_mean','system_uwh_per_tx_std',
                   'consensus_uwh_per_tx_mean','consensus_uwh_per_tx_std',
                   'throughput_tps_mean']].to_string(index=False))
    print(f'Files saved to {out.resolve()}')
    return df,summary,inference


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--runs',type=int,default=10)
    parser.add_argument('--seed',type=int,default=20261107)
    parser.add_argument('--out',default='comparison_outputs')
    parser.add_argument('--no-epochs',action='store_true')
    args=parser.parse_args()
    main(Config(runs=args.runs,seed=args.seed,save_epoch_metrics=not args.no_epochs),args.out)
