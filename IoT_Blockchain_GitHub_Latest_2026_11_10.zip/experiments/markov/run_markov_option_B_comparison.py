"""Paired-seed comparative simulation: original vs activity-aware Markov option B.

Run in folder containing both simulator source files:
 python run_markov_option_B_comparison.py --runs 10 --tps 80000 --duration 30 --out markov_B_comparison

The two systems share the same seed and initial configuration, but stochastic
trajectories may diverge as committee composition changes. No fabricated results.
"""
import argparse
import csv
import importlib.util
import json
import random
from pathlib import Path

import numpy as np


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def row(m, fw, variant, seed):
    trust = fw.markov_trust_model
    d = trust.current_state_distribution()
    tx = fw.tx.metrics
    n = max(1, int(tx['tx_processed']))
    qs = fw.metrics['queue_stats']
    counts = [sum(v.state == 'MALICIOUS' for v in fw.validators)]
    return {
        'variant': variant, 'seed': seed,
        'target_tps': fw.target_tps, 'duration_s': fw.sim_t,
        'nodes': len(fw.nodes), 'shards': m.NUM_SHARDS,
        'trusted_pct': d['TRUSTED'] * 100,
        'neutral_pct': d['NEUTRAL'] * 100,
        'risky_pct': d['RISKY'] * 100,
        'malicious_pct': d['MALICIOUS'] * 100,
        'processed_tps': int(tx['tx_processed']) / fw.sim_t,
        'generated_tx': int(tx['tx_generated']),
        'processed_tx': int(tx['tx_processed']),
        'expired_tx': int(tx['tx_expired']),
        'pending_tx': fw.tx.pending_count(),
        'latency_ms': 1000.0 * tx['total_latency_s'] / n,
        'energy_uwh_tx': 1e6 * fw.total_energy_wh / n,
        'mean_active_validators': float(np.mean([q['c'] for q in qs])),
        'mean_shard_rho': float(np.mean([q['avg_shard_rho'] for q in qs])),
        'end_malicious_active': counts[0],
        'max_malicious_active_post_selection': max(fw.metrics.get('malicious_active_after_selection_epoch', [0])) if variant == 'B' else 'not_recorded',
        'audit_events': getattr(trust, 'audit_events_total', 0),
        'audit_passes': getattr(trust, 'audit_pass_total', 0),
        'audit_rehabilitations': getattr(trust, 'audit_rehabilitations_total', 0),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--runs', type=int, default=10)
    p.add_argument('--tps', type=float, default=80000)
    p.add_argument('--duration', type=float, default=30)
    p.add_argument('--nodes', type=int, default=1000)
    p.add_argument('--shards', type=int, default=10)
    p.add_argument('--seed-base', type=int, default=6100)
    p.add_argument('--out', default='markov_B_comparison')
    args = p.parse_args()
    here = Path(__file__).resolve().parent
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    variants = {
        'original': load('markov_original', here / 'iot_blockchain_markov_original.py'),
        'B': load('markov_B', here / 'iot_blockchain_markov_option_B.py'),
    }
    for m in variants.values():
        m.NUM_NODES = args.nodes
        m.NUM_SHARDS = args.shards
        m.SIMULATION_DURATION = args.duration
        m.WRITE_REPORT_TO_FILE = False
    rows=[]
    for r in range(args.runs):
        seed = args.seed_base + r
        for variant, m in variants.items():
            random.seed(seed); np.random.seed(seed)
            fw = m.run_simulation(target_tps=args.tps, report_path=None, verbose=False, deployment_mode='edge_dominant')
            record=row(m,fw,variant,seed)
            rows.append(record)
            print(f'{r+1}/{args.runs} {variant}: malignant={record["malicious_pct"]:.2f}% throughput={record["processed_tps"]:.1f} TPS', flush=True)
    path=out/'per_run.csv'
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    metrics=['trusted_pct','malicious_pct','processed_tps','pending_tx','expired_tx','latency_ms','energy_uwh_tx','mean_active_validators','mean_shard_rho','audit_events','audit_rehabilitations']
    summaries=[]
    for variant in variants:
        subset=[x for x in rows if x['variant']==variant]
        for metric in metrics:
            values=np.array([float(x[metric]) for x in subset])
            summaries.append({'variant':variant,'metric':metric,'n':len(values),'mean':values.mean(),'sd':values.std(ddof=1) if len(values)>1 else 0})
    with (out/'summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(summaries[0]));w.writeheader();w.writerows(summaries)
    (out/'protocol.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    print('Wrote',path,'and',out/'summary.csv')

if __name__=='__main__':main()
