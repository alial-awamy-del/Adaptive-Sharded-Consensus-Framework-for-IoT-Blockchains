# -*- coding: utf-8 -*-
"""
REALISTIC IoT BLOCKCHAIN SIMULATION - FULL REPORT + PRE/DURING/POST ATTACK PHASES
--------------------------------------------------------------------------------
ENERGY MODEL ENHANCEMENTS:
- Device-profile-aware energy modeling using representative IoT hardware classes
- Protocol-specific energy factors based on communication complexity
- Attack impact on energy, throughput, and latency
- Markov-based validator trust state transitions with empirical transition tracking
- Explicit event-driven simulation of seven attack types with detection and mitigation accounting
- Nominal-capacity validator service model: reputation/trust affects selection,
  while device class determines selected-validator service capacity.
"""

import random
import math
import numpy as np
import os
import csv
import hashlib
from collections import defaultdict, deque

# ============================================================
# CONSTANTS
# ============================================================
NUM_NODES = 1000
NUM_SHARDS = 10
EPOCH_DURATION = 0.05
SIMULATION_DURATION = 30.0

TARGET_TPS = 80000

SECURITY_LEVEL = 1.0
EWMA_ALPHA = 0.30
EWMA_THRESHOLD = 0.08

RHO_MIN = 0.40
RHO_MAX = 0.80
RHO_TARGET = 0.60

BLOCK_TIME = 1.0
BLOCK_SIZE = 1000
ENERGY_TARGET = 0.0001
CARBON_INTENSITY_KG_PER_KWH = 0.5

ATTACK_START_EPOCH = 120
ATTACK_END_EPOCH = 220

WARMUP_EPOCHS = 20
PRE_WINDOW_EPOCHS = 20

REPORT_EVERY_SECONDS = 1.0
WRITE_REPORT_TO_FILE = True

PRIORITY_LEVELS = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
PRIORITY_CONFIG = {
    "CRITICAL": {"deadline": 0.1, "weight": 0.10, "security_level": 1.0, "base_proc_s": 0.001},
    "HIGH":     {"deadline": 0.2, "weight": 0.20, "security_level": 0.9, "base_proc_s": 0.002},
    "MEDIUM":   {"deadline": 0.5, "weight": 0.30, "security_level": 0.7, "base_proc_s": 0.005},
    "LOW":      {"deadline": 1.0, "weight": 0.40, "security_level": 0.5, "base_proc_s": 0.010},
}

# ============================================================
# REAL-TIME OPTIMIZATION KNOBS
# ============================================================
# These knobs make the simulator more appropriate for firm/soft real-time IoT.
# They do not claim hard real-time URLLC behavior; instead they prioritize
# deadline preservation for emergency/critical events.
FAST_LANE_ENABLED = True
LOAD_AWARE_SHARD_ROUTING = True
POWER_OF_TWO_CHOICES = 2
ROUTING_CHUNK_SIZE = 250
CRITICAL_RESERVED_VALIDATOR_RATIO = 0.25
CRITICAL_FAST_LANE_WQ_FACTOR = 0.30
CRITICAL_FAST_LANE_PROC_FACTOR = 0.55
CRITICAL_FAST_LANE_NET_DELAY_RANGE = (0.0003, 0.0010)
NORMAL_NET_DELAY_RANGE = (0.0008, 0.0025)
CONSENSUS_DELAY_BY_PRIORITY = {
    "CRITICAL": 0.0012,
    "HIGH": 0.0016,
    "MEDIUM": 0.0022,
    "LOW": 0.0030,
}
REALTIME_RHO_TARGET = 0.55
SHARD_SCALE_UP_RHO = 0.82
SHARD_SCALE_DOWN_RHO = 0.30
SCALE_UP_SMOOTHING = 0.65
SCALE_DOWN_SMOOTHING = 0.20

# ============================================================
# POST-ATTACK SHARD RECOVERY CONTROLS
# ============================================================
# After the attack window, the simulator explicitly enters a bounded recovery
# period. The purpose is to drain residual shard backlogs, rebalance new
# arrivals away from saturated shards, and temporarily reserve additional
# edge/gateway validation capacity for overloaded shards.
POST_ATTACK_RECOVERY_EPOCHS = 160
RECOVERY_RHO_TRIGGER = 0.72
RECOVERY_RHO_TARGET = 0.48
RECOVERY_ROUTE_PRESSURE_WEIGHT = 2500.0
RECOVERY_EDGE_SCORE_BONUS = 1.35
RECOVERY_GATEWAY_SCORE_BONUS = 1.12
RECOVERY_CLOUD_SCORE_FACTOR = 0.85
RECOVERY_EXTRA_VALIDATORS_PER_OVERLOADED_SHARD = 8

# ============================================================
# MARKOV TRUST MODEL CONSTANTS
# ============================================================
# State order follows the mathematical model:
# S = {TRUSTED, NEUTRAL, RISKY, MALICIOUS}
TRUST_STATES = ["TRUSTED", "NEUTRAL", "RISKY", "MALICIOUS"]

# Baseline stochastic transition matrix P_base.
# Rows represent current states, columns represent next states.
P_BASE = np.array([
    [0.85, 0.10, 0.04, 0.01],  # TRUSTED
    [0.20, 0.65, 0.12, 0.03],  # NEUTRAL
    [0.10, 0.30, 0.50, 0.10],  # RISKY
    [0.05, 0.15, 0.20, 0.60],  # MALICIOUS
], dtype=float)

# Numerical smoothing for empirical transition matrices and KL diagnostics
MARKOV_EPS = 1e-12

# OPTION B: explicit activity-aware trust evidence (synthetic sensitivity protocol).
# An audit is independent of consensus; it is NOT an observed blockchain event.
INACTIVE_AUDIT_INTERVAL_EPOCHS = 20
INACTIVE_AUDIT_PASS_BASE = 0.65
INACTIVE_AUDIT_PASS_QUALITY_GAIN = 0.30
INACTIVE_AUDIT_ATTACK_PENALTY = 0.25
INACTIVE_AUDIT_RECOVERY_PROB = 0.25
FAIL_CLOSED_ON_EMPTY_SHARD = True

# ============================================================
# DEVICE PROFILES (Calibrated values)
# ============================================================

PROFILE_REFERENCE_MAP = {
    "sensor": "ESP32-C3-class sensor node",
    "gateway": "Raspberry Pi 4-class gateway node",
    "edge": "Jetson Nano-class edge node",
    "cloud": "Cloud-backed validator proxy"
}

DEVICE_PROFILES = {
    "sensor": {
        "reference_device": "ESP32-C3-class sensor",
        "power": {"sleep": 0.0005, "compute": 0.05, "radio": 0.15},
        "capacity": 10,
        "energy_correction": 0.12,
        "memory_mb": 0.1,
        "typical_use": "Sensing and periodic transmission"
    },
    "gateway": {
        "reference_device": "Raspberry Pi 4-class gateway",
        "power": {"sleep": 2.5, "compute": 4.5, "radio": 6.0},
        "capacity": 100,
        "energy_correction": 0.85,
        "memory_mb": 0.5,
        "typical_use": "Aggregation and local coordination"
    },
    "edge": {
        "reference_device": "Jetson Nano-class edge node",
        "power": {"sleep": 1.0, "compute": 8.0, "radio": 4.0},
        "capacity": 500,
        "energy_correction": 1.6,
        "memory_mb": 2.0,
        "typical_use": "Edge inference and validator processing"
    },
    "cloud": {
        "reference_device": "Cloud-backed validator proxy",
        "power": {"sleep": 20.0, "compute": 60.0, "radio": 20.0},
        "capacity": 2000,
        "energy_correction": 3.2,
        "memory_mb": 10.0,
        "typical_use": "Remote consensus participation and validation"
    },
}

# ============================================================
# DEVICE-LEVEL THROUGHPUT ACCOUNTING
# ============================================================
# Source weights model the fact that sensors mainly generate IoT events, while
# gateways/edge/cloud contribute fewer direct application transactions.
DEVICE_TYPES = ["sensor", "gateway", "edge", "cloud"]

# Sensors are transaction/data producers and lightweight clients only.
# They are intentionally excluded from validator committees to keep the
# deployment consistent with edge/middleware IoT-blockchain architecture.
VALIDATOR_DEVICE_TYPES = ["gateway", "edge", "cloud"]

DEVICE_SOURCE_WEIGHTS = {
    "sensor": 0.60,
    "gateway": 0.25,
    "edge": 0.10,
    "cloud": 0.05,
}

# ============================================================
# DEPLOYMENT MODE / DECENTRALIZATION POLICY
# ============================================================
# cloud_assisted: prioritizes maximum throughput and uses cloud-backed validators
# when they provide the highest service capacity.
# edge_dominant: prioritizes smart-city decentralization and local processing by
# favoring edge/gateway validators and capping the cloud contribution.
DEPLOYMENT_MODES = ["cloud_assisted", "edge_dominant"]

DEVICE_PROCESSING_BONUS_BY_MODE = {
    "cloud_assisted": {
        "sensor": 1.00,
        "gateway": 1.00,
        "edge": 1.00,
        "cloud": 1.00,
    },
    "edge_dominant": {
        "sensor": 0.35,
        "gateway": 1.35,
        "edge": 1.75,
        "cloud": 0.40,
    },
}

# Maximum processing attribution share per device type. These are soft caps;
# if a shard lacks enough eligible validators of a given type, the remaining
# probability mass is redistributed to available validator classes.
PROCESSOR_SHARE_CAPS_BY_MODE = {
    "cloud_assisted": {
        "sensor": 0.00,
        "gateway": 0.35,
        "edge": 0.50,
        "cloud": 0.35,
    },
    "edge_dominant": {
        "sensor": 0.00,
        "gateway": 0.30,
        "edge": 0.47,
        "cloud": 0.25,
    },
}

# Optional cap used during validator committee construction. This avoids a
# committee that is structurally cloud-dominated before processing even starts.
VALIDATOR_COUNT_CAPS_BY_MODE = {
    "cloud_assisted": {
        "sensor": 0.00,
        "gateway": 0.35,
        "edge": 0.50,
        "cloud": 0.35,
    },
    "edge_dominant": {
        "sensor": 0.00,
        "gateway": 0.34,
        "edge": 0.48,
        "cloud": 0.24,
    },
}

# ============================================================
# PROTOCOL-SPECIFIC ENERGY FACTORS
# ============================================================

CONSENSUS_ENERGY_MODELS = {
    "proposed": {
        "compute_mult": 1.00,
        "radio_mult": 1.00,
        "consensus_mult": 1.00,
        "label": "Proposed Hybrid Consensus",
        "description": "Reference model with trust-aware validator selection and queue-aware scaling",
        "complexity": "Baseline"
    },
    "poa": {
        "compute_mult": 0.85,
        "radio_mult": 0.90,
        "consensus_mult": 0.85,
        "label": "Proof of Authority (PoA)",
        "description": "Lower coordination overhead due to authority-based validation",
        "complexity": "O(1)"
    },
    "raft": {
        "compute_mult": 0.95,
        "radio_mult": 1.10,
        "consensus_mult": 0.95,
        "label": "Raft Consensus",
        "description": "Leader-based coordination with moderate communication cost",
        "complexity": "O(n)"
    },
    "pbft_lite": {
        "compute_mult": 1.20,
        "radio_mult": 1.35,
        "consensus_mult": 1.30,
        "label": "PBFT-lite",
        "description": "Higher communication overhead due to Byzantine multi-party agreement",
        "complexity": "O(n²)"
    }
}

REALITY_FACTORS = {
    "network": 1.3,
    "security": 1.4,
    "consensus": 1.5,
    "storage": 1.2,
    "overhead": 2.0,
}

FAST_MODE = True
ENERGY_SAMPLE_RATIO = 0.15
MAX_TX_PER_EPOCH = 20000

# ============================================================
# HELPERS
# ============================================================
def clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x

def safe_mean(arr):
    return float(np.mean(arr)) if len(arr) else 0.0

def safe_std(arr):
    return float(np.std(arr)) if len(arr) else 0.0

def safe_percentile(arr, p):
    return float(np.percentile(arr, p)) if len(arr) else 0.0

def safe_corr(a, b):
    if len(a) < 2 or np.std(a) == 0 or np.std(b) == 0:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])

# ============================================================
# STABLE M/M/c QUEUE (Erlang C)
# ============================================================
class StableMMcValidatorQueue:
    def __init__(self, num_servers: int):
        self.c = int(max(1, num_servers))
        self.lam = 0.0
        self.mu = 1e-6
        self.total_processed = 0
        self.total_wait_time_s = 0.0
        self.max_wq_s = 1.0

    def set_servers(self, c: int):
        self.c = int(max(1, c))

    def update_rates(self, arrival_rate: float, service_rate_per_server: float):
        self.lam = float(max(0.0, arrival_rate))
        self.mu = float(max(1e-6, service_rate_per_server))

    def rho_raw(self) -> float:
        return 0.0 if (self.c <= 0 or self.mu <= 0) else (self.lam / (self.c * self.mu))

    def rho(self) -> float:
        return min(self.rho_raw(), 0.999999)

    def _erlang_c(self) -> float:
        c = self.c
        if c <= 0 or self.mu <= 0:
            return 0.0
        rho = self.rho()
        if rho <= 0:
            return 0.0
        if rho >= 0.999999:
            return 0.999999

        a = self.lam / self.mu
        sum_terms = 1.0
        term = 1.0
        for k in range(1, c):
            term *= a / k
            sum_terms += term

        term *= a / c
        numer = term * (1.0 / max(1e-12, 1.0 - rho))
        denom = sum_terms + numer
        if denom <= 0:
            return 0.999999
        return min(max(numer / denom, 0.0), 0.999999)

    def Lq(self) -> float:
        rho = self.rho()
        if rho <= 0:
            return 0.0
        if rho >= 0.999999:
            return 100.0
        # Exact Erlang-C becomes expensive and numerically unstable for large c.
        # For large validator pools we use a fast Halfin-Whitt-like approximation
        # that preserves the key behavior: Lq grows sharply as rho approaches 1.
        if self.c > 50:
            expo = max(1.0, math.sqrt(2.0 * (self.c + 1.0)) - 1.0)
            approx = (rho ** expo) * rho / max(1e-12, 1.0 - rho)
            return float(min(max(approx, 0.0), 100.0))
        C = self._erlang_c()
        return float(min(C * rho / max(1e-12, 1.0 - rho), 100.0))

    def Wq(self) -> float:
        if self.lam <= 0:
            return 0.0
        return float(min(max(self.Lq() / self.lam, 0.0), self.max_wq_s))

    def W(self) -> float:
        return 0.0 if self.mu <= 0 else float(self.Wq() + 1.0 / self.mu)

    def get_stats(self) -> dict:
        return {
            "c": self.c,
            "lambda": self.lam,
            "mu": self.mu,
            "rho": self.rho_raw(),
            "rho_stable": self.rho(),
            "Lq": self.Lq(),
            "Wq_s": self.Wq(),
            "W_s": self.W(),
            "rho_min": RHO_MIN,
            "rho_max": RHO_MAX,
            "rho_target": RHO_TARGET,
        }

# ============================================================
# IoT NODE
# ============================================================
class IoTNode:
    __slots__ = (
        "id","profile","reputation","validator_score","state","energy_wh",
        "energy_by_activity","is_validator","security_level","stake","ddos_affected"
    )

    def __init__(self, node_id: int):
        self.id = int(node_id)
        self.profile = random.choices(list(DEVICE_PROFILES.keys()), weights=[0.6, 0.25, 0.10, 0.05])[0]
        self.reputation = 60 + random.randint(0, 40)
        self.validator_score = 50 + random.randint(0, 50)
        # Initial state is not fixed for all nodes; this better matches a Markov trust population.
        self.state = random.choices(
            ["TRUSTED", "NEUTRAL", "RISKY", "MALICIOUS"],
            weights=[0.70, 0.22, 0.07, 0.01],
            k=1
        )[0]
        self.energy_wh = 0.0
        self.energy_by_activity = defaultdict(float)
        self.is_validator = False
        self.security_level = SECURITY_LEVEL
        self.stake = 30 + random.randint(0, 70)
        self.ddos_affected = False

    def update_energy_activity_based(
        self,
        activity: str,
        duration_s: float,
        power_mult: float = 1.0,
        compute_mult: float = 1.0,
        radio_mult: float = 1.0,
        consensus_mult: float = 1.0
    ) -> float:
        prof = DEVICE_PROFILES[self.profile]
        base_power = prof["power"][activity] * prof.get("energy_correction", 1.0)

        network_factor = REALITY_FACTORS["network"] if activity in ("radio", "compute") else 1.0
        security_factor = 1.0 + (1.0 - self.security_level) * 0.5

        if activity == "compute":
            protocol_factor = compute_mult
        elif activity == "radio":
            protocol_factor = radio_mult
        else:
            protocol_factor = 1.0

        if self.is_validator and activity == "compute":
            consensus_factor = consensus_mult * REALITY_FACTORS["consensus"]
        else:
            consensus_factor = 1.0

        actual_power = (
            base_power
            * network_factor
            * security_factor
            * consensus_factor
            * protocol_factor
            * REALITY_FACTORS["overhead"]
            * float(max(0.0, power_mult))
        )
        
        consumed_wh = actual_power * duration_s / 3600.0
        self.energy_wh += consumed_wh
        self.energy_by_activity[activity] += consumed_wh
        return consumed_wh

# ============================================================
# SHARDS
# ============================================================
class ShardManager:
    def __init__(self, nodes):
        self.nodes = nodes
        self.shards = {}
        self._create_shards()

    def _create_shards(self):
        nodes = self.nodes[:]
        random.shuffle(nodes)
        shard_size = max(1, len(nodes) // NUM_SHARDS)
        remainder = len(nodes) % NUM_SHARDS
        start = 0
        for sid in range(NUM_SHARDS):
            end = start + shard_size + (1 if sid < remainder else 0)
            self.shards[sid] = nodes[start:end]
            start = end

    def get_shard(self, shard_id):
        return self.shards.get(shard_id, [])

# ============================================================
# VALIDATORS
# ============================================================
class ValidatorManager:
    """Shard-level validator manager with one M/M/c queue per shard.

    The previous implementation used one global M/M/c queue for the whole
    validator pool. This version keeps a full shard-level implementation:
    arrivals, service rate, utilization, wait time, and validator scaling are
    computed independently for every shard. An aggregate queue summary is still
    returned for backward-compatible reporting.
    """
    def __init__(self, shard_manager: ShardManager, deployment_mode: str = "edge_dominant"):
        self.shard_manager = shard_manager
        self.deployment_mode = deployment_mode if deployment_mode in DEPLOYMENT_MODES else "edge_dominant"
        self.validators = []
        self.validators_by_shard = {sid: [] for sid in range(NUM_SHARDS)}
        self.shard_queues = {sid: StableMMcValidatorQueue(num_servers=1) for sid in range(NUM_SHARDS)}
        # Backward-compatible aggregate queue summary.
        self.queue_model = StableMMcValidatorQueue(num_servers=1)
        # Real-time optimized version rotates/scales validators every epoch so
        # congested shards receive additional validators before deadlines expire.
        self.rotation_interval = 1
        self.last_metrics_update_sim_t = 0.0
        self.arrivals_in_window_by_shard = defaultdict(float)
        self.utilization_history = []
        self.shard_utilization_history = {sid: [] for sid in range(NUM_SHARDS)}
        # A slightly higher service scale models micro-batching and fast-path
        # validation for critical IoT transactions.
        self.MU_SCALE = 1.35
        self.recovery_mode = False
        self.recovery_overloaded_shards = set()

    def _candidate_score(self, node: IoTNode) -> float:
        # Sensors are not eligible to serve as primary validators.
        # They remain transaction producers/lightweight clients.
        if node.profile not in VALIDATOR_DEVICE_TYPES:
            return 0.0
        hw_factor = DEVICE_PROFILES[node.profile]["capacity"] / 800.0
        security_factor = 1.0 + (node.security_level * 0.4)
        stake_factor = node.stake / 80.0
        state_factor_map = {
            "TRUSTED": 1.00,
            "NEUTRAL": 0.75,
            "RISKY": 0.35,
            "MALICIOUS": 0.00,
        }
        state_factor = state_factor_map.get(node.state, 0.50)
        base_score = (
            math.log1p(node.reputation) * 0.22
            + math.log1p(node.validator_score) * 0.22
            + hw_factor * 0.26
            + security_factor * 0.12
            + stake_factor * 0.06
            + state_factor * 0.12
        )
        # Deployment-aware selection: edge-dominant mode favors local edge/fog
        # validators and treats cloud validators as an overflow resource.
        bonus = DEVICE_PROCESSING_BONUS_BY_MODE.get(self.deployment_mode, {}).get(node.profile, 1.0)
        # During post-attack recovery, favor locally available gateway/edge
        # validators to drain affected shards while retaining cloud as overflow.
        recovery_bonus = 1.0
        if getattr(self, "recovery_mode", False):
            if node.profile == "edge":
                recovery_bonus = RECOVERY_EDGE_SCORE_BONUS
            elif node.profile == "gateway":
                recovery_bonus = RECOVERY_GATEWAY_SCORE_BONUS
            elif node.profile == "cloud":
                recovery_bonus = RECOVERY_CLOUD_SCORE_FACTOR
        return base_score * float(bonus) * float(recovery_bonus)

    def _eligible_nodes_in_shard(self, sid: int):
        """Return nodes that may act as validators in this shard.

        Sensors are deliberately excluded from validator committees. This keeps
        the architecture consistent with the thesis assumption that sensors are
        mainly data producers/lightweight clients, while gateways, edge/fog, and
        selected cloud-backed nodes perform validation/consensus work.
        """
        return [
            n for n in self.shard_manager.get_shard(sid)
            if n.profile in VALIDATOR_DEVICE_TYPES
        ]

    def _base_count_per_shard(self, sid: int) -> int:
        # At least two non-sensor validators per shard when possible.
        eligible_size = len(self._eligible_nodes_in_shard(sid))
        if eligible_size <= 0:
            return 0
        return int(clamp(max(2, int(math.ceil(eligible_size * 0.03))), 1, eligible_size))

    def _max_count_per_shard(self, sid: int) -> int:
        eligible_size = len(self._eligible_nodes_in_shard(sid))
        if eligible_size <= 0:
            return 0
        return int(max(self._base_count_per_shard(sid), max(1, eligible_size // 2)))

    def _set_validator_flags(self):
        for sid in range(NUM_SHARDS):
            for node in self.shard_manager.get_shard(sid):
                node.is_validator = False
        self.validators = []
        for sid, vals in self.validators_by_shard.items():
            for v in vals:
                v.is_validator = True
                self.validators.append(v)

    def _apply_validator_count_caps(self, candidates, desired: int):
        """Select a committee while respecting deployment-mode device caps.

        Caps are intentionally soft. If a shard does not have enough eligible
        validators of the preferred types, the remaining slots are filled by the
        best candidates regardless of type to preserve liveness.
        """
        caps = VALIDATOR_COUNT_CAPS_BY_MODE.get(self.deployment_mode)
        if not caps or desired <= 0:
            return [n for _, n in candidates[:desired]]

        max_counts = {dev: max(0, int(math.ceil(float(caps.get(dev, 1.0)) * desired))) for dev in DEVICE_TYPES}
        selected = []
        selected_ids = set()
        counts = {dev: 0 for dev in DEVICE_TYPES}

        # First pass: respect caps.
        for score, node in candidates:
            if len(selected) >= desired:
                break
            prof = node.profile
            if counts.get(prof, 0) < max_counts.get(prof, desired):
                selected.append(node)
                selected_ids.add(id(node))
                counts[prof] = counts.get(prof, 0) + 1

        # Second pass: preserve liveness if caps cannot fill the shard committee.
        if len(selected) < desired:
            for score, node in candidates:
                if len(selected) >= desired:
                    break
                if id(node) not in selected_ids:
                    selected.append(node)
                    selected_ids.add(id(node))
        return selected[:desired]

    def _apply_processor_share_caps(self, weights: dict) -> dict:
        """Apply soft processing-share caps and redistribute excess mass."""
        caps = PROCESSOR_SHARE_CAPS_BY_MODE.get(self.deployment_mode)
        total = sum(float(weights.get(dev, 0.0)) for dev in DEVICE_TYPES)
        if total <= 0:
            return {"sensor": 0.0, "gateway": 1.0, "edge": 0.0, "cloud": 0.0}
        norm = {dev: float(weights.get(dev, 0.0)) / total for dev in DEVICE_TYPES}
        if not caps:
            return norm

        # Iterative cap/redistribution. This keeps the distribution normalized
        # while preventing cloud dominance in edge-dominant deployments.
        capped = norm.copy()
        fixed = set()
        for _ in range(8):
            excess = 0.0
            for dev in DEVICE_TYPES:
                cap = float(caps.get(dev, 1.0))
                if capped.get(dev, 0.0) > cap + 1e-12:
                    excess += capped[dev] - cap
                    capped[dev] = cap
                    fixed.add(dev)
            if excess <= 1e-12:
                break
            receivers = [dev for dev in DEVICE_TYPES if dev not in fixed and capped.get(dev, 0.0) > 0]
            if not receivers:
                receivers = [dev for dev in DEVICE_TYPES if capped.get(dev, 0.0) > 0]
            recv_total = sum(capped[d] for d in receivers)
            if recv_total <= 0:
                break
            for dev in receivers:
                capped[dev] += excess * (capped[dev] / recv_total)
        s = sum(capped.values())
        if s <= 0:
            return norm
        return {dev: capped[dev] / s for dev in DEVICE_TYPES}

    def select_validators(self, count=None, count_by_shard=None):
        """Select validators independently inside each shard.

        count_by_shard is preferred for shard-level scaling. If only count is
        supplied, it is distributed across shards as evenly as possible.
        """
        # Recovery mode is set by rotate_validators before committee selection.
        recovery_mode = bool(getattr(self, "recovery_mode", False))
        if count_by_shard is None:
            total_base = sum(self._base_count_per_shard(sid) for sid in range(NUM_SHARDS))
            total_max = sum(self._max_count_per_shard(sid) for sid in range(NUM_SHARDS))
            if count is None:
                count = total_base
            count = int(clamp(count, total_base, total_max))
            base = count // NUM_SHARDS
            rem = count % NUM_SHARDS
            count_by_shard = {sid: base + (1 if sid < rem else 0) for sid in range(NUM_SHARDS)}

        new_by_shard = {}
        for sid in range(NUM_SHARDS):
            c_min = self._base_count_per_shard(sid)
            c_max = self._max_count_per_shard(sid)
            if c_max <= 0:
                new_by_shard[sid] = []
                continue
            desired = int(count_by_shard.get(sid, c_min))
            desired = int(clamp(desired, c_min, c_max))

            candidates = []
            for node in self._eligible_nodes_in_shard(sid):
                if node.reputation >= 50 and node.validator_score >= 40 and node.state != "MALICIOUS":
                    candidates.append((self._candidate_score(node), node))
            candidates.sort(key=lambda x: x[0], reverse=True)

            if len(candidates) < desired:
                # If Markov trust is very harsh, keep the shard alive with the
                # best non-sensor, non-malicious fallback candidates. Sensors
                # are never used as primary validators.
                seen = {id(n) for _, n in candidates}
                fallback = []
                for node in self._eligible_nodes_in_shard(sid):
                    if id(node) in seen:
                        continue
                    if node.state != "MALICIOUS":
                        fallback.append((self._candidate_score(node) * 0.8, node))
                # Option B: never reintroduce MALICIOUS nodes merely to fill slots.
                # Effective committee size can be below the requested target.
                fallback.sort(key=lambda x: x[0], reverse=True)
                candidates.extend(fallback)

            if FAIL_CLOSED_ON_EMPTY_SHARD and len(candidates) == 0:
                raise RuntimeError(
                    f"Shard {sid} has no non-MALICIOUS eligible validator; "
                    "simulation cannot silently assign phantom service capacity."
                )
            new_by_shard[sid] = self._apply_validator_count_caps(candidates, min(desired, len(candidates)))

        # Post-attack recovery borrowing: after every shard has kept its local
        # committee, allocate only currently unused trusted gateway/edge nodes
        # to residual overloaded shards. This avoids starving donor shards and
        # keeps sensor nodes excluded from all committees.
        if recovery_mode and self.recovery_overloaded_shards:
            selected_ids = {id(v) for vals in new_by_shard.values() for v in vals}
            spare_pool = [
                n for n in self.shard_manager.nodes
                if n.profile in ("gateway", "edge")
                and n.state != "MALICIOUS"
                and id(n) not in selected_ids
            ]
            spare_pool.sort(key=lambda n: self._candidate_score(n), reverse=True)
            for target_sid in sorted(self.recovery_overloaded_shards):
                if not spare_pool:
                    break
                local_vals = new_by_shard.get(target_sid, [])
                local_edge = sum(1 for v in local_vals if v.profile == "edge")
                # Borrow a small bounded reserve. Prefer edge nodes, then
                # gateways, and never borrow more than the configured cap.
                additions = []
                for node in list(spare_pool):
                    if len(additions) >= RECOVERY_EXTRA_VALIDATORS_PER_OVERLOADED_SHARD:
                        break
                    if node.profile == "edge" or (local_edge + sum(1 for x in additions if x.profile == "edge") >= 2):
                        additions.append(node)
                for node in additions:
                    spare_pool.remove(node)
                    selected_ids.add(id(node))
                new_by_shard[target_sid] = local_vals + additions

        self.validators_by_shard = new_by_shard
        self._set_validator_flags()
        for sid, vals in self.validators_by_shard.items():
            self.shard_queues[sid].set_servers(max(1, len(vals)))
        self._refresh_aggregate_queue_model()
        return self.validators

    def record_arrivals(self, arrivals):
        """Record arrivals per shard. Accepts either a dict or a scalar."""
        if isinstance(arrivals, dict):
            for sid, n in arrivals.items():
                self.arrivals_in_window_by_shard[int(sid)] += float(max(0, n))
        else:
            # Compatibility fallback: distribute scalar arrivals evenly.
            n = float(max(0, arrivals))
            base = n / max(1, NUM_SHARDS)
            for sid in range(NUM_SHARDS):
                self.arrivals_in_window_by_shard[sid] += base

    def _compute_mu_per_server_for_shard(self, sid: int, service_mult: float = 1.0) -> float:
        vals = self.validators_by_shard.get(sid, [])
        c = max(1, len(vals))
        # Nominal service capacity is determined by the validator device class,
        # not by reputation. Reputation/Markov trust affects validator eligibility
        # and selection priority before the node enters the committee. Once selected,
        # a validator keeps its device-class service capacity.
        total_capacity = sum(
            DEVICE_PROFILES[v.profile]["capacity"]
            for v in vals
        )
        # Keep a tiny positive service rate even if a shard has no eligible validators.
        # service_mult represents shard/network degradation under attacks or load,
        # not reputation-based hardware-capacity reduction.
        mu_total = max(1e-6, total_capacity * self.MU_SCALE) * float(max(0.0, service_mult))
        return mu_total / c

    def update_queue_metrics(self, sim_t: float, service_mult: float = 1.0):
        dt = max(1e-6, sim_t - self.last_metrics_update_sim_t)
        self.last_metrics_update_sim_t = sim_t
        for sid in range(NUM_SHARDS):
            lam = self.arrivals_in_window_by_shard.get(sid, 0.0) / dt
            self.arrivals_in_window_by_shard[sid] = 0.0
            mu_per = self._compute_mu_per_server_for_shard(sid, service_mult=service_mult)
            self.shard_queues[sid].set_servers(max(1, len(self.validators_by_shard.get(sid, []))))
            self.shard_queues[sid].update_rates(lam, mu_per)
            self.shard_utilization_history[sid].append(self.shard_queues[sid].rho_raw())
        self._refresh_aggregate_queue_model()

    def refresh_service_only(self, service_mult: float = 1.0):
        for sid in range(NUM_SHARDS):
            lam = self.shard_queues[sid].lam
            mu_per = self._compute_mu_per_server_for_shard(sid, service_mult=service_mult)
            self.shard_queues[sid].set_servers(max(1, len(self.validators_by_shard.get(sid, []))))
            self.shard_queues[sid].update_rates(lam, mu_per)
        self._refresh_aggregate_queue_model()

    def rotate_validators(self, epoch: int, recovery_mode: bool = False):
        """Adaptive shard-level validator scaling.

        The previous scaling logic mainly reacted to whether each shard was
        outside the broad target band. The real-time optimized version is more
        conservative for deadlines: it scales up based on each shard's own rho,
        especially when rho approaches the unstable region, and scales down only
        slowly. This reduces max-shard overload and protects critical traffic.
        """
        self.recovery_mode = bool(recovery_mode)
        if epoch % self.rotation_interval != 0 and len(self.validators) > 0:
            return self.validators

        count_by_shard = {}
        self.recovery_overloaded_shards = set()
        any_change = False
        for sid in range(NUM_SHARDS):
            q = self.shard_queues[sid]
            lam = q.lam
            mu = q.mu
            current_c = max(0, len(self.validators_by_shard.get(sid, [])))
            rho_raw = q.rho_raw()
            c_min = self._base_count_per_shard(sid)
            c_max = self._max_count_per_shard(sid)
            if c_max <= 0:
                count_by_shard[sid] = 0
                continue

            if lam <= 1e-9 or mu <= 1e-9:
                target_c = max(current_c, c_min)
            else:
                self.utilization_history.append(rho_raw)
                # Scale up before rho reaches 1.0. Critical real-time systems
                # should react when a shard is near saturation, not after it is
                # already unstable.
                if recovery_mode and rho_raw >= RECOVERY_RHO_TRIGGER:
                    # Aggressive but bounded recovery scaling: keep a larger
                    # committee reserve on shards retaining post-attack backlog.
                    self.recovery_overloaded_shards.add(sid)
                    target_rho = RECOVERY_RHO_TARGET
                    target_c = int(math.ceil(lam / max(1e-9, target_rho * mu)))
                    new_c = int(math.ceil(max(current_c, target_c)))
                elif rho_raw >= SHARD_SCALE_UP_RHO:
                    target_rho = REALTIME_RHO_TARGET
                    target_c = int(math.ceil(lam / max(1e-9, target_rho * mu)))
                    new_c = int(round((1.0 - SCALE_UP_SMOOTHING) * current_c + SCALE_UP_SMOOTHING * target_c))
                elif rho_raw < SHARD_SCALE_DOWN_RHO:
                    # Conservative scale down to avoid oscillation and preserve
                    # a small real-time reserve.
                    target_c = int(math.ceil(lam / max(1e-9, RHO_TARGET * mu))) if lam > 0 else c_min
                    new_c = int(round((1.0 - SCALE_DOWN_SMOOTHING) * current_c + SCALE_DOWN_SMOOTHING * target_c))
                else:
                    new_c = current_c
                target_c = new_c

            # Keep a minimum reserve per shard for fast-lane critical traffic.
            reserve_floor = int(math.ceil(self._base_count_per_shard(sid) * (1.0 + CRITICAL_RESERVED_VALIDATOR_RATIO)))
            target_c = int(clamp(max(target_c, reserve_floor), c_min, c_max))
            count_by_shard[sid] = target_c
            any_change = any_change or (target_c != current_c)

        # Membership eligibility must be rechecked every epoch, even when the
        # target committee size is unchanged: a member may become MALICIOUS.
        invalid_member = any(v.state == "MALICIOUS" for v in self.validators)
        if any_change or invalid_member:
            return self.select_validators(count_by_shard=count_by_shard)
        return self.validators

    def processor_profile_weights(self, sid: int) -> dict:
        """Capacity-weighted validator profile shares for a shard.

        This is used to attribute processing throughput to the device types
        that actually execute validation/consensus work.
        """
        weights = {dev: 0.0 for dev in DEVICE_TYPES}
        vals = self.validators_by_shard.get(int(sid), [])
        bonuses = DEVICE_PROCESSING_BONUS_BY_MODE.get(self.deployment_mode, {})
        for v in vals:
            # Processing attribution is based on nominal device-class capacity.
            # Reputation was already used during validator selection; it should
            # not reduce the hardware service contribution of selected validators.
            base = DEVICE_PROFILES[v.profile]["capacity"]
            weights[v.profile] += base * float(bonuses.get(v.profile, 1.0))
        return self._apply_processor_share_caps(weights)

    def _shard_validator_device_summary(self, sid: int) -> dict:
        """Return count and capacity composition of active validators in a shard.

        Important for reporting: in this simulator validators are heterogeneous
        (gateway/edge/cloud; sensors are excluded from validator committees),
        so c_active is the number of validators while μ_total is the
        device-capacity-weighted aggregate service rate. Reputation and Markov
        trust affect eligibility/selection, not the hardware capacity of a
        selected validator. A shard with fewer edge/cloud validators can
        therefore have higher μ_total than a shard with many lower-capacity
        validators.
        """
        vals = self.validators_by_shard.get(int(sid), [])
        count_by_dev = {dev: 0 for dev in DEVICE_TYPES}
        cap_by_dev = {dev: 0.0 for dev in DEVICE_TYPES}
        bonuses = DEVICE_PROCESSING_BONUS_BY_MODE.get(self.deployment_mode, {})
        for v in vals:
            dev = v.profile if v.profile in DEVICE_TYPES else "sensor"
            count_by_dev[dev] += 1
            cap_by_dev[dev] += (
                DEVICE_PROFILES[dev]["capacity"]
                * float(bonuses.get(dev, 1.0))
            )
        total_cap = sum(cap_by_dev.values())
        cap_share = {dev: (cap_by_dev[dev] / total_cap if total_cap > 0 else 0.0) for dev in DEVICE_TYPES}
        dominant = max(DEVICE_TYPES, key=lambda d: cap_by_dev[d]) if total_cap > 0 else "none"
        out = {
            "dominant_validator_type": dominant,
            "active_validator_count": int(len(vals)),
            "validator_capacity_total_raw": float(total_cap),
        }
        for dev in DEVICE_TYPES:
            out[f"count_{dev}"] = int(count_by_dev[dev])
            out[f"capacity_share_{dev}"] = float(cap_share[dev])
        return out

    def get_shard_queue_stats(self) -> dict:
        """Return shard queue stats augmented for heterogeneous validators.

        StableMMcValidatorQueue exposes c and μ per service channel. For thesis
        reporting we add clearer fields:
        - active_validator_count: actual validators assigned to the shard
        - mu_avg_per_validator: average service rate per active validator
        - mu_total_capacity: aggregate nominal service capacity of the shard
        - dominant_validator_type and device composition fields
        """
        stats = {}
        for sid in range(NUM_SHARDS):
            s = dict(self.shard_queues[sid].get_stats())
            c_active = len(self.validators_by_shard.get(sid, []))
            mu_avg = float(s.get("mu", 0.0)) if c_active > 0 else 0.0
            s.update({
                "c_active": int(c_active),
                "active_validator_count": int(c_active),
                "mu_avg_per_validator": mu_avg,
                "mu_total_capacity": mu_avg * max(0, c_active),
            })
            s.update(self._shard_validator_device_summary(sid))
            stats[sid] = s
        return stats

    def _refresh_aggregate_queue_model(self):
        total_lam = sum(q.lam for q in self.shard_queues.values())
        total_c = sum(max(1, len(self.validators_by_shard.get(sid, []))) for sid in range(NUM_SHARDS))
        total_mu_capacity = 0.0
        for sid, q in self.shard_queues.items():
            c = max(1, len(self.validators_by_shard.get(sid, [])))
            total_mu_capacity += c * q.mu
        mu_per_agg = total_mu_capacity / max(1, total_c)
        self.queue_model.set_servers(max(1, total_c))
        self.queue_model.update_rates(total_lam, mu_per_agg)

    def get_aggregate_queue_stats(self) -> dict:
        shard_stats = self.get_shard_queue_stats()
        agg = self.queue_model.get_stats()
        rhos = [s.get("rho", 0.0) for s in shard_stats.values()]
        wqs = [s.get("Wq_s", 0.0) for s in shard_stats.values()]
        lqs = [s.get("Lq", 0.0) for s in shard_stats.values()]
        lambdas = [s.get("lambda", 0.0) for s in shard_stats.values()]
        total_lam = sum(lambdas)
        weighted_wq = sum(w * x for w, x in zip(lambdas, wqs)) / max(1e-9, total_lam)
        weighted_lq = sum(lqs)
        agg.update({
            "scope": "aggregate_of_shard_level_mmc",
            "num_shards": NUM_SHARDS,
            "shards": shard_stats,
            "avg_shard_rho": safe_mean(rhos),
            "max_shard_rho": max(rhos) if rhos else 0.0,
            "min_shard_rho": min(rhos) if rhos else 0.0,
            "overloaded_shards": int(sum(1 for r in rhos if r >= 1.0)),
            "avg_shard_Wq_s": safe_mean(wqs),
            "weighted_Wq_s": weighted_wq,
            "sum_shard_Lq": weighted_lq,
        })
        return agg

# ============================================================
# SECURITY MONITOR
# ============================================================
class SecurityMonitor:
    def __init__(self, nodes):
        self.nodes = nodes

    def threat_level(self) -> float:
        malicious = sum(1 for n in self.nodes if n.state == "MALICIOUS")
        risky = sum(1 for n in self.nodes if n.state == "RISKY")
        total = max(1, len(self.nodes))
        return (malicious * 0.7 + risky * 0.3) / total

    def state_distribution(self) -> dict:
        counts = {s: 0 for s in TRUST_STATES}
        for n in self.nodes:
            counts[n.state if n.state in counts else "NEUTRAL"] += 1
        total = max(1, len(self.nodes))
        return {s: counts[s] / total for s in TRUST_STATES}

# ============================================================
# MARKOV TRUST MODEL
# ============================================================
class MarkovTrustModel:
    """
    Finite-state discrete-time Markov trust process for validators.

    The model starts from P_BASE, then modulates the current-state transition
    row using three epoch-level evidence sources:
    1) performance quality,
    2) security exposure / attack intensity,
    3) consensus participation outcome.
    """
    def __init__(self, nodes):
        self.nodes = nodes
        self.state_to_idx = {s: i for i, s in enumerate(TRUST_STATES)}
        self.empirical_transition_counts = np.zeros((len(TRUST_STATES), len(TRUST_STATES)), dtype=float)
        self.epoch_transition_counts = np.zeros_like(self.empirical_transition_counts)
        self.state_distribution_history = []
        self.effective_transition_history = []
        self.kl_to_stationary_history = []
        self.stationary_ref = self.stationary_distribution_vector()
        audit_seed = int(hashlib.sha256(repr(random.getstate()).encode()).hexdigest()[:16], 16)
        self.audit_rng = random.Random(audit_seed)
        self.audit_transition_counts = np.zeros_like(self.empirical_transition_counts)
        self.audit_epoch = 0
        self.audit_events_total = 0
        self.audit_pass_total = 0
        self.audit_rehabilitations_total = 0
        self.active_transition_total = 0
        self.active_malicious_exclusions_total = 0
        self.audit_history = []

    def _normalize(self, probs):
        probs = np.asarray(probs, dtype=float)
        probs = np.clip(probs, MARKOV_EPS, None)
        return probs / np.sum(probs)

    def stationary_distribution_vector(self, max_iter=10000, tol=1e-12):
        pi = np.ones(len(TRUST_STATES), dtype=float) / len(TRUST_STATES)
        for _ in range(max_iter):
            new_pi = pi @ P_BASE
            if np.linalg.norm(new_pi - pi, ord=1) < tol:
                return self._normalize(new_pi)
            pi = new_pi
        return self._normalize(pi)

    def _performance_quality(self, node: IoTNode) -> float:
        rep = clamp(node.reputation / 100.0, 0.0, 1.0)
        val = clamp(node.validator_score / 100.0, 0.0, 1.0)
        hw = clamp(DEVICE_PROFILES[node.profile]["capacity"] / 2000.0, 0.0, 1.0)
        return clamp(0.45 * rep + 0.45 * val + 0.10 * hw, 0.0, 1.0)

    def _apply_performance_modulation(self, probs, q: float):
        probs = probs.copy()
        # q > 0.5 moves probability mass toward favorable states; q < 0.5 moves it toward adverse states.
        delta = clamp(q - 0.5, -0.5, 0.5)
        probs[0] += 0.10 * delta       # TRUSTED
        probs[1] += 0.04 * delta       # NEUTRAL
        probs[2] -= 0.06 * delta       # RISKY
        probs[3] -= 0.08 * delta       # MALICIOUS
        return self._normalize(probs)

    def _apply_security_modulation(self, probs, attack_intensity: float, node: IoTNode):
        probs = probs.copy()
        a = clamp(float(attack_intensity), 0.0, 1.0)
        # Balanced Markov behavior:
        # attack intensity degrades trust, but normal/stable workloads should not
        # accumulate a large MALICIOUS population merely because many epochs pass.
        a_eff = a ** 1.20
        probs[0] -= 0.070 * a_eff      # TRUSTED
        probs[1] -= 0.030 * a_eff      # NEUTRAL
        probs[2] += 0.060 * a_eff      # RISKY
        probs[3] += 0.040 * a_eff      # MALICIOUS
        if getattr(node, "ddos_affected", False):
            probs[0] -= 0.015
            probs[2] += 0.010
            probs[3] += 0.005
        return self._normalize(probs)

    def _apply_consensus_modulation(self, probs, consensus_success: bool):
        probs = probs.copy()
        if consensus_success:
            probs[0] += 0.030
            probs[1] += 0.012
            probs[2] -= 0.020
            probs[3] -= 0.022
        else:
            # A single missed consensus should mainly increase RISKY suspicion;
            # MALICIOUS should require repeated or attack-driven evidence.
            probs[0] -= 0.025
            probs[1] -= 0.008
            probs[2] += 0.023
            probs[3] += 0.010
        return self._normalize(probs)

    def _apply_recovery_modulation(self, probs, current_state: str, q: float, attack_intensity: float):
        """Evidence-driven recovery in low/no-attack periods.

        This is a guard against unrealistically high MALICIOUS ratios in stable
        workloads. Recovery is intentionally limited: suspicious validators are
        not immediately restored to TRUSTED; they first move through RISKY/NEUTRAL.
        """
        probs = probs.copy()
        a = clamp(float(attack_intensity), 0.0, 1.0)

        if a <= 0.05:
            if current_state == "TRUSTED":
                removed = probs[3] * 0.60 + probs[2] * 0.20
                probs[3] *= 0.40
                probs[2] *= 0.80
                probs[0] += removed * 0.70
                probs[1] += removed * 0.30
            elif current_state == "NEUTRAL":
                removed = probs[3] * 0.45 + probs[2] * 0.10
                probs[3] *= 0.55
                probs[2] *= 0.90
                probs[0] += removed * 0.30
                probs[1] += removed * 0.70
            elif current_state == "RISKY" and q >= 0.50:
                removed = probs[3] * 0.30 + probs[2] * 0.08
                probs[3] *= 0.70
                probs[2] *= 0.92
                probs[0] += removed * 0.20
                probs[1] += removed * 0.80
            elif current_state == "MALICIOUS" and q >= 0.45:
                removed = probs[3] * 0.25
                probs[3] *= 0.75
                probs[2] += removed * 0.55
                probs[1] += removed * 0.35
                probs[0] += removed * 0.10
        elif a <= 0.50 and current_state in ("TRUSTED", "NEUTRAL"):
            removed = probs[3] * 0.20
            probs[3] *= 0.80
            probs[2] += removed * 0.70
            probs[1] += removed * 0.30

        return self._normalize(probs)

    def update_validator_states(self, validators, attack_intensity: float = 0.0):
        self.epoch_transition_counts = np.zeros_like(self.empirical_transition_counts)
        a = clamp(attack_intensity, 0.0, 1.0)
        for node in validators:
            current_state = node.state if node.state in self.state_to_idx else "NEUTRAL"
            old_idx = self.state_to_idx[current_state]
            probs = P_BASE[old_idx].copy()

            q = self._performance_quality(node)
            consensus_success_prob = clamp(0.82 + 0.14 * q - 0.25 * a, 0.58, 0.975)
            consensus_success = random.random() < consensus_success_prob
            node.ddos_affected = bool(a > 0 and random.random() < 0.10 * a)

            probs = self._apply_performance_modulation(probs, q)
            probs = self._apply_security_modulation(probs, a, node)
            probs = self._apply_consensus_modulation(probs, consensus_success)
            probs = self._apply_recovery_modulation(probs, current_state, q, a)

            new_state = random.choices(TRUST_STATES, weights=probs, k=1)[0]
            new_idx = self.state_to_idx[new_state]
            node.state = new_state
            self.empirical_transition_counts[old_idx, new_idx] += 1.0
            self.epoch_transition_counts[old_idx, new_idx] += 1.0
            self.active_transition_total += 1
            self._update_scores_from_state(node, new_state, consensus_success, attack_intensity)

        self._record_epoch_diagnostics()

    def audit_inactive_candidates(self, active_validators, attack_intensity: float = 0.0):
        """Independent simulated compliance audits, not fabricated consensus outcomes.

        Non-validator sensor devices are outside the validator-trust population.
        Inactive gateway/edge/cloud candidates are audited every configured interval.
        Reentry requires a successful audit and advances at most one trust tier.
        Other inactive states are held, not subjected to fake consensus updates.
        """
        self.audit_epoch += 1
        active_ids = {n.id for n in active_validators}
        events = successes = rehabilitations = 0
        if self.audit_epoch % INACTIVE_AUDIT_INTERVAL_EPOCHS == 0:
            a = clamp(float(attack_intensity), 0.0, 1.0)
            recovery_step = {
                "MALICIOUS": "RISKY", "RISKY": "NEUTRAL",
                "NEUTRAL": "TRUSTED", "TRUSTED": "TRUSTED",
            }
            for node in self.nodes:
                if node.profile not in VALIDATOR_DEVICE_TYPES or node.id in active_ids:
                    continue
                events += 1
                old_audit_state_idx = self.state_to_idx[node.state]
                q = self._performance_quality(node)
                # Audit outcome is an assumed exogenous signal, not a measured event.
                pass_prob = clamp(
                    INACTIVE_AUDIT_PASS_BASE
                    + INACTIVE_AUDIT_PASS_QUALITY_GAIN * q
                    - INACTIVE_AUDIT_ATTACK_PENALTY * a, 0.0, 1.0
                )
                audit_pass = self.audit_rng.random() < pass_prob
                if audit_pass:
                    successes += 1
                    if node.state != "TRUSTED" and self.audit_rng.random() < INACTIVE_AUDIT_RECOVERY_PROB:
                        next_state = recovery_step[node.state]
                        node.state = next_state
                        rehabilitations += 1
                        # Audit cannot be confused with successful consensus evidence.
                        node.reputation = clamp(node.reputation + 0.25, 0, 100)
                        node.validator_score = clamp(node.validator_score + 0.25, 0, 100)
                # Record a separate audit transition, including unchanged states.
                self.audit_transition_counts[
                    old_audit_state_idx, self.state_to_idx[node.state]
                ] += 1
                # Failed audit is NOT assumed to prove a malicious attack.
        # Update the per-epoch population diagnostics to include scheduled audits,
        # without mixing audit transitions into active-consensus transition counts.
        if self.state_distribution_history:
            self.state_distribution_history.pop()
            self.effective_transition_history.pop()
            self.kl_to_stationary_history.pop()
        self._record_epoch_diagnostics()
        self.audit_events_total += events
        self.audit_pass_total += successes
        self.audit_rehabilitations_total += rehabilitations
        self.audit_history.append({
            "epoch": self.audit_epoch, "audited": events,
            "audit_pass": successes, "rehabilitations": rehabilitations,
            "inactive_candidates": sum(
                n.profile in VALIDATOR_DEVICE_TYPES and n.id not in active_ids
                for n in self.nodes
            ),
        })

    def _update_scores_from_state(self, node: IoTNode, state: str, consensus_success: bool, attack_intensity: float):
        a = clamp(float(attack_intensity), 0.0, 1.0)
        if state == "TRUSTED":
            node.reputation = clamp(node.reputation + random.uniform(0.20, 1.00), 0, 100)
            node.validator_score = clamp(node.validator_score + random.uniform(0.20, 0.80), 0, 100)
        elif state == "NEUTRAL":
            node.reputation = clamp(node.reputation + random.uniform(-0.30, 0.30), 0, 100)
            node.validator_score = clamp(node.validator_score + random.uniform(-0.30, 0.30), 0, 100)
        elif state == "RISKY":
            node.reputation = clamp(node.reputation - random.uniform(0.35, 1.10) * (1.0 + 0.8 * a), 0, 100)
            node.validator_score = clamp(node.validator_score - random.uniform(0.30, 0.95) * (1.0 + 0.8 * a), 0, 100)
        elif state == "MALICIOUS":
            node.reputation = clamp(node.reputation - random.uniform(1.00, 2.80) * (1.0 + 1.0 * a), 0, 100)
            node.validator_score = clamp(node.validator_score - random.uniform(1.00, 2.80) * (1.0 + 1.0 * a), 0, 100)
        if not consensus_success:
            node.validator_score = clamp(node.validator_score - random.uniform(0.15, 0.60), 0, 100)

    def _record_epoch_diagnostics(self):
        dist = self.current_state_distribution()
        self.state_distribution_history.append(dist)
        self.effective_transition_history.append(self.get_effective_transition_matrix(epoch_only=True))
        pi = np.array([dist[s] for s in TRUST_STATES], dtype=float)
        pi = self._normalize(pi)
        ref = self._normalize(self.stationary_ref + MARKOV_EPS)
        kl = float(np.sum(pi * np.log((pi + MARKOV_EPS) / ref)))
        self.kl_to_stationary_history.append(kl)

    def current_state_distribution(self) -> dict:
        counts = {s: 0 for s in TRUST_STATES}
        for node in self.nodes:
            state = node.state if node.state in counts else "NEUTRAL"
            counts[state] += 1
        total = max(1, len(self.nodes))
        return {s: counts[s] / total for s in TRUST_STATES}

    def get_effective_transition_matrix(self, epoch_only: bool = False):
        counts = self.epoch_transition_counts if epoch_only else self.empirical_transition_counts
        row_sums = counts.sum(axis=1, keepdims=True)
        return np.divide(counts, row_sums, out=np.zeros_like(counts), where=row_sums > 0)

    def stationary_distribution(self) -> dict:
        return {s: float(v) for s, v in zip(TRUST_STATES, self.stationary_ref)}

# ============================================================
# ATTACK CAMPAIGN
# ============================================================
class AttackCampaign:
    """
    Event-driven attack campaign with explicit simulation of seven attack types.

    Every attack vector records: attempts, detected attempts, mitigated attempts,
    and successful attempts. A resistance score is derived only from simulated
    events: 1 - successful_attempts / total_attempts.

    The model is intentionally comparative and simulation-based. It does not
    claim to reproduce a production blockchain threat model; instead it gives
    each attack a distinct workload/service/latency/energy effect and a linked
    mitigation mechanism grounded in the framework's trust-aware committee
    selection, diversity caps, and finality logic.
    """
    def __init__(self, start_epoch=ATTACK_START_EPOCH, end_epoch=ATTACK_END_EPOCH):
        self.start_epoch = int(start_epoch)
        self.end_epoch = int(end_epoch)
        self.vectors = [
            "sybil", "ddos", "eclipse", "collusion",
            "selfish_mining", "bribery", "long_range",
        ]
        self.truth_attack_epoch_flags = []
        self.last_attack_active = False
        self.last_attack_intensity = 0.0
        self.last_effects = self._neutral_effects()
        self.attack_metrics = {"total_launched": 0, "total_success": 0}
        for vec in self.vectors:
            self.attack_metrics.update({
                f"{vec}_attempts": 0,
                f"{vec}_success": 0,
                f"{vec}_detected": 0,
                f"{vec}_mitigated": 0,
            })

    @staticmethod
    def _neutral_effects():
        return {
            "arrival_mult": 1.0,
            "service_mult": 1.0,
            "latency_mult": 1.0,
            "power_mult": 1.0,
            "active_vectors": [],
            "detected_vectors": [],
            "mitigated_vectors": [],
            "successful_vectors": [],
        }

    def _security_context(self, validators):
        validators = list(validators or [])
        if not validators:
            return {
                "trusted_frac": 0.0, "malicious_frac": 0.0,
                "avg_rep": 0.0, "diversity": 0.0, "edge_frac": 0.0,
                "committee_size": 0,
            }
        n = len(validators)
        trusted = sum(1 for v in validators if v.state == "TRUSTED") / n
        malicious = sum(1 for v in validators if v.state == "MALICIOUS") / n
        avg_rep = safe_mean([v.reputation / 100.0 for v in validators])
        counts = defaultdict(int)
        for v in validators:
            counts[v.profile] += 1
        shares = [c / n for c in counts.values()]
        diversity = 1.0 - sum(s * s for s in shares)  # Simpson diversity
        edge_frac = counts.get("edge", 0) / n
        return {
            "trusted_frac": clamp(trusted, 0.0, 1.0),
            "malicious_frac": clamp(malicious, 0.0, 1.0),
            "avg_rep": clamp(avg_rep, 0.0, 1.0),
            "diversity": clamp(diversity, 0.0, 1.0),
            "edge_frac": clamp(edge_frac, 0.0, 1.0),
            "committee_size": n,
        }

    def _detect_probability(self, vec, ctx):
        # Detection is driven by trust quality, committee diversity, and the
        # security monitor's threat visibility. Different vectors expose
        # different observable evidence in this simulation.
        base = {
            "sybil": 0.88,
            "ddos": 0.84,
            "eclipse": 0.79,
            "collusion": 0.76,
            "selfish_mining": 0.74,
            "bribery": 0.72,
            "long_range": 0.90,
        }[vec]
        p = base + 0.10 * ctx["trusted_frac"] + 0.07 * ctx["diversity"] + 0.05 * ctx["avg_rep"]
        p -= 0.16 * ctx["malicious_frac"]
        return clamp(p, 0.45, 0.99)

    def _base_success_probability(self, vec, ctx):
        # Threat-specific base probability before detection/mitigation.
        base = {
            "sybil": 0.21,
            "ddos": 0.25,
            "eclipse": 0.24,
            "collusion": 0.20,
            "selfish_mining": 0.18,
            "bribery": 0.19,
            "long_range": 0.15,
        }[vec]
        # A larger malicious fraction increases attack opportunity, while
        # trust and committee diversity reduce it.
        p = base + 0.20 * ctx["malicious_frac"] - 0.10 * ctx["trusted_frac"] - 0.08 * ctx["diversity"]
        return clamp(p, 0.03, 0.45)

    def _apply_effect(self, vec, detected, mitigated, success, compromised_nodes):
        """Return attack effects. Mitigation reduces but does not necessarily erase cost."""
        # Baseline disturbance occurs whenever an attack is launched, whereas
        # successful undetected attempts create the larger system-level impact.
        effect_scale = 1.0
        if detected:
            effect_scale *= 0.55
        if mitigated:
            effect_scale *= 0.50
        if success and not mitigated:
            effect_scale *= 1.35

        a = {"arrival_mult": 1.0, "service_mult": 1.0, "latency_mult": 1.0, "power_mult": 1.0}
        if vec == "ddos":
            a["arrival_mult"] *= 1.0 + 0.26 * effect_scale
            a["latency_mult"] *= 1.0 + 0.13 * effect_scale
            a["power_mult"] *= 1.0 + 0.11 * effect_scale
        elif vec == "eclipse":
            a["service_mult"] *= max(0.70, 1.0 - 0.18 * effect_scale)
            a["latency_mult"] *= 1.0 + 0.18 * effect_scale
            a["power_mult"] *= 1.0 + 0.09 * effect_scale
        elif vec == "sybil":
            a["latency_mult"] *= 1.0 + 0.09 * effect_scale
            a["power_mult"] *= 1.0 + 0.08 * effect_scale
        elif vec == "collusion":
            a["service_mult"] *= max(0.74, 1.0 - 0.14 * effect_scale)
            a["latency_mult"] *= 1.0 + 0.10 * effect_scale
            a["power_mult"] *= 1.0 + 0.06 * effect_scale
        elif vec == "selfish_mining":
            # Block withholding / delayed publication primarily increases
            # consensus and finalization delay, represented here by latency.
            a["service_mult"] *= max(0.80, 1.0 - 0.10 * effect_scale)
            a["latency_mult"] *= 1.0 + 0.16 * effect_scale
            a["power_mult"] *= 1.0 + 0.07 * effect_scale
        elif vec == "bribery":
            # A successful bribery event temporarily weakens a subset of
            # selected validators through score/reputation penalties.
            a["service_mult"] *= max(0.82, 1.0 - 0.09 * effect_scale)
            a["latency_mult"] *= 1.0 + 0.12 * effect_scale
            a["power_mult"] *= 1.0 + 0.06 * effect_scale
            if success and not mitigated:
                for node in compromised_nodes:
                    node.validator_score = clamp(node.validator_score - random.uniform(4.0, 9.0), 0, 100)
                    node.reputation = clamp(node.reputation - random.uniform(2.0, 6.0), 0, 100)
                    if random.random() < 0.35:
                        node.state = "RISKY"
        elif vec == "long_range":
            # Finality checkpoints limit this attack. Any remaining effect is
            # modeled as re-validation/finality overhead rather than a rewrite
            # of the transaction history itself.
            a["latency_mult"] *= 1.0 + 0.14 * effect_scale
            a["power_mult"] *= 1.0 + 0.10 * effect_scale
        return a

    def step(self, epoch: int, validators=None) -> dict:
        self.last_attack_active = False
        self.last_attack_intensity = 0.0
        self.last_effects = self._neutral_effects()
        self.truth_attack_epoch_flags.append(False)

        if epoch < self.start_epoch or epoch > self.end_epoch:
            return {"intensity": 0.0, **self.last_effects}

        self.truth_attack_epoch_flags[-1] = True
        self.last_attack_active = True
        ctx = self._security_context(validators)
        # One or two concurrent threats maintain continuity with the original
        # experiment while allowing all seven vectors to be sampled over time.
        active = random.sample(self.vectors, random.randint(1, 2))
        effects = self._neutral_effects()
        success_count = 0

        for vec in active:
            self.attack_metrics["total_launched"] += 1
            self.attack_metrics[f"{vec}_attempts"] += 1

            detected = random.random() < self._detect_probability(vec, ctx)
            mitigated = detected and (random.random() < clamp(0.80 + 0.10 * ctx["trusted_frac"], 0.65, 0.97))
            if detected:
                self.attack_metrics[f"{vec}_detected"] += 1
                effects["detected_vectors"].append(vec)
            if mitigated:
                self.attack_metrics[f"{vec}_mitigated"] += 1
                effects["mitigated_vectors"].append(vec)

            p_success = self._base_success_probability(vec, ctx)
            if detected:
                p_success *= 0.45
            if mitigated:
                p_success *= 0.25
            success = random.random() < p_success
            if success:
                success_count += 1
                self.attack_metrics["total_success"] += 1
                self.attack_metrics[f"{vec}_success"] += 1
                effects["successful_vectors"].append(vec)

            # Bribery selects a small set of currently active validators.
            compromised_nodes = []
            if vec == "bribery" and validators:
                n_target = max(1, min(len(validators), int(math.ceil(0.08 * len(validators)))))
                compromised_nodes = random.sample(list(validators), n_target)

            e = self._apply_effect(vec, detected, mitigated, success, compromised_nodes)
            for key in ("arrival_mult", "service_mult", "latency_mult", "power_mult"):
                effects[key] *= e[key]
            effects["active_vectors"].append(vec)

        # Clamp compounding effects to retain a controlled and interpretable
        # stress scenario rather than creating unbounded synthetic collapse.
        effects["arrival_mult"] = clamp(effects["arrival_mult"], 1.0, 1.75)
        effects["service_mult"] = clamp(effects["service_mult"], 0.55, 1.0)
        effects["latency_mult"] = clamp(effects["latency_mult"], 1.0, 2.00)
        effects["power_mult"] = clamp(effects["power_mult"], 1.0, 1.70)

        intensity = clamp(0.18 * len(active) + 0.18 * success_count + 0.08 * len(effects["detected_vectors"]), 0.0, 1.0)
        self.last_attack_intensity = intensity
        self.last_effects = effects
        return {"intensity": intensity, **effects}

    def get_resistance_metrics(self):
        def resistance(vec):
            att = self.attack_metrics.get(f"{vec}_attempts", 0)
            suc = self.attack_metrics.get(f"{vec}_success", 0)
            return 1.0 - (suc / att) if att > 0 else 1.0
        return {f"{vec}_resistance": resistance(vec) for vec in self.vectors}

    def get_event_summary(self):
        rows = []
        for vec in self.vectors:
            att = int(self.attack_metrics.get(f"{vec}_attempts", 0))
            suc = int(self.attack_metrics.get(f"{vec}_success", 0))
            det = int(self.attack_metrics.get(f"{vec}_detected", 0))
            mit = int(self.attack_metrics.get(f"{vec}_mitigated", 0))
            rows.append({
                "attack": vec,
                "attempts": att,
                "successful": suc,
                "detected": det,
                "mitigated": mit,
                "resistance": 1.0 - (suc / att) if att > 0 else 1.0,
                "detection_rate": det / att if att > 0 else 0.0,
                "mitigation_rate": mit / att if att > 0 else 0.0,
            })
        return rows

# ============================================================
# TRANSACTIONS WITH REAL-TIME DEADLINE ENFORCEMENT
# ============================================================
class RealisticTransactionSystem:
    """
    Shard-level, priority-aware transaction subsystem with deadline expiration.

    Real-time optimized version:
    - load-aware shard routing using a power-of-two-choices heuristic,
    - a critical fast lane that reduces queueing and processing overhead,
    - EDF-compatible ordering within each priority queue (FIFO is EDF when all
      transactions of the same priority share the same relative deadline),
    - explicit timing decomposition into queue, service, consensus, and
      confirmation components.
    """
    def __init__(self):
        self.backlog = {sid: {p: deque() for p in PRIORITY_LEVELS} for sid in range(NUM_SHARDS)}
        self.last_arrivals_by_shard = {sid: 0 for sid in range(NUM_SHARDS)}
        # Dynamic routing pressure is supplied by the framework from the most
        # recent shard M/M/c state. It allows post-attack traffic to avoid
        # shards with residual utilization/backlog instead of considering only
        # raw queue length.
        self.shard_routing_pressure = {sid: 0.0 for sid in range(NUM_SHARDS)}
        self.last_generated_by_priority_shard = {
            sid: {p: 0 for p in PRIORITY_LEVELS} for sid in range(NUM_SHARDS)
        }
        self.metrics = {
            "tx_generated": 0,
            "tx_processed": 0,
            "tx_expired": 0,
            "deadline_misses": 0,
            "total_latency_s": 0.0,
            "total_freshness_score": 0.0,
            "priority_tx_generated": {p: 0 for p in PRIORITY_LEVELS},
            "priority_tx_processed": {p: 0 for p in PRIORITY_LEVELS},
            "priority_tx_expired": {p: 0 for p in PRIORITY_LEVELS},
            "priority_latency_s": {p: [] for p in PRIORITY_LEVELS},
            "priority_freshness_score": {p: 0.0 for p in PRIORITY_LEVELS},
            "shard_tx_generated": {sid: 0 for sid in range(NUM_SHARDS)},
            "shard_tx_processed": {sid: 0 for sid in range(NUM_SHARDS)},
            "shard_tx_expired": {sid: 0 for sid in range(NUM_SHARDS)},
            # Device-level throughput accounting.
            # source_*: device class that generated the transaction.
            # processor_*: validator device class that processed/confirmed it.
            "source_tx_generated": {dev: 0 for dev in DEVICE_TYPES},
            "source_tx_processed": {dev: 0 for dev in DEVICE_TYPES},
            "source_tx_expired": {dev: 0 for dev in DEVICE_TYPES},
            "processor_tx_processed": {dev: 0 for dev in DEVICE_TYPES},
            # Timing decomposition for thesis/report tables.
            "queue_wait_s_total": 0.0,
            "service_time_s_total": 0.0,
            "consensus_time_s_total": 0.0,
            "finalization_time_s_total": 0.0,
            "priority_queue_wait_s": {p: 0.0 for p in PRIORITY_LEVELS},
            "priority_service_time_s": {p: 0.0 for p in PRIORITY_LEVELS},
            "priority_consensus_time_s": {p: 0.0 for p in PRIORITY_LEVELS},
            "priority_finalization_time_s": {p: 0.0 for p in PRIORITY_LEVELS},
        }

    @staticmethod
    def _normalize_count_dict(counts: dict) -> dict:
        return {dev: int(max(0, counts.get(dev, 0))) for dev in DEVICE_TYPES}

    @staticmethod
    def _allocate_by_weights(total_count: int, weights: dict) -> dict:
        """Deterministically allocate an integer count according to weights."""
        total_count = int(max(0, total_count))
        weights = {dev: float(max(0.0, weights.get(dev, 0.0))) for dev in DEVICE_TYPES}
        wsum = sum(weights.values())
        if total_count <= 0:
            return {dev: 0 for dev in DEVICE_TYPES}
        if wsum <= 0:
            weights = {dev: 1.0 / len(DEVICE_TYPES) for dev in DEVICE_TYPES}
            wsum = 1.0
        raw = {dev: total_count * weights[dev] / wsum for dev in DEVICE_TYPES}
        out = {dev: int(math.floor(raw[dev])) for dev in DEVICE_TYPES}
        remainder = total_count - sum(out.values())
        order = sorted(DEVICE_TYPES, key=lambda d: raw[d] - out[d], reverse=True)
        for dev in order[:remainder]:
            out[dev] += 1
        return out

    @staticmethod
    def _subtract_count_dict(base: dict, used: dict):
        for dev in DEVICE_TYPES:
            base[dev] = int(max(0, base.get(dev, 0) - used.get(dev, 0)))

    def pending_count(self, priority: str = None, shard_id: int = None) -> int:
        if shard_id is not None:
            sid = int(shard_id)
            if priority is not None:
                return int(sum(int(entry[1]) for entry in self.backlog[sid][priority]))
            return int(sum(sum(int(entry[1]) for entry in self.backlog[sid][p]) for p in PRIORITY_LEVELS))
        if priority is not None:
            return int(sum(sum(count for _, count in self.backlog[sid][priority]) for sid in range(NUM_SHARDS)))
        return int(sum(self.pending_count(shard_id=sid) for sid in range(NUM_SHARDS)))

    def set_shard_routing_pressure(self, pressure_by_shard: dict):
        for sid in range(NUM_SHARDS):
            self.shard_routing_pressure[sid] = float(max(0.0, pressure_by_shard.get(sid, 0.0)))

    def _shard_load_score(self, sid: int, extra_alloc=None) -> float:
        extra = 0 if extra_alloc is None else int(extra_alloc.get(sid, 0))
        return float(
            self.pending_count(shard_id=sid)
            + self.last_arrivals_by_shard.get(sid, 0)
            + extra
            + self.shard_routing_pressure.get(sid, 0.0)
        )

    def _route_priority_count(self, priority: str, count: int, current_time_s: float, source_profile: str = 'sensor'):
        """Route transactions to shards using load-aware power-of-two choices."""
        count = int(max(0, count))
        if count <= 0:
            return

        if not LOAD_AWARE_SHARD_ROUTING:
            splits = np.random.multinomial(count, [1.0 / NUM_SHARDS] * NUM_SHARDS)
            for sid, k in enumerate(splits):
                self._append_arrival(sid, priority, int(k), current_time_s, source_profile=source_profile)
            return

        remaining = count
        planned_extra = defaultdict(int)
        while remaining > 0:
            chunk = min(ROUTING_CHUNK_SIZE, remaining)
            choices = random.sample(range(NUM_SHARDS), k=min(POWER_OF_TWO_CHOICES, NUM_SHARDS))
            # Critical traffic is more sensitive to existing critical backlog;
            # lower-priority traffic can use total backlog.
            if priority == "CRITICAL":
                sid = min(
                    choices,
                    key=lambda s: self.pending_count("CRITICAL", shard_id=s) + 0.25 * self.pending_count(shard_id=s) + planned_extra[s] + self.shard_routing_pressure.get(s, 0.0)
                )
            else:
                sid = min(choices, key=lambda s: self._shard_load_score(s, planned_extra))
            planned_extra[sid] += chunk
            remaining -= chunk

        for sid, k in planned_extra.items():
            self._append_arrival(int(sid), priority, int(k), current_time_s, source_profile=source_profile)

    def _append_arrival(self, sid: int, priority: str, count: int, current_time_s: float, source_profile: str = "sensor"):
        count = int(max(0, count))
        if count <= 0:
            return
        sid = int(sid)
        source_profile = source_profile if source_profile in DEVICE_TYPES else "sensor"
        source_counts = {dev: 0 for dev in DEVICE_TYPES}
        source_counts[source_profile] = count
        q = self.backlog[sid][priority]
        # Coalesce same-epoch arrivals to avoid thousands of tiny queue batches.
        if q and abs(float(q[-1][0]) - float(current_time_s)) < 1e-12:
            q[-1][1] += count
            if len(q[-1]) < 3:
                q[-1].append({dev: 0 for dev in DEVICE_TYPES})
            for dev in DEVICE_TYPES:
                q[-1][2][dev] = int(q[-1][2].get(dev, 0) + source_counts.get(dev, 0))
        else:
            q.append([float(current_time_s), count, source_counts])
        self.last_arrivals_by_shard[sid] += count
        self.last_generated_by_priority_shard[sid][priority] += count
        self.metrics["priority_tx_generated"][priority] += count
        self.metrics["shard_tx_generated"][sid] += count
        self.metrics["source_tx_generated"][source_profile] += count

    def generate_transactions(self, offered_tps: float, current_time_s: float) -> int:
        n = int(offered_tps * EPOCH_DURATION)
        n = int(min(n, MAX_TX_PER_EPOCH))
        self.last_arrivals_by_shard = {sid: 0 for sid in range(NUM_SHARDS)}
        self.last_generated_by_priority_shard = {
            sid: {p: 0 for p in PRIORITY_LEVELS} for sid in range(NUM_SHARDS)
        }
        if n <= 0:
            return 0

        priorities = list(PRIORITY_CONFIG.keys())
        p_weights = [PRIORITY_CONFIG[p]["weight"] for p in priorities]
        source_types = DEVICE_TYPES
        s_weights = [DEVICE_SOURCE_WEIGHTS[d] for d in source_types]
        source_splits = np.random.multinomial(n, s_weights)

        for source_profile, source_n in zip(source_types, source_splits):
            source_n = int(source_n)
            if source_n <= 0:
                continue
            prio_splits = np.random.multinomial(source_n, p_weights)
            for p, k in zip(priorities, prio_splits):
                self._route_priority_count(p, int(k), current_time_s, source_profile=source_profile)

        self.metrics["tx_generated"] += int(n)
        return int(n)

    def _expire_batch(self, priority: str, count: int, shard_id: int = None, source_counts: dict = None):
        count = int(max(0, count))
        if count <= 0:
            return
        self.metrics["tx_expired"] += count
        self.metrics["deadline_misses"] += count
        self.metrics["priority_tx_expired"][priority] += count
        if shard_id is not None:
            self.metrics["shard_tx_expired"][int(shard_id)] += count
        if source_counts is not None:
            for dev in DEVICE_TYPES:
                self.metrics["source_tx_expired"][dev] += int(source_counts.get(dev, 0))

    def expire_transactions(self, current_time_s: float, shard_id: int = None) -> int:
        expired_total = 0
        shard_ids = [int(shard_id)] if shard_id is not None else list(range(NUM_SHARDS))
        for sid in shard_ids:
            for p in PRIORITY_LEVELS:
                deadline = float(PRIORITY_CONFIG[p]["deadline"])
                q = self.backlog[sid][p]
                while q:
                    entry = q[0]
                    arrival_time, count = entry[0], int(entry[1])
                    source_counts = entry[2] if len(entry) >= 3 else {"sensor": count}
                    if float(current_time_s) - float(arrival_time) <= deadline:
                        break
                    q.popleft()
                    expired_total += int(count)
                    self._expire_batch(p, int(count), shard_id=sid, source_counts=source_counts)
        return expired_total

    def _priority_processing_components(self, priority: str, queue_Wq_s: float, latency_mult: float):
        """Return queue, service, consensus and finalization components."""
        queue_wait = min(float(queue_Wq_s), 0.3)
        base_proc = float(PRIORITY_CONFIG[priority]["base_proc_s"])
        consensus_delay = float(CONSENSUS_DELAY_BY_PRIORITY.get(priority, 0.002))
        finalization_delay = 0.0004 if priority == "CRITICAL" else 0.0006

        if FAST_LANE_ENABLED and priority == "CRITICAL":
            queue_wait *= CRITICAL_FAST_LANE_WQ_FACTOR
            service_time = base_proc * CRITICAL_FAST_LANE_PROC_FACTOR * random.uniform(0.85, 1.05)
            network_delay = random.uniform(*CRITICAL_FAST_LANE_NET_DELAY_RANGE)
            consensus_delay *= 0.75
            finalization_delay *= 0.75
        else:
            service_time = base_proc * random.uniform(0.9, 1.1)
            network_delay = random.uniform(*NORMAL_NET_DELAY_RANGE)

        # Treat network + consensus delay as consensus-related overhead for the
        # timing decomposition, because finality requires validator communication.
        consensus_time = (network_delay + consensus_delay) * float(max(0.0, latency_mult))
        service_time = service_time * float(max(0.0, latency_mult))
        queue_wait = queue_wait * float(max(0.0, latency_mult))
        return queue_wait, service_time, consensus_time, finalization_delay

    def _record_processed_batch(self, priority: str, sid: int, k: int, queue_wait: float, service_time: float, consensus_time: float, finalization_time: float, completion_latency_s: float, source_counts: dict = None, processor_profile_weights: dict = None):
        self.metrics["tx_processed"] += k
        self.metrics["priority_tx_processed"][priority] += k
        self.metrics["shard_tx_processed"][sid] += k
        if source_counts is not None:
            for dev in DEVICE_TYPES:
                self.metrics["source_tx_processed"][dev] += int(source_counts.get(dev, 0))
        processor_counts = self._allocate_by_weights(k, processor_profile_weights or {})
        for dev in DEVICE_TYPES:
            self.metrics["processor_tx_processed"][dev] += int(processor_counts.get(dev, 0))
        self.metrics["total_latency_s"] += completion_latency_s * k
        self.metrics["queue_wait_s_total"] += queue_wait * k
        self.metrics["service_time_s_total"] += service_time * k
        self.metrics["consensus_time_s_total"] += consensus_time * k
        self.metrics["finalization_time_s_total"] += finalization_time * k
        self.metrics["priority_queue_wait_s"][priority] += queue_wait * k
        self.metrics["priority_service_time_s"][priority] += service_time * k
        self.metrics["priority_consensus_time_s"][priority] += consensus_time * k
        self.metrics["priority_finalization_time_s"][priority] += finalization_time * k

        deadline = float(PRIORITY_CONFIG[priority]["deadline"])
        freshness = max(0.0, 1.0 - (completion_latency_s / max(1e-9, deadline)))
        self.metrics["total_freshness_score"] += freshness * k
        self.metrics["priority_freshness_score"][priority] += freshness * k

        sample = min(100, k)
        for _ in range(sample):
            self.metrics["priority_latency_s"][priority].append(
                completion_latency_s * random.uniform(0.95, 1.05)
            )

    def process_shard_epoch(self, shard_id: int, capacity_tx: float, queue_Wq_s: float, latency_mult: float, current_time_s: float, processor_profile_weights: dict = None) -> int:
        sid = int(shard_id)
        capacity = int(max(0, math.floor(capacity_tx)))
        processed_total = 0
        if capacity <= 0:
            return 0

        # CRITICAL fast lane: process emergency traffic first with reduced queue
        # and consensus overhead. Since it is processed first, the reserved
        # validator share mainly acts as a guaranteed capacity floor when the
        # shard is congested.
        priority_order = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
        for p in priority_order:
            if capacity <= 0:
                break
            deadline = float(PRIORITY_CONFIG[p]["deadline"])
            q = self.backlog[sid][p]

            while q and capacity > 0:
                # FIFO inside the same priority is equivalent to EDF because all
                # transactions in the same class share the same relative deadline.
                entry = q[0]
                arrival_time = float(entry[0])
                avail = int(entry[1])
                source_counts_total = self._normalize_count_dict(entry[2] if len(entry) >= 3 else {"sensor": avail})
                if avail <= 0:
                    q.popleft()
                    continue

                age_s = max(0.0, float(current_time_s) - arrival_time)
                if age_s > deadline:
                    q.popleft()
                    self._expire_batch(p, avail, shard_id=sid, source_counts=source_counts_total)
                    continue

                k = min(avail, capacity)
                consumed_source_counts = self._allocate_by_weights(k, source_counts_total)
                queue_wait, service_time, consensus_time, finalization_time = self._priority_processing_components(
                    p, queue_Wq_s, latency_mult
                )
                completion_latency_s = age_s + queue_wait + service_time + consensus_time + finalization_time

                if completion_latency_s > deadline:
                    q.popleft()
                    self._expire_batch(p, avail, shard_id=sid, source_counts=source_counts_total)
                    continue

                if k == avail:
                    q.popleft()
                else:
                    q[0][1] = avail - k
                    if len(q[0]) >= 3:
                        self._subtract_count_dict(q[0][2], consumed_source_counts)

                capacity -= k
                processed_total += k
                self._record_processed_batch(
                    p, sid, k, queue_wait, service_time, consensus_time, finalization_time,
                    completion_latency_s, source_counts=consumed_source_counts,
                    processor_profile_weights=processor_profile_weights
                )
        return processed_total

    def process_epoch(self, capacity_tx: float, queue_Wq_s: float, latency_mult: float, current_time_s: float) -> int:
        per_shard_capacity = float(capacity_tx) / max(1, NUM_SHARDS)
        return sum(
            self.process_shard_epoch(sid, per_shard_capacity, queue_Wq_s, latency_mult, current_time_s, processor_profile_weights=None)
            for sid in range(NUM_SHARDS)
        )

    def timing_summary(self) -> dict:
        txp = max(1, int(self.metrics.get("tx_processed", 0)))
        out = {
            "avg_confirmation_latency_ms": (self.metrics["total_latency_s"] / txp) * 1000.0,
            "avg_queue_wait_ms": (self.metrics["queue_wait_s_total"] / txp) * 1000.0,
            "avg_service_time_ms": (self.metrics["service_time_s_total"] / txp) * 1000.0,
            "avg_consensus_time_ms": (self.metrics["consensus_time_s_total"] / txp) * 1000.0,
            "avg_finalization_time_ms": (self.metrics["finalization_time_s_total"] / txp) * 1000.0,
        }
        for p in PRIORITY_LEVELS:
            pp = max(1, int(self.metrics["priority_tx_processed"].get(p, 0)))
            arr = self.metrics["priority_latency_s"].get(p, [])
            out[f"{p.lower()}_avg_latency_ms"] = safe_mean(arr) * 1000.0
            out[f"{p.lower()}_p95_latency_ms"] = safe_percentile(arr, 95) * 1000.0
            out[f"{p.lower()}_p99_latency_ms"] = safe_percentile(arr, 99) * 1000.0
            out[f"{p.lower()}_queue_wait_ms"] = (self.metrics["priority_queue_wait_s"].get(p, 0.0) / pp) * 1000.0
            out[f"{p.lower()}_service_time_ms"] = (self.metrics["priority_service_time_s"].get(p, 0.0) / pp) * 1000.0
            out[f"{p.lower()}_consensus_time_ms"] = (self.metrics["priority_consensus_time_s"].get(p, 0.0) / pp) * 1000.0
        return out

    def device_throughput_summary(self, duration_s: float) -> dict:
        duration_s = max(1e-9, float(duration_s))
        source_rows = []
        processor_rows = []
        total_generated = max(1, int(self.metrics.get("tx_generated", 0)))
        total_processed = max(1, int(self.metrics.get("tx_processed", 0)))
        for dev in DEVICE_TYPES:
            gen = int(self.metrics["source_tx_generated"].get(dev, 0))
            proc_src = int(self.metrics["source_tx_processed"].get(dev, 0))
            exp = int(self.metrics["source_tx_expired"].get(dev, 0))
            pending = max(0, gen - proc_src - exp)
            source_rows.append({
                "device_type": dev,
                "generated_tx": gen,
                "processed_tx_from_source": proc_src,
                "expired_tx_from_source": exp,
                "pending_tx_from_source": pending,
                "source_throughput_tps": proc_src / duration_s,
                "generated_share": gen / total_generated,
                "processed_source_share": proc_src / total_processed,
            })
            proc_by_validator = int(self.metrics["processor_tx_processed"].get(dev, 0))
            processor_rows.append({
                "device_type": dev,
                "processed_tx_by_validator_type": proc_by_validator,
                "processing_throughput_tps": proc_by_validator / duration_s,
                "processing_share": proc_by_validator / total_processed,
            })
        return {"source": source_rows, "processor": processor_rows}

# ============================================================
# MAIN FRAMEWORK
# ============================================================
class RealisticHybridConsensusFramework:
    def __init__(self, protocol_mode: str = "proposed", target_tps: float = None, deployment_mode: str = "edge_dominant"):
        self.protocol_mode = protocol_mode
        self.target_tps = float(TARGET_TPS if target_tps is None else target_tps)
        self.deployment_mode = deployment_mode if deployment_mode in DEPLOYMENT_MODES else "edge_dominant"
        self.nodes = [IoTNode(i) for i in range(NUM_NODES)]
        self.shard_manager = ShardManager(self.nodes)
        self.validator_manager = ValidatorManager(self.shard_manager, deployment_mode=self.deployment_mode)
        self.validators = self.validator_manager.select_validators()
        self.attack_campaign = AttackCampaign()
        self.security_monitor = SecurityMonitor(self.nodes)
        self.markov_trust_model = MarkovTrustModel(self.nodes)
        self.tx = RealisticTransactionSystem()
        self.epoch = 0
        self.sim_t = 0.0
        self.total_energy_wh = 0.0
        self.energy_by_activity = defaultdict(float)
        self.energy_by_device = defaultdict(float)
        self.block_elapsed = 0.0
        self.pending_block_tx = 0
        self.pending_block_energy_wh = 0.0
        self.total_blocks = 0
        self.energy_per_block_hist = []
        self.ewma = 0.0
        self.device_counts = defaultdict(int)
        for n in self.nodes:
            self.device_counts[n.profile] += 1
        self.metrics = {
            "tps_epoch": [], "tps_cum": [], "tx_processed_epoch": [],
            "epoch_energy_wh": [], "latency_ms_per_epoch": [],
            "threat": [], "ewma_threat": [], "attack_intensity": [],
            "attack_effects": [], "queue_stats": [], "shard_queue_stats": [],
            "blocks_per_epoch": [], "energy_per_block_wh": [],
            "trust_state_distribution": [], "markov_kl_to_stationary": [],
            "tx_generated_epoch": [], "tx_expired_epoch": [], "pending_tx_epoch": [],
            "deadline_success_rate_epoch": [],
            "avg_queue_wait_ms_epoch": [], "avg_service_time_ms_epoch": [],
            "avg_consensus_time_ms_epoch": [], "avg_finalization_time_ms_epoch": [],
            "recovery_active_epoch": [], "recovery_overloaded_shards_epoch": [],
            "trust_audit_events_epoch": [], "trust_audit_rehabilitations_epoch": [],
            "malicious_active_after_selection_epoch": [],
        }

    def update_energy_epoch(self, power_mult: float = 1.0) -> float:
        if FAST_MODE:
            k = max(1, int(NUM_NODES * ENERGY_SAMPLE_RATIO))
            sample = random.sample(self.nodes, k)
            scale = NUM_NODES / k
        else:
            sample = self.nodes
            scale = 1.0

        protocol_config = CONSENSUS_ENERGY_MODELS.get(self.protocol_mode, CONSENSUS_ENERGY_MODELS["proposed"])
        compute_mult = protocol_config["compute_mult"]
        radio_mult = protocol_config["radio_mult"]
        consensus_mult = protocol_config["consensus_mult"]

        validator_ids = {v.id for v in self.validators}
        epoch_energy_wh = 0.0

        for n in sample:
            n.is_validator = (n.id in validator_ids)
            if n.is_validator:
                compute_time = EPOCH_DURATION * 0.6
                radio_time = EPOCH_DURATION * 0.3
                sleep_time = EPOCH_DURATION * 0.1
            else:
                sleep_time = EPOCH_DURATION * 0.95
                compute_time = EPOCH_DURATION * 0.04
                radio_time = EPOCH_DURATION * 0.01

            e_c = n.update_energy_activity_based(
                "compute", compute_time, power_mult=power_mult,
                compute_mult=compute_mult, radio_mult=radio_mult, consensus_mult=consensus_mult
            )
            e_r = n.update_energy_activity_based(
                "radio", radio_time, power_mult=power_mult,
                compute_mult=compute_mult, radio_mult=radio_mult, consensus_mult=consensus_mult
            ) if radio_time > 0 else 0.0
            e_s = n.update_energy_activity_based(
                "sleep", sleep_time, power_mult=1.0,
                compute_mult=1.0, radio_mult=1.0, consensus_mult=1.0
            )
            self.energy_by_activity["compute"] += e_c * scale
            self.energy_by_activity["radio"] += e_r * scale
            self.energy_by_activity["sleep"] += e_s * scale
            self.energy_by_device[n.profile] += (e_c + e_r + e_s) * scale
            epoch_energy_wh += (e_c + e_r + e_s) * scale

        self.total_energy_wh += epoch_energy_wh
        return epoch_energy_wh

    def update_blocks(self, processed_tx: int, epoch_energy_wh: float):
        self.block_elapsed += EPOCH_DURATION
        self.pending_block_tx += processed_tx
        self.pending_block_energy_wh += epoch_energy_wh
        blocks_this_epoch = 0
        energy_per_block_wh = 0.0
        while self.block_elapsed >= BLOCK_TIME:
            blocks_this_epoch += 1
            self.total_blocks += 1
            tx_in_block = min(BLOCK_SIZE, self.pending_block_tx)
            self.pending_block_tx -= tx_in_block
            frac = (tx_in_block / (tx_in_block + self.pending_block_tx)) if self.pending_block_tx > 0 else 1.0
            e_block = self.pending_block_energy_wh * frac
            self.pending_block_energy_wh -= e_block
            self.block_elapsed -= BLOCK_TIME
            energy_per_block_wh = e_block
            self.energy_per_block_hist.append(e_block)
        if blocks_this_epoch == 0 and self.energy_per_block_hist:
            energy_per_block_wh = self.energy_per_block_hist[-1]
        self.metrics["blocks_per_epoch"].append(blocks_this_epoch)
        self.metrics["energy_per_block_wh"].append(energy_per_block_wh)
        return blocks_this_epoch, energy_per_block_wh

    def _recovery_active(self) -> bool:
        return (ATTACK_END_EPOCH < self.epoch <= ATTACK_END_EPOCH + POST_ATTACK_RECOVERY_EPOCHS)

    def _update_post_attack_routing_pressure(self):
        """Bias new arrivals away from residual high-rho shards after attack."""
        latest = self.metrics.get("queue_stats", [])
        if not latest:
            self.tx.set_shard_routing_pressure({sid: 0.0 for sid in range(NUM_SHARDS)})
            return
        qstats = latest[-1].get("shards", {})
        pressure = {}
        for sid in range(NUM_SHARDS):
            q = qstats.get(sid, {})
            rho = float(q.get("rho_raw", q.get("rho", 0.0)))
            pending = self.tx.pending_count(shard_id=sid)
            overload = max(0.0, rho - RECOVERY_RHO_TRIGGER)
            pressure[sid] = RECOVERY_ROUTE_PRESSURE_WEIGHT * overload + 0.50 * pending
        self.tx.set_shard_routing_pressure(pressure)

    def step_epoch(self):
        self.epoch += 1
        self.sim_t = self.epoch * EPOCH_DURATION
        recovery_active = self._recovery_active()
        if recovery_active:
            self._update_post_attack_routing_pressure()
        else:
            self.tx.set_shard_routing_pressure({sid: 0.0 for sid in range(NUM_SHARDS)})
        eff = self.attack_campaign.step(self.epoch, validators=self.validators)
        attack_intensity = eff["intensity"]
        self.markov_trust_model.update_validator_states(self.validators, attack_intensity=attack_intensity)
        # Scheduled independent audits of inactive candidates; their trust is not
        # updated using consensus outcomes from transactions they did not verify.
        self.markov_trust_model.audit_inactive_candidates(
            self.validators, attack_intensity=attack_intensity
        )
        arrival_mult = eff["arrival_mult"]
        service_mult = eff["service_mult"]
        latency_mult = eff["latency_mult"]
        power_mult = eff["power_mult"]
        offered_tps = self.target_tps * arrival_mult

        generated = self.tx.generate_transactions(offered_tps, self.sim_t)
        self.validator_manager.record_arrivals(self.tx.last_arrivals_by_shard)
        self.validator_manager.update_queue_metrics(self.sim_t, service_mult=service_mult)
        self.validators = self.validator_manager.rotate_validators(self.epoch, recovery_mode=recovery_active)
        malicious_selected = sum(v.state == "MALICIOUS" for v in self.validators)
        if malicious_selected:
            raise AssertionError("MALICIOUS validator retained after committee reselection")
        self.metrics["malicious_active_after_selection_epoch"].append(malicious_selected)
        audit_row = self.markov_trust_model.audit_history[-1]
        self.metrics["trust_audit_events_epoch"].append(audit_row["audited"])
        self.metrics["trust_audit_rehabilitations_epoch"].append(audit_row["rehabilitations"])
        self.validator_manager.refresh_service_only(service_mult=service_mult)
        qstats = self.validator_manager.get_aggregate_queue_stats()
        shard_qstats = qstats.get("shards", {})

        base_threat = self.security_monitor.threat_level()
        threat = clamp(0.2 * base_threat + 0.8 * attack_intensity, 0.0, 1.0)
        self.ewma = threat if self.epoch == 1 else (EWMA_ALPHA * threat + (1.0 - EWMA_ALPHA) * self.ewma)
        epoch_energy_wh = self.update_energy_epoch(power_mult=power_mult)

        expired_before = self.tx.metrics["tx_expired"]
        self.tx.expire_transactions(self.sim_t)

        processed_tx = 0
        for sid in range(NUM_SHARDS):
            sq = shard_qstats.get(sid, {})
            c_s = max(1, int(sq.get("c", len(self.validator_manager.validators_by_shard.get(sid, [])) or 1)))
            mu_s = max(1e-6, float(sq.get("mu", 1e-6)))
            capacity_tx_s = c_s * mu_s * EPOCH_DURATION
            processed_tx += self.tx.process_shard_epoch(
                sid,
                capacity_tx_s,
                float(sq.get("Wq_s", qstats.get("weighted_Wq_s", qstats.get("Wq_s", 0.0)))),
                latency_mult=latency_mult,
                current_time_s=self.sim_t,
                processor_profile_weights=self.validator_manager.processor_profile_weights(sid),
            )

        expired_epoch = self.tx.metrics["tx_expired"] - expired_before
        txp_total = self.tx.metrics["tx_processed"]
        avg_latency_ms = (self.tx.metrics["total_latency_s"] / txp_total) * 1000.0 if txp_total > 0 else 0.0
        # Fast cumulative timing decomposition for per-epoch histories. Avoid
        # full percentile calculation inside every epoch; detailed P95/P99 are
        # computed only once in timing_summary() at the end of a run.
        denom_timing = max(1, txp_total)
        timing = {
            "avg_queue_wait_ms": (self.tx.metrics.get("queue_wait_s_total", 0.0) / denom_timing) * 1000.0,
            "avg_service_time_ms": (self.tx.metrics.get("service_time_s_total", 0.0) / denom_timing) * 1000.0,
            "avg_consensus_time_ms": (self.tx.metrics.get("consensus_time_s_total", 0.0) / denom_timing) * 1000.0,
            "avg_finalization_time_ms": (self.tx.metrics.get("finalization_time_s_total", 0.0) / denom_timing) * 1000.0,
        }
        epoch_tps = processed_tx / max(1e-9, EPOCH_DURATION)
        cum_tps = txp_total / max(1e-9, self.sim_t)
        blocks_this_epoch, energy_per_block_wh = self.update_blocks(processed_tx, epoch_energy_wh)
        self.metrics["tps_epoch"].append(epoch_tps)
        self.metrics["tps_cum"].append(cum_tps)
        self.metrics["tx_processed_epoch"].append(processed_tx)
        self.metrics["tx_generated_epoch"].append(generated)
        self.metrics["tx_expired_epoch"].append(expired_epoch)
        self.metrics["pending_tx_epoch"].append(self.tx.pending_count())
        denom_rt = max(1, processed_tx + expired_epoch)
        self.metrics["deadline_success_rate_epoch"].append(processed_tx / denom_rt)
        self.metrics["epoch_energy_wh"].append(epoch_energy_wh)
        self.metrics["latency_ms_per_epoch"].append(avg_latency_ms)
        self.metrics["avg_queue_wait_ms_epoch"].append(timing.get("avg_queue_wait_ms", 0.0))
        self.metrics["avg_service_time_ms_epoch"].append(timing.get("avg_service_time_ms", 0.0))
        self.metrics["avg_consensus_time_ms_epoch"].append(timing.get("avg_consensus_time_ms", 0.0))
        self.metrics["avg_finalization_time_ms_epoch"].append(timing.get("avg_finalization_time_ms", 0.0))
        self.metrics["threat"].append(threat)
        self.metrics["ewma_threat"].append(self.ewma)
        self.metrics["attack_intensity"].append(attack_intensity)
        self.metrics["attack_effects"].append(eff)
        self.metrics["queue_stats"].append(qstats)
        self.metrics.setdefault("shard_queue_stats", []).append(shard_qstats)
        trust_dist = self.markov_trust_model.current_state_distribution()
        self.metrics["trust_state_distribution"].append(trust_dist)
        self.metrics["markov_kl_to_stationary"].append(
            self.markov_trust_model.kl_to_stationary_history[-1]
            if self.markov_trust_model.kl_to_stationary_history else 0.0
        )
        self.metrics["recovery_active_epoch"].append(bool(recovery_active))
        self.metrics["recovery_overloaded_shards_epoch"].append(len(self.validator_manager.recovery_overloaded_shards))
        return {
            "epoch": self.epoch, "tps": epoch_tps, "lat_ms": avg_latency_ms,
            "threat": threat, "attack": attack_intensity, "validators": len(self.validators),
            "rho": qstats.get("rho", 0.0), "max_shard_rho": qstats.get("max_shard_rho", 0.0),
            "overloaded_shards": qstats.get("overloaded_shards", 0), "effects": eff,
            "energy_per_block_wh": energy_per_block_wh, "blocks_s": blocks_this_epoch / max(1e-9, EPOCH_DURATION),
            "expired": expired_epoch, "pending": self.tx.pending_count(),
            "recovery_active": recovery_active,
            "recovery_shards": len(self.validator_manager.recovery_overloaded_shards),
        }

    def print_epoch_line(self, s: dict):
        eff = s["effects"]
        recovery_label = f" | Recovery {s.get('recovery_shards',0)} shards" if s.get("recovery_active", False) else ""
        print(f"Epoch {s['epoch']:4d} | TPS {s['tps']/1000:6.1f}K | Latency {s['lat_ms']:7.2f}ms | Expired {s.get('expired',0):5d} | Pending {s.get('pending',0):7d} | Threat {s['threat']:.2f} | Attack {s['attack']:.2f} | Validators {s['validators']} | Max shard ρ {s.get('max_shard_rho',0):.2f} | Overloaded shards {s.get('overloaded_shards',0)}{recovery_label}")
        q = self.metrics["queue_stats"][-1]
        mu_total = q["c"] * q["mu"]
        print(f"   Shard-level M/M/c aggregate: ρ={q.get('rho',0.0):.3f}, avg_shard_ρ={q.get('avg_shard_rho',0.0):.3f}, max_shard_ρ={q.get('max_shard_rho',0.0):.3f}, overloaded={q.get('overloaded_shards',0)}/{NUM_SHARDS}, Wq_weighted={q.get('weighted_Wq_s',q.get('Wq_s',0.0))*1000:.3f}ms, c_total={q['c']}, λ_total={q['lambda']:.1f}/s, μ_total={mu_total:.1f}/s | Effects: arr×{eff['arrival_mult']:.2f}, svc×{eff['service_mult']:.2f}, lat×{eff['latency_mult']:.2f}, pwr×{eff['power_mult']:.2f}")
        if self.metrics.get("trust_state_distribution"):
            d = self.metrics["trust_state_distribution"][-1]
            print(f"   Markov trust: T={d.get('TRUSTED',0):.2f}, N={d.get('NEUTRAL',0):.2f}, R={d.get('RISKY',0):.2f}, M={d.get('MALICIOUS',0):.2f}")

# ============================================================
# ENERGY COMPARISON FUNCTIONS
# ============================================================

def print_energy_model_calibration():
    """Print device calibration table."""
    print("\n" + "="*80)
    print("ENERGY MODEL CALIBRATION - REPRESENTATIVE DEVICE PROFILES")
    print("="*80)
    print("\nDevice power profiles calibrated using representative hardware classes.\n")
    
    print(f"{'Device Class':<15} | {'Sleep (W)':<12} | {'Compute (W)':<12} | {'Radio (W)':<12}")
    print("-" * 60)
    
    for dev_type, profile in DEVICE_PROFILES.items():
        power = profile["power"]
        print(f"{dev_type:<15} | {power['sleep']:<12.4f} | {power['compute']:<12.2f} | {power['radio']:<12.2f}")
    
    print("="*80)
    
    print("\n" + "="*80)
    print("METHODOLOGICAL NOTE")
    print("="*80)
    print("""
    Protocol-specific energy factors are MODELED ASSUMPTIONS based on 
    communication complexity, NOT empirical measurements:
    
    - PoA:      O(1) complexity  → minimal coordination overhead
    - Raft:     O(n) complexity  → leader-based communication
    - PBFT:     O(n²) complexity → all-to-all messaging
    """)
    print("="*80)

def run_energy_protocol_comparison(framework_class, num_epochs: int = 100):
    """Run energy comparison across different consensus protocols."""
    protocols = list(CONSENSUS_ENERGY_MODELS.keys())
    results = {}
    print("\n" + "="*80)
    print("ENERGY CONSUMPTION COMPARISON ACROSS CONSENSUS PROTOCOLS")
    print("="*80)
    print("\nNote: Energy factors are modeled assumptions based on communication complexity.\n")
    
    for protocol in protocols:
        print(f"\nRunning simulation for {CONSENSUS_ENERGY_MODELS[protocol]['label']}...")
        fw = framework_class(protocol_mode=protocol)
        for epoch in range(1, num_epochs + 1):
            fw.step_epoch()
        tx_processed = fw.tx.metrics["tx_processed"]
        total_energy = fw.total_energy_wh
        energy_per_tx = total_energy / max(1, tx_processed)
        efficiency = 1.0 / max(1e-12, energy_per_tx)
        results[protocol] = {
            "label": CONSENSUS_ENERGY_MODELS[protocol]["label"],
            "description": CONSENSUS_ENERGY_MODELS[protocol]["description"],
            "complexity": CONSENSUS_ENERGY_MODELS[protocol]["complexity"],
            "tx_processed": tx_processed, "total_energy_wh": total_energy,
            "energy_per_tx_wh": energy_per_tx, "efficiency_tx_per_wh": efficiency,
            "energy_by_activity": dict(fw.energy_by_activity), "energy_by_device": dict(fw.energy_by_device)
        }
        print(f"  Transactions: {tx_processed:,}")
        print(f"  Total Energy: {total_energy:.6f} Wh")
        print(f"  Energy per TX: {energy_per_tx:.8f} Wh/tx")
        print(f"  Efficiency: {efficiency:.2f} tx/Wh")
        print(f"  Complexity: {CONSENSUS_ENERGY_MODELS[protocol]['complexity']}")
    return results

def generate_energy_comparison_report(results: dict):
    """Generate formatted comparison report."""
    print("\n" + "="*80)
    print("ENERGY COMPARISON REPORT")
    print("="*80)
    
    print(f"\n{'Protocol':<22} | {'Complexity':<10} | {'Total Energy':>12} | {'Wh/tx':>12} | {'tx/Wh':>12} | {'vs Proposed':>12}")
    print("-" * 95)
    proposed_energy = results["proposed"]["energy_per_tx_wh"]
    for protocol, data in results.items():
        label = data["label"][:20]
        complexity = data.get("complexity", "N/A")
        total_energy = data["total_energy_wh"]
        energy_per_tx = data["energy_per_tx_wh"]
        efficiency = data["efficiency_tx_per_wh"]
        if protocol == "proposed":
            improvement = "baseline"
        else:
            improvement_pct = ((proposed_energy - energy_per_tx) / proposed_energy) * 100
            improvement = f"{improvement_pct:+.1f}%"
        print(f"{label:<22} | {complexity:<10} | {total_energy:11.6f} | {energy_per_tx:11.8f} | {efficiency:11.2f} | {improvement:>12}")
    print("-" * 95)
    
    print("\n" + "="*80)
    print("KEY FINDINGS")
    print("="*80)
    poa_energy = results["poa"]["energy_per_tx_wh"]
    pbft_energy = results["pbft_lite"]["energy_per_tx_wh"]
    raft_energy = results["raft"]["energy_per_tx_wh"]
    
    print(f"\n1. Proposed consensus achieves {results['proposed']['efficiency_tx_per_wh']:.2f} tx/Wh")
    print(f"2. PoA (O(1) complexity) is {(proposed_energy - poa_energy)/proposed_energy*100:.1f}% more energy-efficient")
    print(f"3. Raft (O(n) complexity) is {(proposed_energy - raft_energy)/proposed_energy*100:.1f}% more energy-efficient")
    print(f"4. PBFT-lite (O(n²) complexity) consumes {(pbft_energy - proposed_energy)/proposed_energy*100:.1f}% more energy")
    print("\n" + "="*80)

# ============================================================
# ATTACK IMPACT ANALYSIS FUNCTIONS
# ============================================================

def _safe_pct_change(current, reference):
    return 0.0 if reference == 0 else (current - reference) / reference * 100.0


def compute_pre_during_post_attack_analysis(framework):
    """
    Compute a single, consistent PRE / DURING / POST attack analysis.

    This replaces the older non-attack-vs-attack calculation, which mixed the
    post-attack period with the pre-attack baseline and could produce confusing
    or contradictory impact numbers.
    """
    truth_flags = np.array(framework.attack_campaign.truth_attack_epoch_flags, dtype=bool)
    tps_epoch = np.array(framework.metrics.get("tps_epoch", []), dtype=float)
    lat_ms = np.array(framework.metrics.get("latency_ms_per_epoch", []), dtype=float)
    e_wh = np.array(framework.metrics.get("epoch_energy_wh", []), dtype=float)
    tx_ep = np.array(framework.metrics.get("tx_processed_epoch", []), dtype=float)
    gen_ep = np.array(framework.metrics.get("tx_generated_epoch", []), dtype=float)
    exp_ep = np.array(framework.metrics.get("tx_expired_epoch", []), dtype=float)
    pending_ep = np.array(framework.metrics.get("pending_tx_epoch", []), dtype=float)
    deadline_success = np.array(framework.metrics.get("deadline_success_rate_epoch", []), dtype=float)
    attack_intensity = np.array(framework.metrics.get("attack_intensity", []), dtype=float)
    c_series = np.array([qs.get("c", 0.0) for qs in framework.metrics.get("queue_stats", [])], dtype=float)
    rho_series = np.array([qs.get("rho", 0.0) for qs in framework.metrics.get("queue_stats", [])], dtype=float)

    n = min(
        len(truth_flags), len(tps_epoch), len(lat_ms), len(e_wh), len(tx_ep),
        len(gen_ep), len(exp_ep), len(pending_ep), len(deadline_success),
        len(attack_intensity), len(c_series), len(rho_series)
    )
    if n == 0 or not truth_flags[:n].any():
        return {"available": False, "reason": "No attack window found or no metrics recorded."}

    truth_flags = truth_flags[:n]
    tps_epoch = tps_epoch[:n]
    lat_ms = lat_ms[:n]
    e_wh = e_wh[:n]
    tx_ep = tx_ep[:n]
    gen_ep = gen_ep[:n]
    exp_ep = exp_ep[:n]
    pending_ep = pending_ep[:n]
    deadline_success = deadline_success[:n]
    attack_intensity = attack_intensity[:n]
    c_series = c_series[:n]
    rho_series = rho_series[:n]

    attack_idx = np.where(truth_flags)[0]
    a0, a1 = int(attack_idx[0]), int(attack_idx[-1])
    pre_end = a0
    pre_start = max(WARMUP_EPOCHS, pre_end - PRE_WINDOW_EPOCHS)
    during_start, during_end = a0, a1 + 1
    post_start, post_end = a1 + 1, n

    def phase_stats(lo, hi):
        lo = max(0, int(lo))
        hi = min(n, int(hi))
        epochs = max(0, hi - lo)
        duration_s = epochs * EPOCH_DURATION
        if hi <= lo:
            return {
                "start_epoch": lo + 1, "end_epoch": hi, "epochs": 0, "duration_s": 0.0,
                "tps": 0.0, "lat_ms": 0.0, "energy_wh": 0.0, "tx": 0.0,
                "generated": 0.0, "expired": 0.0, "pending_last": 0.0,
                "energy_per_tx_wh": 0.0, "energy_rate_wh_per_s": 0.0, "validators": 0.0, "rho": 0.0,
                "deadline_success": 0.0, "attack_intensity": 0.0,
            }
        tx_tot = float(np.sum(tx_ep[lo:hi]))
        gen_tot = float(np.sum(gen_ep[lo:hi]))
        exp_tot = float(np.sum(exp_ep[lo:hi]))
        e_tot = float(np.sum(e_wh[lo:hi]))
        return {
            "start_epoch": lo + 1,
            "end_epoch": hi,
            "epochs": epochs,
            "duration_s": duration_s,
            "tps": tx_tot / max(1e-9, duration_s),
            "lat_ms": safe_mean(lat_ms[lo:hi]),
            "energy_wh": e_tot,
            "tx": tx_tot,
            "generated": gen_tot,
            "expired": exp_tot,
            "pending_last": float(pending_ep[hi - 1]) if hi > lo else 0.0,
            "energy_per_tx_wh": e_tot / max(1.0, tx_tot),
            "energy_rate_wh_per_s": e_tot / max(1e-9, duration_s),
            "validators": safe_mean(c_series[lo:hi]),
            "rho": safe_mean(rho_series[lo:hi]),
            "deadline_success": safe_mean(deadline_success[lo:hi]),
            "attack_intensity": safe_mean(attack_intensity[lo:hi]),
        }

    pre = phase_stats(pre_start, pre_end)
    during = phase_stats(during_start, during_end)
    post = phase_stats(post_start, post_end)

    changes_pre_to_during = {
        "energy_wh": _safe_pct_change(during["energy_wh"], pre["energy_wh"]),
        "energy_rate_wh_per_s": _safe_pct_change(during["energy_rate_wh_per_s"], pre["energy_rate_wh_per_s"]),
        "energy_per_tx_wh": _safe_pct_change(during["energy_per_tx_wh"], pre["energy_per_tx_wh"]),
        "tps": _safe_pct_change(during["tps"], pre["tps"]),
        "latency_ms": _safe_pct_change(during["lat_ms"], pre["lat_ms"]),
        "validators": _safe_pct_change(during["validators"], pre["validators"]),
        "rho": _safe_pct_change(during["rho"], pre["rho"]),
        "deadline_success": _safe_pct_change(during["deadline_success"], pre["deadline_success"]),
        "expired": _safe_pct_change(during["expired"], pre["expired"]),
    }
    changes_during_to_post = {
        "energy_wh": _safe_pct_change(post["energy_wh"], during["energy_wh"]),
        "energy_rate_wh_per_s": _safe_pct_change(post["energy_rate_wh_per_s"], during["energy_rate_wh_per_s"]),
        "energy_per_tx_wh": _safe_pct_change(post["energy_per_tx_wh"], during["energy_per_tx_wh"]),
        "tps": _safe_pct_change(post["tps"], during["tps"]),
        "latency_ms": _safe_pct_change(post["lat_ms"], during["lat_ms"]),
        "validators": _safe_pct_change(post["validators"], during["validators"]),
        "rho": _safe_pct_change(post["rho"], during["rho"]),
        "deadline_success": _safe_pct_change(post["deadline_success"], during["deadline_success"]),
        "expired": _safe_pct_change(post["expired"], during["expired"]),
    }

    # Correlation is still reported only inside the attack window, where attack intensity varies.
    during_slice = slice(during_start, during_end)
    corr_attack_energy = safe_corr(attack_intensity[during_slice], e_wh[during_slice])
    corr_attack_tps = safe_corr(attack_intensity[during_slice], tps_epoch[during_slice])
    corr_attack_latency = safe_corr(attack_intensity[during_slice], lat_ms[during_slice])

    return {
        "available": True,
        "n_epochs": n,
        "attack_window": {"start_epoch": a0 + 1, "end_epoch": a1 + 1},
        "warmup_epochs": WARMUP_EPOCHS,
        "pre_window_epochs": PRE_WINDOW_EPOCHS,
        "phases": {"pre": pre, "during": during, "post": post},
        "changes_pre_to_during_pct": changes_pre_to_during,
        "changes_during_to_post_pct": changes_during_to_post,
        "correlations_during_attack": {
            "attack_vs_energy": corr_attack_energy,
            "attack_vs_tps": corr_attack_tps,
            "attack_vs_latency": corr_attack_latency,
        },
    }


def analyze_attack_energy_impact(framework):
    """Backward-compatible wrapper using the new PRE/DURING/POST analysis."""
    analysis = compute_pre_during_post_attack_analysis(framework)
    if not analysis.get("available", False):
        return {
            "correlations": {"attack_vs_energy": 0.0, "attack_vs_tps": 0.0, "attack_vs_latency": 0.0},
            "phase_comparison": {
                "pre_attack": {"energy_wh": 0.0, "tps": 0.0, "latency_ms": 0.0},
                "during_attack": {"energy_wh": 0.0, "tps": 0.0, "latency_ms": 0.0},
                "post_attack": {"energy_wh": 0.0, "tps": 0.0, "latency_ms": 0.0},
                "changes_percent": {"energy": 0.0, "tps": 0.0, "latency": 0.0},
            },
            "pre_during_post": analysis,
        }
    phases = analysis["phases"]
    changes = analysis["changes_pre_to_during_pct"]
    return {
        "correlations": analysis["correlations_during_attack"],
        "phase_comparison": {
            "pre_attack": {
                "energy_wh": phases["pre"]["energy_wh"],
                "energy_per_tx_wh": phases["pre"]["energy_per_tx_wh"],
                "energy_rate_wh_per_s": phases["pre"]["energy_rate_wh_per_s"],
                "tps": phases["pre"]["tps"],
                "latency_ms": phases["pre"]["lat_ms"],
            },
            "during_attack": {
                "energy_wh": phases["during"]["energy_wh"],
                "energy_per_tx_wh": phases["during"]["energy_per_tx_wh"],
                "energy_rate_wh_per_s": phases["during"]["energy_rate_wh_per_s"],
                "tps": phases["during"]["tps"],
                "latency_ms": phases["during"]["lat_ms"],
            },
            "post_attack": {
                "energy_wh": phases["post"]["energy_wh"],
                "energy_per_tx_wh": phases["post"]["energy_per_tx_wh"],
                "energy_rate_wh_per_s": phases["post"]["energy_rate_wh_per_s"],
                "tps": phases["post"]["tps"],
                "latency_ms": phases["post"]["lat_ms"],
            },
            "changes_percent": {
                "energy": changes["energy_wh"],
                "energy_rate": changes["energy_rate_wh_per_s"],
                "energy_per_tx": changes["energy_per_tx_wh"],
                "tps": changes["tps"],
                "latency": changes["latency_ms"],
            },
        },
        "pre_during_post": analysis,
    }

def print_attack_impact_report(results):
    """Print formatted attack impact report."""
    print("\n" + "="*70)
    print("ATTACK IMPACT ANALYSIS: Energy, Throughput, and Latency")
    print("="*70)
    
    phase = results["phase_comparison"]
    changes = phase["changes_percent"]
    
    print("\n1. PHASE COMPARISON (Pre-Attack vs During-Attack)")
    print("-" * 50)
    print(f"   {'Metric':<15} | {'Pre-Attack':>12} | {'During-Attack':>12} | {'Change':>10}")
    print(f"   {'-'*15} | {'-'*12} | {'-'*12} | {'-'*10}")
    print(f"   {'Energy (Wh)':<15} | {phase['pre_attack']['energy_wh']:11.6f} | {phase['during_attack']['energy_wh']:11.6f} | {changes['energy']:+9.2f}%")
    print(f"   {'Throughput':<15} | {phase['pre_attack']['tps']:11.2f} | {phase['during_attack']['tps']:11.2f} | {changes['tps']:+9.2f}%")
    print(f"   {'Latency (ms)':<15} | {phase['pre_attack']['latency_ms']:11.2f} | {phase['during_attack']['latency_ms']:11.2f} | {changes['latency']:+9.2f}%")
    
    corr = results["correlations"]
    print("\n2. CORRELATION WITH ATTACK INTENSITY (During Attack)")
    print("-" * 50)
    print(f"   Attack Intensity vs Energy:     {corr['attack_vs_energy']:+.3f}")
    print(f"   Attack Intensity vs Throughput: {corr['attack_vs_tps']:+.3f}")
    print(f"   Attack Intensity vs Latency:    {corr['attack_vs_latency']:+.3f}")
    
    print("\n3. INTERPRETATION")
    print("-" * 50)
    if abs(corr['attack_vs_energy']) > 0.7:
        print(f"   ✓ Strong correlation between attack intensity and energy")
    elif abs(corr['attack_vs_energy']) > 0.3:
        print(f"   ✓ Moderate correlation between attack intensity and energy")
    else:
        print(f"   ✗ Weak correlation between attack intensity and energy")
    
    if changes['energy'] > 20:
        print(f"   ✓ Energy increased significantly ({changes['energy']:.1f}%) during attacks")
    elif changes['energy'] > 5:
        print(f"   ✓ Energy increased moderately ({changes['energy']:.1f}%) during attacks")
    
    if changes['tps'] < -20:
        print(f"   ✗ Throughput degraded significantly ({changes['tps']:.1f}%) during attacks")
    elif changes['tps'] < -5:
        print(f"   ✗ Throughput degraded moderately ({changes['tps']:.1f}%) during attacks")
    
    print("\n" + "="*70)

# ============================================================
# REPORTING FUNCTIONS
# ============================================================

def calculate_iot_qos_metrics(framework: RealisticHybridConsensusFramework):
    """Compute IoT QoS metrics from simulation outputs, not fixed constants."""
    txm = framework.tx.metrics
    generated = int(txm.get("tx_generated", 0))
    processed = int(txm.get("tx_processed", 0))
    expired = int(txm.get("tx_expired", 0))
    pending = int(framework.tx.pending_count())

    tx_processed_epoch = np.array(framework.metrics.get("tx_processed_epoch", []), dtype=float)
    tx_generated_epoch = np.array(framework.metrics.get("tx_generated_epoch", []), dtype=float)
    active_epochs = int(np.sum(tx_generated_epoch > 0)) if len(tx_generated_epoch) else 0
    service_epochs = int(np.sum(tx_processed_epoch > 0)) if len(tx_processed_epoch) else 0

    availability = service_epochs / max(1, active_epochs)
    reliability = processed / max(1, generated)
    deadline_miss_ratio = expired / max(1, processed + expired)
    real_time_success_rate = processed / max(1, processed + expired + pending)
    data_freshness = txm.get("total_freshness_score", 0.0) / max(1, processed)
    avg_node_delivery_time_ms = (txm.get("total_latency_s", 0.0) / max(1, processed)) * 1000.0

    critical_lat = np.array(txm["priority_latency_s"].get("CRITICAL", []), dtype=float) * 1000.0
    critical_event_detection_ms = safe_mean(critical_lat)
    critical_p95_ms = safe_percentile(critical_lat, 95)

    # Battery-life estimate derived from simulated energy consumption.
    # Cloud-backed validators are excluded because they are not battery-powered IoT nodes.
    battery_capacity_wh = {"sensor": 5.0, "gateway": 40.0, "edge": 60.0}
    duration_h = max(1e-9, framework.sim_t / 3600.0)
    battery_life_by_device_h = {}
    for dev, capacity_wh in battery_capacity_wh.items():
        count = max(1, framework.device_counts.get(dev, 0))
        total_energy_wh = framework.energy_by_device.get(dev, 0.0)
        avg_energy_per_node_wh = total_energy_wh / count
        avg_power_w = avg_energy_per_node_wh / duration_h
        battery_life_by_device_h[dev] = capacity_wh / max(1e-12, avg_power_w)

    min_battery_life_h = min(battery_life_by_device_h.values()) if battery_life_by_device_h else 0.0
    avg_battery_life_h = safe_mean(list(battery_life_by_device_h.values()))

    priority_deadline_success = {}
    for p in PRIORITY_LEVELS:
        p_proc = txm["priority_tx_processed"].get(p, 0)
        p_exp = txm["priority_tx_expired"].get(p, 0)
        priority_deadline_success[p] = p_proc / max(1, p_proc + p_exp)

    return {
        "availability": availability,
        "reliability": reliability,
        "real_time_success_rate": real_time_success_rate,
        "deadline_miss_ratio": deadline_miss_ratio,
        "data_freshness": data_freshness,
        "critical_event_detection_ms": critical_event_detection_ms,
        "critical_p95_latency_ms": critical_p95_ms,
        "avg_node_delivery_time_ms": avg_node_delivery_time_ms,
        "min_battery_life_h": min_battery_life_h,
        "avg_battery_life_h": avg_battery_life_h,
        "pending_transactions": pending,
        "expired_transactions": expired,
        "battery_life_by_device_h": battery_life_by_device_h,
        "priority_deadline_success": priority_deadline_success,
    }

def generate_full_report(framework: RealisticHybridConsensusFramework, out=None):
    def w(*args, **kwargs):
        if out is None:
            print(*args, **kwargs)
        else:
            print(*args, **kwargs, file=out)

    txp = int(framework.tx.metrics["tx_processed"])
    throughput = txp / max(1e-9, SIMULATION_DURATION)
    avg_lat = safe_mean(framework.metrics["latency_ms_per_epoch"])
    pri = {}
    for p in PRIORITY_LEVELS:
        arr = np.array(framework.tx.metrics["priority_latency_s"][p], dtype=float) * 1000.0
        pri[p] = {"avg": safe_mean(arr), "p95": safe_percentile(arr, 95), "p99": safe_percentile(arr, 99)}
    attack_resistance = framework.attack_campaign.get_resistance_metrics()
    iot_qos_metrics = calculate_iot_qos_metrics(framework)
    q_stats = framework.metrics["queue_stats"]
    avg_rho = safe_mean([q.get("rho", 0.0) for q in q_stats])
    avg_lq = safe_mean([q.get("Lq", 0.0) for q in q_stats])
    avg_wq = safe_mean([q.get("Wq_s", 0.0) for q in q_stats]) * 1000
    avg_w = safe_mean([q.get("W_s", 0.0) for q in q_stats]) * 1000
    avg_c = safe_mean([q.get("c", 0.0) for q in q_stats])
    truth = np.array(framework.attack_campaign.truth_attack_epoch_flags, dtype=bool)
    ewma = np.array(framework.metrics["ewma_threat"], dtype=float)
    m = min(len(truth), len(ewma))
    truth, ewma = truth[:m], ewma[:m]
    pred = ewma > EWMA_THRESHOLD
    TP = int(np.sum(pred & truth)); FP = int(np.sum(pred & ~truth))
    FN = int(np.sum(~pred & truth)); TN = int(np.sum(~pred & ~truth))
    precision = TP / max(1, TP + FP); recall = TP / max(1, TP + FN)
    f1 = 0.0 if (precision + recall) == 0 else 2 * precision * recall / (precision + recall)
    far = FP / max(1, FP + TN)
    total_energy = framework.total_energy_wh
    energy_per_tx = total_energy / max(1, txp)
    if framework.energy_per_block_hist:
        energy_array = np.array(framework.energy_per_block_hist)
        epb_avg, epb_med = safe_mean(energy_array), float(np.median(energy_array))
        epb_p95, epb_p99 = safe_percentile(energy_array, 95), safe_percentile(energy_array, 99)
    else:
        epb_avg = epb_med = epb_p95 = epb_p99 = 0.0

    w("\n" + "="*50); w("REALISTIC HYBRID CONSENSUS RESULTS"); w("="*50)
    w(f"Duration: {SIMULATION_DURATION:.1f}s | Epochs: {framework.epoch}")
    w(f"Transactions: {txp:,} processed"); w(f"Throughput: {throughput/1000:.1f}K TPS")
    w(f"Average Latency: {avg_lat:.3f} ms")
    for p in PRIORITY_LEVELS:
        w(f"{p} Latency: {pri[p]['avg']:.2f} ms (P95={pri[p]['p95']:.2f}, P99={pri[p]['p99']:.2f})")

    w("\n" + "="*50); w("ATTACK RESISTANCE METRICS"); w("="*50)
    for k, v in attack_resistance.items():
        w(f"{k}: {v:.4f}")
    w("\nAttack event accounting (all attack types explicitly simulated):")
    w(f"{'Attack':<18} | {'Attempts':>8} | {'Success':>7} | {'Detected':>8} | {'Mitigated':>9} | {'Resistance':>10}")
    w("-" * 78)
    for row in framework.attack_campaign.get_event_summary():
        w(f"{row['attack']:<18} | {row['attempts']:>8d} | {row['successful']:>7d} | {row['detected']:>8d} | {row['mitigated']:>9d} | {row['resistance']:>10.4f}")

    w("\n" + "="*50); w("REAL-TIME IoT QoS METRICS (computed from simulation)"); w("="*50)
    w(f"availability: {iot_qos_metrics['availability']:.4f}")
    w(f"reliability: {iot_qos_metrics['reliability']:.4f}")
    w(f"real_time_success_rate: {iot_qos_metrics['real_time_success_rate']:.4f}")
    w(f"deadline_miss_ratio: {iot_qos_metrics['deadline_miss_ratio']:.4f}")
    w(f"data_freshness: {iot_qos_metrics['data_freshness']:.4f}")
    w(f"avg_node_delivery_time_ms: {iot_qos_metrics['avg_node_delivery_time_ms']:.3f}")
    w(f"critical_event_detection_ms: {iot_qos_metrics['critical_event_detection_ms']:.3f}")
    w(f"critical_p95_latency_ms: {iot_qos_metrics['critical_p95_latency_ms']:.3f}")
    w(f"min_battery_life_h: {iot_qos_metrics['min_battery_life_h']:.2f}")
    w(f"avg_battery_life_h: {iot_qos_metrics['avg_battery_life_h']:.2f}")
    w(f"expired_transactions: {iot_qos_metrics['expired_transactions']:,}")
    w(f"pending_transactions: {iot_qos_metrics['pending_transactions']:,}")
    w("Priority deadline success rates:")
    for p in PRIORITY_LEVELS:
        w(f"  {p:8s}: {iot_qos_metrics['priority_deadline_success'][p]:.4f}")
    w("Estimated battery life by device type (hours):")
    for dev, hours in iot_qos_metrics['battery_life_by_device_h'].items():
        w(f"  {dev:7s}: {hours:.2f}")


    # Timing decomposition is computed once for the final report, not in every epoch.
    timing_summary = framework.tx.timing_summary()
    w("\n" + "="*50); w("TIMING AND CONSENSUS SPEED"); w("="*50)
    w(f"Average confirmation latency: {timing_summary.get('avg_confirmation_latency_ms', 0.0):.3f} ms")
    w(f"Average queue waiting time: {timing_summary.get('avg_queue_wait_ms', 0.0):.3f} ms")
    w(f"Average service time: {timing_summary.get('avg_service_time_ms', 0.0):.3f} ms")
    w(f"Average consensus-processing time: {timing_summary.get('avg_consensus_time_ms', 0.0):.3f} ms")
    w(f"Average finalization overhead: {timing_summary.get('avg_finalization_time_ms', 0.0):.3f} ms")
    w(f"Block production rate: {framework.total_blocks / max(1e-9, framework.sim_t):.2f} blocks/s")
    w(f"Total produced blocks: {framework.total_blocks}")
    w("Priority timing summary:")
    for p in PRIORITY_LEVELS:
        key = p.lower()
        w(f"  {p:8s}: avg={timing_summary.get(key + '_avg_latency_ms', 0.0):7.3f} ms, "
          f"P95={timing_summary.get(key + '_p95_latency_ms', 0.0):7.3f} ms, "
          f"P99={timing_summary.get(key + '_p99_latency_ms', 0.0):7.3f} ms, "
          f"queue={timing_summary.get(key + '_queue_wait_ms', 0.0):6.3f} ms, "
          f"service={timing_summary.get(key + '_service_time_ms', 0.0):6.3f} ms, "
          f"consensus={timing_summary.get(key + '_consensus_time_ms', 0.0):6.3f} ms")

    # Device-level throughput distribution.
    device_summary = framework.tx.device_throughput_summary(framework.sim_t)
    w("\n" + "="*50); w("DEVICE-LEVEL THROUGHPUT DISTRIBUTION"); w("="*50)
    w("Source throughput: where transactions are generated")
    w(f"{'Device':<8} | {'Generated':>10} | {'Processed':>10} | {'Expired':>9} | {'Pending':>8} | {'TPS':>10} | {'Proc.Share':>10}")
    w("-" * 84)
    for row in device_summary['source']:
        w(f"{row['device_type']:<8} | {row['generated_tx']:10d} | {row['processed_tx_from_source']:10d} | "
          f"{row['expired_tx_from_source']:9d} | {row['pending_tx_from_source']:8d} | "
          f"{row['source_throughput_tps']:10.1f} | {row['processed_source_share']*100:9.2f}%")

    w("\nProcessing throughput: which validator device types confirmed transactions")
    w(f"{'Device':<8} | {'Processed by validators':>24} | {'TPS':>10} | {'Share':>10}")
    w("-" * 62)
    for row in device_summary['processor']:
        w(f"{row['device_type']:<8} | {row['processed_tx_by_validator_type']:24d} | "
          f"{row['processing_throughput_tps']:10.1f} | {row['processing_share']*100:9.2f}%")

    w("\n" + "="*50); w("MARKOV TRUST MODEL ANALYSIS"); w("="*50)
    stationary = framework.markov_trust_model.stationary_distribution()
    current_dist = framework.markov_trust_model.current_state_distribution()
    w("Baseline stationary distribution:")
    for s in TRUST_STATES:
        w(f"  {s:9s}: {stationary.get(s,0.0):.4f}")
    w("Current empirical state distribution:")
    for s in TRUST_STATES:
        w(f"  {s:9s}: {current_dist.get(s,0.0):.4f}")
    if framework.markov_trust_model.kl_to_stationary_history:
        w(f"Latest KL divergence to stationary reference: {framework.markov_trust_model.kl_to_stationary_history[-1]:.6f}")
    eff_mat = framework.markov_trust_model.get_effective_transition_matrix(epoch_only=False)
    w("Empirical effective transition matrix (rows=current, cols=next):")
    w("           " + " ".join([f"{s[:3]:>8s}" for s in TRUST_STATES]))
    for idx, s in enumerate(TRUST_STATES):
        row = " ".join([f"{eff_mat[idx, j]:8.3f}" for j in range(len(TRUST_STATES))])
        w(f"{s[:9]:>9s} {row}")

    w("\n" + "="*50); w("M/M/c QUEUE METRICS ANALYSIS"); w("="*50)
    w(f"Target Utilization Band: ρ ∈ [{RHO_MIN:.2f}, {RHO_MAX:.2f}]")
    if q_stats:
        last_q = q_stats[-1]
        w("\nLAST EPOCH METRICS:")
        w(f"Utilization (ρ): {last_q.get('rho',0):.3f} ({last_q.get('rho',0)*100:.1f}%)")
        w(f"Queue Length (Lq): {last_q.get('Lq',0):.2f} transactions")
        w(f"Wait Time (Wq): {last_q.get('Wq_s',0)*1000:.2f} ms")
        w(f"Response Time (W): {last_q.get('W_s',0)*1000:.2f} ms")
        w(f"Number of Servers (c): {last_q.get('c',0)} validators")
        w(f"Arrival Rate (λ): {last_q.get('lambda',0):.1f} tx/s")
        w(f"Service Rate (μ_total): {last_q.get('mu',0)*last_q.get('c',1):.1f} tx/s")
        w("\nAVERAGE METRICS:")
        w(f"Utilization (ρ): {avg_rho:.3f} ({avg_rho*100:.1f}%)")
        w(f"Queue Length (Lq): {avg_lq:.2f} transactions")
        w(f"Wait Time (Wq): {avg_wq:.2f} ms")
        w(f"Response Time (W): {avg_w:.2f} ms")
        w(f"Number of Servers (c): {avg_c:.1f} validators")
        w(f"Average shard utilization (ρ): {safe_mean([q.get('avg_shard_rho', 0.0) for q in q_stats]):.3f}")
        w(f"Average max-shard utilization (ρ): {safe_mean([q.get('max_shard_rho', 0.0) for q in q_stats]):.3f}")
        w(f"Average overloaded shards: {safe_mean([q.get('overloaded_shards', 0.0) for q in q_stats]):.2f}/{NUM_SHARDS}")

        if 'shards' in last_q:
            w("\nAVERAGE SHARD-LEVEL HETEROGENEOUS M/M/c METRICS:")
            w("Note: c_active is the number of active validators. Sensors are excluded from validator committees. Because gateway/edge/cloud validators are heterogeneous, μ_total is based on nominal device-class capacity. Reputation/Markov trust affects eligibility and selection priority, not the service capacity of a selected validator.")
            w(f"{'Shard':>5} | {'avg λ':>10} | {'avg c_active':>12} | {'avg μ/val':>10} | {'avg μ_total':>11} | {'avg ρ':>7} | {'avg Wq ms':>10} | {'avg cloud%':>10} | {'dom(last)':>9}")
            w("-" * 111)
            for sid in range(NUM_SHARDS):
                rows = [q.get('shards', {}).get(sid, {}) for q in q_stats if 'shards' in q]
                avg_lam_s = safe_mean([r.get('lambda', 0.0) for r in rows])
                avg_c_s = safe_mean([r.get('c_active', r.get('c', 0.0)) for r in rows])
                avg_mu_val_s = safe_mean([r.get('mu_avg_per_validator', r.get('mu', 0.0)) for r in rows])
                avg_mu_total_s = safe_mean([r.get('mu_total_capacity', r.get('mu', 0.0) * r.get('c', 0.0)) for r in rows])
                avg_rho_s = safe_mean([r.get('rho', 0.0) for r in rows])
                avg_wq_s = safe_mean([r.get('Wq_s', 0.0) for r in rows]) * 1000.0
                avg_cloud_share = safe_mean([r.get('capacity_share_cloud', 0.0) for r in rows]) * 100.0
                last_sq = last_q['shards'].get(sid, {})
                dom_last = str(last_sq.get('dominant_validator_type', 'n/a'))[:9]
                w(f"{sid:5d} | {avg_lam_s:10.1f} | {avg_c_s:12.1f} | {avg_mu_val_s:10.1f} | {avg_mu_total_s:11.1f} | {avg_rho_s:7.3f} | {avg_wq_s:10.3f} | {avg_cloud_share:9.1f}% | {dom_last:>9}")

            w("\nLAST EPOCH SHARD-LEVEL HETEROGENEOUS M/M/c SNAPSHOT:")
            w(f"{'Shard':>5} | {'λ tx/s':>10} | {'c_active':>8} | {'μ/val':>10} | {'μ_total':>10} | {'ρ':>7} | {'Wq ms':>8} | {'Pending':>8} | {'Dominant':>9} | {'validator mix S/G/E/C':>21}")
            w("-" * 124)
            for sid in range(NUM_SHARDS):
                sq = last_q['shards'].get(sid, {})
                c_s = int(sq.get('c_active', sq.get('c', 0)))
                mu_val_s = sq.get('mu_avg_per_validator', sq.get('mu', 0.0))
                mu_total_s = sq.get('mu_total_capacity', mu_val_s * c_s)
                pending_s = framework.tx.pending_count(shard_id=sid)
                dom = str(sq.get('dominant_validator_type', 'n/a'))[:9]
                mix = f"{int(sq.get('count_sensor',0))}/{int(sq.get('count_gateway',0))}/{int(sq.get('count_edge',0))}/{int(sq.get('count_cloud',0))}"
                w(f"{sid:5d} | {sq.get('lambda',0.0):10.1f} | {c_s:8d} | {mu_val_s:10.1f} | {mu_total_s:10.1f} | {sq.get('rho',0.0):7.3f} | {sq.get('Wq_s',0.0)*1000:8.3f} | {pending_s:8d} | {dom:>9} | {mix:>21}")

    w("\n" + "="*50); w("BLOCK ENERGY ANALYSIS (Wh/block)"); w("="*50)
    w(f"Average Energy per Block: {epb_avg:.6f} Wh")
    w(f"Median Energy per Block: {epb_med:.6f} Wh")
    w(f"P95 Energy per Block: {epb_p95:.6f} Wh")
    w(f"P99 Energy per Block: {epb_p99:.6f} Wh")
    w(f"Block Production Rate: {framework.total_blocks/SIMULATION_DURATION:.2f} blocks/s")
    w(f"Total Blocks Produced: {framework.total_blocks} blocks")

    w("\n" + "-"*50); w("ENERGY CONSUMPTION ANALYSIS"); w("-"*50)
    w(f"Total Energy Consumed: {total_energy:.6f} Wh")
    w(f"Energy per Transaction: {energy_per_tx:.6f} Wh/tx")
    w(f"Energy Efficiency: {1/max(1e-12,energy_per_tx):.2f} tx/Wh")
    w("\nEnergy by Device Type:")
    for dev in ["sensor","gateway","edge","cloud"]:
        count = framework.device_counts.get(dev, 0)
        energy = framework.energy_by_device.get(dev, 0.0)
        per_node = energy / max(1, count)
        w(f"  {dev:7s}: {per_node:.6f} Wh/node ({count} nodes)")
    w("\nEnergy by Activity:")
    total_act = sum(framework.energy_by_activity.values())
    for act in ["sleep","compute","radio"]:
        energy = framework.energy_by_activity.get(act, 0.0)
        pct = energy / total_act * 100 if total_act > 0 else 0.0
        w(f"  {act:7s}: {energy:.6f} Wh ({pct:.1f}%)")

    # PRE / DURING / POST ATTACK COMPARISON TABLE
    w("\n" + "="*50)
    w("PRE / DURING / POST ATTACK COMPARISON")
    w("="*50)
    phase_analysis = compute_pre_during_post_attack_analysis(framework)
    if phase_analysis.get("available", False):
        aw = phase_analysis["attack_window"]
        phases = phase_analysis["phases"]
        changes = phase_analysis["changes_pre_to_during_pct"]
        pre = phases["pre"]
        during = phases["during"]
        post = phases["post"]

        w(f"\nAttack window epochs: {aw['start_epoch']}–{aw['end_epoch']} (of {phase_analysis['n_epochs']})")
        w(f"Warm-up excluded from PRE: first {phase_analysis['warmup_epochs']} epochs")
        w(f"PRE window: epochs {pre['start_epoch']}–{pre['end_epoch']} (last {phase_analysis['pre_window_epochs']} before attack, after warmup)\n")

        w(f"{'Metric':<24} | {'Pre-Attack':>15} | {'During-Attack':>15} | {'Post-Attack':>15} | {'Pre→During':>12}")
        w("-" * 90)
        w(f"{'Throughput (TPS)':<24} | {pre['tps']/1000:13.2f}K | {during['tps']/1000:13.2f}K | {post['tps']/1000:13.2f}K | {changes['tps']:+11.1f}%")
        w(f"{'Latency (ms)':<24} | {pre['lat_ms']:15.2f} | {during['lat_ms']:15.2f} | {post['lat_ms']:15.2f} | {changes['latency_ms']:+11.1f}%")
        w(f"{'Energy total (Wh)':<24} | {pre['energy_wh']:15.3f} | {during['energy_wh']:15.3f} | {post['energy_wh']:15.3f} | {changes['energy_wh']:+11.1f}%")
        w(f"{'Energy rate (Wh/s)':<24} | {pre['energy_rate_wh_per_s']:15.3f} | {during['energy_rate_wh_per_s']:15.3f} | {post['energy_rate_wh_per_s']:15.3f} | {changes['energy_rate_wh_per_s']:+11.1f}%")
        w(f"{'Energy (Wh/tx)':<24} | {pre['energy_per_tx_wh']:15.6f} | {during['energy_per_tx_wh']:15.6f} | {post['energy_per_tx_wh']:15.6f} | {changes['energy_per_tx_wh']:+11.1f}%")
        w(f"{'Validators (c)':<24} | {pre['validators']:15.1f} | {during['validators']:15.1f} | {post['validators']:15.1f} | {changes['validators']:+11.1f}%")
        w(f"{'Utilization (ρ)':<24} | {pre['rho']:15.3f} | {during['rho']:15.3f} | {post['rho']:15.3f} | {changes['rho']:+11.1f}%")
        w(f"{'Deadline success':<24} | {pre['deadline_success']:15.3f} | {during['deadline_success']:15.3f} | {post['deadline_success']:15.3f} | {changes['deadline_success']:+11.1f}%")
        w(f"{'Expired tx':<24} | {pre['expired']:15.0f} | {during['expired']:15.0f} | {post['expired']:15.0f} | {changes['expired']:+11.1f}%")

        w("\nPhase totals based on actual phase duration:")
        for label, stats in [("Pre", pre), ("During", during), ("Post", post)]:
            w(f"  {label:7s}: duration={stats['duration_s']:.2f}s, energy={stats['energy_wh']:.3f} Wh, "
              f"energy_rate={stats['energy_rate_wh_per_s']:.3f} Wh/s, processed_tx={stats['tx']:.0f}, "
              f"expired_tx={stats['expired']:.0f}, pending_last={stats['pending_last']:.0f}")
    else:
        w(f"No attack phase analysis available: {phase_analysis.get('reason', 'unknown reason')}")

    w("\n" + "="*50); w("DETECTION QUALITY"); w("="*50)
    w(f"TP={TP} FP={FP} FN={FN} TN={TN}")
    w(f"Precision={precision:.3f} Recall={recall:.3f} F1={f1:.3f} FAR={far:.3f}")
    
    # Attack Impact Analysis using the same PRE/DURING/POST windows above
    w("\n" + "="*50)
    w("ATTACK IMPACT ON ENERGY, THROUGHPUT AND LATENCY")
    w("="*50)
    attack_impact = analyze_attack_energy_impact(framework)
    pdp = attack_impact.get("pre_during_post", {})
    if pdp.get("available", False):
        c1 = pdp["changes_pre_to_during_pct"]
        c2 = pdp["changes_during_to_post_pct"]
        w("Impact is computed with the same PRE/DURING/POST windows used in the table above.")
        w(f"Pre→During energy change (total Wh): {c1['energy_wh']:+.2f}%")
        w(f"Pre→During energy-rate change (Wh/s): {c1['energy_rate_wh_per_s']:+.2f}%")
        w(f"Pre→During energy-per-tx change: {c1['energy_per_tx_wh']:+.2f}%")
        w(f"Pre→During throughput change: {c1['tps']:+.2f}%")
        w(f"Pre→During latency change: {c1['latency_ms']:+.2f}%")
        w(f"Pre→During deadline-success change: {c1['deadline_success']:+.2f}%")
        w(f"During→Post energy-rate recovery/change (Wh/s): {c2['energy_rate_wh_per_s']:+.2f}%")
        w(f"During→Post throughput recovery/change: {c2['tps']:+.2f}%")
        w(f"During→Post latency recovery/change: {c2['latency_ms']:+.2f}%")
        corr = pdp["correlations_during_attack"]
        w(f"Correlation during attack (Attack vs Energy): {corr['attack_vs_energy']:.3f}")
        w(f"Correlation during attack (Attack vs TPS): {corr['attack_vs_tps']:.3f}")
        w(f"Correlation during attack (Attack vs Latency): {corr['attack_vs_latency']:.3f}")
    else:
        w(f"No attack impact analysis available: {pdp.get('reason', 'unknown reason')}")
    
    w("\n" + "="*80); w("SIMULATION RESULTS SUMMARY"); w("="*80)
    w(f"Final Throughput: {throughput/1000:.1f}K TPS")
    w(f"Average Latency: {avg_lat:.2f} ms")
    w(f"Total Energy: {total_energy:.6f} Wh")
    w(f"Energy per Transaction: {energy_per_tx:.6f} Wh/tx")
    w(f"Total Blocks: {framework.total_blocks}")
    w(f"Average Utilization (ρ): {avg_rho:.3f}")
    w(f"Average Validators: {avg_c:.1f}")
    w(f"Real-Time Success Rate: {iot_qos_metrics['real_time_success_rate']:.4f}")
    w(f"Deadline Miss Ratio: {iot_qos_metrics['deadline_miss_ratio']:.4f}")
    current_dist = framework.markov_trust_model.current_state_distribution()
    w(f"Final Trust Distribution: T={current_dist.get('TRUSTED',0):.3f}, N={current_dist.get('NEUTRAL',0):.3f}, R={current_dist.get('RISKY',0):.3f}, M={current_dist.get('MALICIOUS',0):.3f}")
    w("="*80)

# ============================================================
# MAIN
# ============================================================

def export_device_throughput_tables(framework, output_prefix="device_throughput"):
    """Write two CSV tables: source throughput and processor throughput."""
    summary = framework.tx.device_throughput_summary(framework.sim_t)
    source_path = f"{output_prefix}_source.csv"
    processor_path = f"{output_prefix}_processor.csv"
    with open(source_path, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(summary["source"][0].keys()) if summary["source"] else []
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader(); writer.writerows(summary["source"])
    with open(processor_path, "w", newline="", encoding="utf-8") as f:
        fieldnames = list(summary["processor"][0].keys()) if summary["processor"] else []
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader(); writer.writerows(summary["processor"])
    return source_path, processor_path

def export_phase_analysis_table(framework, output_csv="pre_during_post_attack_phase_summary.csv"):
    """Write the PRE/DURING/POST attack analysis table used in the report."""
    analysis = compute_pre_during_post_attack_analysis(framework)
    rows = []
    if analysis.get("available", False):
        for phase_name, stats in analysis["phases"].items():
            row = {"phase": phase_name}
            row.update(stats)
            rows.append(row)
    if rows:
        with open(output_csv, "w", newline="", encoding="utf-8") as f:
            fieldnames = list(rows[0].keys())
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader(); writer.writerows(rows)
    return output_csv

def run_simulation(target_tps: float = None, report_path: str = "simulation_report.txt", verbose: bool = True, deployment_mode: str = "edge_dominant"):
    active_target_tps = float(TARGET_TPS if target_tps is None else target_tps)
    if verbose:
        print("="*80)
        print("REALISTIC IOT BLOCKCHAIN SIMULATION")
        print("="*80)
        print_energy_model_calibration()
        print(f"\nSimulation Duration: {SIMULATION_DURATION:.0f} seconds")
        print(f"Number of Nodes: {NUM_NODES}")
        print(f"Number of Shards: {NUM_SHARDS}")
        print(f"Baseline Offered TPS: {active_target_tps:,.0f}")
        print(f"Attack window: epochs {ATTACK_START_EPOCH}–{ATTACK_END_EPOCH}")
        print(f"Target ρ band: [{RHO_MIN:.2f}, {RHO_MAX:.2f}]")
        print(f"Protocol Mode: Proposed Hybrid Consensus")
        print(f"Deployment Mode: {deployment_mode}")
        print("="*80)

    fw = RealisticHybridConsensusFramework(protocol_mode="proposed", target_tps=active_target_tps, deployment_mode=deployment_mode)
    if verbose:
        dc = fw.device_counts
        print(f"Device Distribution: Sensor={dc.get('sensor',0)}, Gateway={dc.get('gateway',0)}, Edge={dc.get('edge',0)}, Cloud={dc.get('cloud',0)}")
    total_epochs = int(round(SIMULATION_DURATION / EPOCH_DURATION))
    report_every_epochs = max(1, int(round(REPORT_EVERY_SECONDS / EPOCH_DURATION)))
    for _ in range(total_epochs):
        s = fw.step_epoch()
        if verbose and (fw.epoch % report_every_epochs == 0 or fw.epoch == 1):
            fw.print_epoch_line(s)
    if WRITE_REPORT_TO_FILE and report_path:
        with open(report_path, "w", encoding="utf-8") as f:
            generate_full_report(fw, out=f)
        # Export thesis-ready supplemental tables for device-level throughput and phase analysis.
        prefix = os.path.splitext(report_path)[0]
        export_device_throughput_tables(fw, output_prefix=prefix + "_device_throughput")
        export_phase_analysis_table(fw, output_csv=prefix + "_pre_during_post_phases.csv")
        if verbose:
            print(f"\n[Saved] Full report written to {report_path}")
            print(f"[Saved] Device throughput tables: {prefix}_device_throughput_source.csv / {prefix}_device_throughput_processor.csv")
            print(f"[Saved] PRE/DURING/POST phases table: {prefix}_pre_during_post_phases.csv")
    if verbose:
        generate_full_report(fw, out=None)
    return fw


def summarize_simulation(framework: RealisticHybridConsensusFramework, target_tps: float):
    """Compact summary for TARGET_TPS scenario sweeps."""
    qos = calculate_iot_qos_metrics(framework)
    q_stats = framework.metrics.get("queue_stats", [])
    avg_rho = safe_mean([q.get("rho", 0.0) for q in q_stats])
    avg_shard_rho = safe_mean([q.get("avg_shard_rho", 0.0) for q in q_stats])
    avg_max_shard_rho = safe_mean([q.get("max_shard_rho", 0.0) for q in q_stats])
    avg_overloaded_shards = safe_mean([q.get("overloaded_shards", 0.0) for q in q_stats])
    avg_c = safe_mean([q.get("c", 0.0) for q in q_stats])
    phase = compute_pre_during_post_attack_analysis(framework)
    current_dist = framework.markov_trust_model.current_state_distribution()
    txp = int(framework.tx.metrics.get("tx_processed", 0))
    generated = int(framework.tx.metrics.get("tx_generated", 0))
    expired = int(framework.tx.metrics.get("tx_expired", 0))
    throughput = txp / max(1e-9, framework.sim_t)
    avg_latency_ms = safe_mean(framework.metrics.get("latency_ms_per_epoch", []))
    energy_per_tx = framework.total_energy_wh / max(1, txp)

    row = {
        "target_tps": float(target_tps),
        "generated_tx": generated,
        "processed_tx": txp,
        "expired_tx": expired,
        "pending_tx": framework.tx.pending_count(),
        "throughput_tps": throughput,
        "avg_latency_ms": avg_latency_ms,
        "real_time_success_rate": qos["real_time_success_rate"],
        "deadline_miss_ratio": qos["deadline_miss_ratio"],
        "data_freshness": qos["data_freshness"],
        "avg_rho": avg_rho,
        "avg_shard_rho": avg_shard_rho,
        "avg_max_shard_rho": avg_max_shard_rho,
        "avg_overloaded_shards": avg_overloaded_shards,
        "avg_validators": avg_c,
        "total_energy_wh": framework.total_energy_wh,
        "avg_energy_rate_wh_per_s": framework.total_energy_wh / max(1e-9, framework.sim_t),
        "energy_per_tx_wh": energy_per_tx,
        "final_trusted": current_dist.get("TRUSTED", 0.0),
        "final_neutral": current_dist.get("NEUTRAL", 0.0),
        "final_risky": current_dist.get("RISKY", 0.0),
        "final_malicious": current_dist.get("MALICIOUS", 0.0),
    }
    if phase.get("available", False):
        c = phase["changes_pre_to_during_pct"]
        row.update({
            "pre_during_tps_change_pct": c["tps"],
            "pre_during_latency_change_pct": c["latency_ms"],
            "pre_during_energy_rate_change_pct": c["energy_rate_wh_per_s"],
            "pre_during_energy_per_tx_change_pct": c["energy_per_tx_wh"],
            "pre_during_deadline_success_change_pct": c["deadline_success"],
            "pre_tps": phase["phases"]["pre"]["tps"],
            "during_tps": phase["phases"]["during"]["tps"],
            "post_tps": phase["phases"]["post"]["tps"],
            "pre_energy_rate_wh_per_s": phase["phases"]["pre"]["energy_rate_wh_per_s"],
            "during_energy_rate_wh_per_s": phase["phases"]["during"]["energy_rate_wh_per_s"],
            "post_energy_rate_wh_per_s": phase["phases"]["post"]["energy_rate_wh_per_s"],
        })
    return row


def run_target_tps_scenarios(
    target_tps_values=(40000, 50000, 60000, 70000, 80000),
    seed_base: int = 2026,
    output_csv: str = "target_tps_scenarios_summary.csv",
    output_txt: str = "target_tps_scenarios_summary.txt",
):
    """
    Run 3–5 TARGET_TPS scenarios for sensitivity/stress analysis.

    The same code path is used for every scenario. Seeds are reset per scenario so
    that scenario comparisons are more reproducible than a single random run.
    """
    rows = []
    for idx, tps in enumerate(target_tps_values):
        random.seed(seed_base + idx)
        np.random.seed(seed_base + idx)
        fw = run_simulation(
            target_tps=float(tps),
            report_path=f"scenario_target_tps_{int(tps)}_report.txt",
            verbose=False,
        )
        rows.append(summarize_simulation(fw, float(tps)))

    if rows and output_csv:
        with open(output_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    if rows and output_txt:
        with open(output_txt, "w", encoding="utf-8") as f:
            f.write("TARGET_TPS SCENARIO SUMMARY\n")
            f.write("="*80 + "\n")
            for r in rows:
                f.write(
                    f"TARGET_TPS={r['target_tps']:,.0f} | throughput={r['throughput_tps']/1000:.2f}K TPS | "
                    f"RT success={r['real_time_success_rate']:.3f} | deadline miss={r['deadline_miss_ratio']:.3f} | "
                    f"avg rho={r['avg_rho']:.3f} | max shard rho={r.get('avg_max_shard_rho',0.0):.3f} | "
                    f"overloaded shards={r.get('avg_overloaded_shards',0.0):.2f}/{NUM_SHARDS} | avg validators={r['avg_validators']:.1f} | "
                    f"final malicious={r['final_malicious']:.3f}\n"
                )
    return rows

def run_energy_comparison():
    print("\n\n")
    print("="*80)
    print("ENERGY COMPARISON ACROSS PROTOCOLS")
    print("="*80)
    results = run_energy_protocol_comparison(RealisticHybridConsensusFramework, num_epochs=100)
    generate_energy_comparison_report(results)
    return results

# Disabled in the bundled repeated-run driver.
if False:
    fw = run_simulation(deployment_mode="edge_dominant")
    results = run_energy_comparison()

# ============================================================
# REAL-TIME OPTIMIZED PAPER TABLES
# ============================================================
def export_timing_consensus_summary(framework: RealisticHybridConsensusFramework, target_tps: float, output_csv: str):
    """Export one-row timing/consensus-speed summary for the completed run."""
    ts = framework.tx.timing_summary()
    txp = framework.tx.metrics["tx_processed"]
    generated = framework.tx.metrics["tx_generated"]
    expired = framework.tx.metrics["tx_expired"]
    pending = framework.tx.pending_count()
    throughput = txp / max(1e-9, SIMULATION_DURATION)
    rt_success = txp / max(1, txp + expired)
    deadline_miss = expired / max(1, generated)
    qstats = framework.metrics["queue_stats"][-1] if framework.metrics.get("queue_stats") else {}

    row = {
        "deployment_mode": getattr(framework, "deployment_mode", "cloud_assisted"),
        "target_tps": target_tps,
        "generated_tx": generated,
        "processed_tx": txp,
        "expired_tx": expired,
        "pending_tx": pending,
        "throughput_tps": throughput,
        "real_time_success_rate": rt_success,
        "deadline_miss_ratio": deadline_miss,
        "avg_confirmation_latency_ms": ts.get("avg_confirmation_latency_ms", 0.0),
        "avg_queue_wait_ms": ts.get("avg_queue_wait_ms", 0.0),
        "avg_service_time_ms": ts.get("avg_service_time_ms", 0.0),
        "avg_consensus_time_ms": ts.get("avg_consensus_time_ms", 0.0),
        "avg_finalization_time_ms": ts.get("avg_finalization_time_ms", 0.0),
        "critical_avg_latency_ms": ts.get("critical_avg_latency_ms", 0.0),
        "critical_p95_latency_ms": ts.get("critical_p95_latency_ms", 0.0),
        "critical_p99_latency_ms": ts.get("critical_p99_latency_ms", 0.0),
        "high_avg_latency_ms": ts.get("high_avg_latency_ms", 0.0),
        "medium_avg_latency_ms": ts.get("medium_avg_latency_ms", 0.0),
        "low_avg_latency_ms": ts.get("low_avg_latency_ms", 0.0),
        "avg_shard_rho": safe_mean([q.get("avg_shard_rho", 0.0) for q in framework.metrics.get("queue_stats", [])]),
        "avg_max_shard_rho": safe_mean([q.get("max_shard_rho", 0.0) for q in framework.metrics.get("queue_stats", [])]),
        "avg_overloaded_shards": safe_mean([q.get("overloaded_shards", 0.0) for q in framework.metrics.get("queue_stats", [])]),
        "last_avg_shard_rho": qstats.get("avg_shard_rho", 0.0),
        "last_max_shard_rho": qstats.get("max_shard_rho", 0.0),
        "last_overloaded_shards": qstats.get("overloaded_shards", 0),
        "total_blocks": framework.total_blocks,
        "block_production_rate_blocks_s": framework.total_blocks / max(1e-9, SIMULATION_DURATION),
    }
    with open(output_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)
    return row


def run_realtime_optimized_80k():
    random.seed(2026)
    np.random.seed(2026)
    fw = run_simulation(
        target_tps=80000,
        report_path="realtime_optimized_report_80k.txt",
        verbose=False,
        deployment_mode="cloud_assisted",
    )
    row = export_timing_consensus_summary(fw, 80000, "realtime_optimized_timing_consensus_summary.csv")
    return fw, row



def run_deployment_mode_comparison_80k(output_prefix: str = "deployment_mode_80k"):
    """Run cloud-assisted vs edge-dominant modes for an 80K TPS scenario."""
    rows = []
    source_rows = []
    processor_rows = []
    phase_rows = []
    for i, mode in enumerate(["cloud_assisted", "edge_dominant"]):
        random.seed(2026)
        np.random.seed(2026)
        report_path = f"{output_prefix}_{mode}_report.txt"
        fw = run_simulation(target_tps=80000, report_path=report_path, verbose=False, deployment_mode=mode)
        overall = summarize_simulation(fw, 80000)
        overall["deployment_mode"] = mode
        timing_path = f"{output_prefix}_{mode}_timing_consensus.csv"
        export_timing_consensus_summary(fw, 80000, timing_path)
        rows.append(overall)
        dev = fw.tx.device_throughput_summary(max(1e-9, fw.sim_t))
        for r in dev["source"]:
            rr = dict(r); rr["deployment_mode"] = mode; source_rows.append(rr)
        for r in dev["processor"]:
            rr = dict(r); rr["deployment_mode"] = mode; processor_rows.append(rr)
        phase_csv = f"{output_prefix}_{mode}_pre_during_post_phases.csv"
        export_phase_analysis_table(fw, phase_csv)
        with open(phase_csv, newline="", encoding="utf-8") as f:
            for pr in csv.DictReader(f):
                pr["deployment_mode"] = mode
                phase_rows.append(pr)

    def write_csv(path, rows):
        if not rows:
            return path
        keys = list(rows[0].keys())
        extra = []
        for r in rows:
            for k in r.keys():
                if k not in keys and k not in extra:
                    extra.append(k)
        keys += extra
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader(); w.writerows(rows)
        return path

    overall_csv = write_csv(f"{output_prefix}_overall_summary.csv", rows)
    source_csv = write_csv(f"{output_prefix}_device_source.csv", source_rows)
    processor_csv = write_csv(f"{output_prefix}_device_processor.csv", processor_rows)
    phase_csv = write_csv(f"{output_prefix}_pre_during_post.csv", phase_rows)

    # Compact interpretation text.
    by_mode = {r["deployment_mode"]: r for r in rows}
    proc_by_mode = {m: {} for m in ["cloud_assisted", "edge_dominant"]}
    for r in processor_rows:
        proc_by_mode[r["deployment_mode"]][r["device_type"]] = float(r.get("processing_share", 0.0))
    txt_path = f"{output_prefix}_interpretation.txt"
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("Deployment-mode comparison at TARGET_TPS=80K\n")
        f.write("="*60 + "\n\n")
        for mode in ["cloud_assisted", "edge_dominant"]:
            r = by_mode.get(mode, {})
            p = proc_by_mode.get(mode, {})
            f.write(f"{mode}:\n")
            f.write(f"  Throughput: {float(r.get('throughput_tps', 0.0))/1000:.2f}K TPS\n")
            f.write(f"  RT success: {float(r.get('real_time_success_rate', 0.0)):.4f}\n")
            f.write(f"  Avg latency: {float(r.get('avg_latency_ms', 0.0)):.2f} ms\n")
            f.write(f"  Avg shard rho: {float(r.get('avg_shard_rho', 0.0)):.3f}\n")
            f.write(f"  Overloaded shards: {float(r.get('avg_overloaded_shards', 0.0)):.2f}/10\n")
            f.write(f"  Processor shares: sensor={p.get('sensor',0)*100:.1f}%, gateway={p.get('gateway',0)*100:.1f}%, edge={p.get('edge',0)*100:.1f}%, cloud={p.get('cloud',0)*100:.1f}%\n\n")
        f.write("Interpretation:\n")
        f.write("  cloud_assisted maximizes capacity by using cloud-backed validators heavily.\n")
        f.write("  edge_dominant constrains cloud dominance and shifts processing toward edge/gateway validators, making the deployment more aligned with decentralized smart-city IoT architecture.\n")

    return {
        "overall_csv": overall_csv,
        "source_csv": source_csv,
        "processor_csv": processor_csv,
        "phase_csv": phase_csv,
        "interpretation_txt": txt_path,
    }

# ============================================================
# NODE-COUNT SCALABILITY ANALYSIS
# ============================================================
def run_node_count_scenarios(
    node_counts=(500, 700, 1000, 1500, 2000),
    target_tps: float = 80000,
    deployment_mode: str = "edge_dominant",
    seed_base: int = 4040,
    output_prefix: str = "node_count_scalability",
):
    """Run scalability scenarios by changing NUM_NODES while keeping TARGET_TPS fixed.

    This function temporarily changes the global NUM_NODES constant for each run,
    then restores it at the end. It exports:
    - overall summary
    - timing/consensus summary
    - device-source throughput table
    - device-processor throughput table
    - pre/during/post attack phase table
    """
    global NUM_NODES
    original_num_nodes = NUM_NODES
    overall_rows = []
    timing_rows = []
    source_rows = []
    processor_rows = []
    phase_rows = []

    try:
        for idx, n_nodes in enumerate(node_counts):
            NUM_NODES = int(n_nodes)
            random.seed(seed_base + idx)
            np.random.seed(seed_base + idx)
            report_path = f"{output_prefix}_{int(n_nodes)}nodes_report.txt"
            fw = run_simulation(
                target_tps=float(target_tps),
                report_path=report_path,
                verbose=False,
                deployment_mode=deployment_mode,
            )

            overall = summarize_simulation(fw, float(target_tps))
            overall["num_nodes"] = int(n_nodes)
            overall["deployment_mode"] = deployment_mode
            overall["node_to_validator_ratio"] = int(n_nodes) / max(1e-9, overall.get("avg_validators", 0.0))
            overall["validators_per_node"] = overall.get("avg_validators", 0.0) / max(1, int(n_nodes))
            for dev_name in ["sensor", "gateway", "edge", "cloud"]:
                overall[f"num_{dev_name}"] = fw.device_counts.get(dev_name, 0)
            overall_rows.append(overall)

            timing_path = f"{output_prefix}_{int(n_nodes)}nodes_timing_consensus.csv"
            timing = export_timing_consensus_summary(fw, float(target_tps), timing_path)
            timing["num_nodes"] = int(n_nodes)
            timing["deployment_mode"] = deployment_mode
            timing_rows.append(timing)

            dev = fw.tx.device_throughput_summary(max(1e-9, fw.sim_t))
            for r in dev.get("source", []):
                rr = dict(r); rr["num_nodes"] = int(n_nodes); rr["deployment_mode"] = deployment_mode
                source_rows.append(rr)
            for r in dev.get("processor", []):
                rr = dict(r); rr["num_nodes"] = int(n_nodes); rr["deployment_mode"] = deployment_mode
                processor_rows.append(rr)

            phase = compute_pre_during_post_attack_analysis(fw)
            if phase.get("available", False):
                for phase_name, stats in phase["phases"].items():
                    pr = dict(stats)
                    pr["phase"] = phase_name
                    pr["num_nodes"] = int(n_nodes)
                    pr["deployment_mode"] = deployment_mode
                    phase_rows.append(pr)
    finally:
        NUM_NODES = original_num_nodes

    def write_rows(path, rows):
        if not rows:
            return None
        # union fieldnames while keeping first-row order
        fields = []
        for row in rows:
            for k in row.keys():
                if k not in fields:
                    fields.append(k)
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
        return path

    overall_csv = write_rows(f"{output_prefix}_overall_summary.csv", overall_rows)
    timing_csv = write_rows(f"{output_prefix}_timing_consensus.csv", timing_rows)
    source_csv = write_rows(f"{output_prefix}_device_source.csv", source_rows)
    processor_csv = write_rows(f"{output_prefix}_device_processor.csv", processor_rows)
    phase_csv = write_rows(f"{output_prefix}_pre_during_post.csv", phase_rows)

    # Excel workbook if openpyxl is available
    try:
        import openpyxl
        from openpyxl import Workbook
        wb = Workbook()
        default = wb.active
        wb.remove(default)
        for sheet_name, rows in [
            ("overall", overall_rows),
            ("timing", timing_rows),
            ("device_source", source_rows),
            ("device_processor", processor_rows),
            ("pre_during_post", phase_rows),
        ]:
            ws = wb.create_sheet(sheet_name[:31])
            if rows:
                fields = []
                for row in rows:
                    for k in row.keys():
                        if k not in fields:
                            fields.append(k)
                ws.append(fields)
                for row in rows:
                    ws.append([row.get(k, "") for k in fields])
                for cell in ws[1]:
                    cell.font = openpyxl.styles.Font(bold=True)
        xlsx_path = f"{output_prefix}_results.xlsx"
        wb.save(xlsx_path)
    except Exception:
        xlsx_path = None

    # Human-readable summary
    txt_path = f"{output_prefix}_summary.txt"
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("NODE-COUNT SCALABILITY SUMMARY\n")
        f.write("="*80 + "\n")
        f.write(f"Target TPS: {float(target_tps):,.0f}\n")
        f.write(f"Deployment mode: {deployment_mode}\n\n")
        for r in overall_rows:
            f.write(
                f"Nodes={int(r['num_nodes']):,} | TPS={r['throughput_tps']/1000:.2f}K | "
                f"RT={r['real_time_success_rate']:.4f} | latency={r['avg_latency_ms']:.2f} ms | "
                f"avg shard rho={r['avg_shard_rho']:.3f} | max shard rho={r['avg_max_shard_rho']:.3f} | "
                f"overloaded={r['avg_overloaded_shards']:.2f}/{NUM_SHARDS} | validators={r['avg_validators']:.1f} | "
                f"energy/tx={r['energy_per_tx_wh']:.8f}\n"
            )

    return {
        "overall": overall_rows,
        "timing": timing_rows,
        "source": source_rows,
        "processor": processor_rows,
        "phase": phase_rows,
        "files": {
            "overall_csv": overall_csv,
            "timing_csv": timing_csv,
            "source_csv": source_csv,
            "processor_csv": processor_csv,
            "phase_csv": phase_csv,
            "xlsx": xlsx_path,
            "summary_txt": txt_path,
        },
    }


# -*- coding: utf-8 -*-
"""
REPEATED-RUN DRIVER FOR ONE MANUAL TPS VALUE
=============================================

Purpose
-------
Run the existing IoT blockchain simulator 10 independent times at ONE chosen
TPS value. Every run is saved as a separate text report. Individual reports
and epoch logs are NOT printed. After all runs finish, this script prints and
saves ONE final aggregated report containing mean ± sample standard deviation.

Required file
-------------
Place this file in the SAME folder as:
    iot_blockchain_markov_final_all_attacks_post_attack_recovery.py

How to use
----------
1) Edit only TARGET_TPS below.
2) Keep NUMBER_OF_RUNS = 10.
3) Run in Jupyter/Colab:
       %run "run_single_tps_10_repeated_runs.py"
   or run in a terminal:
       python run_single_tps_10_repeated_runs.py

No argparse is used. The script is safe for Jupyter and Colab.
"""

import csv
import importlib.util
import numbers
import random
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import numpy as np

# =============================================================================
# USER SETTINGS: EDIT ONLY THESE VALUES WHEN NEEDED
# =============================================================================

# Put ONE manual TPS value here. Examples: 40000, 60000, 80000, 100000, 120000
TARGET_TPS = 80_000

# The user requested exactly 10 independent repetitions.
NUMBER_OF_RUNS = 10

# Same run number uses the same seed whenever you repeat the experiment.
SEED_BASE = 6100

# Keep the main experimental configuration fixed.
FIXED_NUM_NODES = 1000
DEPLOYMENT_MODE = "edge_dominant"

# Leave as None when both Python files are in the same folder.
# Otherwise set the full path, for example:
# SIMULATOR_PATH_OVERRIDE = r"C:\\Users\\Eman\\Downloads\\iot_blockchain_markov_final_all_attacks_post_attack_recovery.py"
SIMULATOR_PATH_OVERRIDE = None

SIMULATOR_FILENAME = "iot_blockchain_markov_final_all_attacks_post_attack_recovery.py"

# The result folder will be created beside this driver.
OUTPUT_FOLDER_NAME = f"repeated_10_runs_TPS_{TARGET_TPS // 1000:03d}K"

# True replaces an existing folder with the same name.
OVERWRITE_OUTPUT_FOLDER = True

# =============================================================================
# PATH HANDLING AND SAFE DYNAMIC IMPORT
# =============================================================================

try:
    DRIVER_DIR = Path(__file__).resolve().parent
except NameError:
    # This fallback is used only if the code is manually pasted into a notebook.
    DRIVER_DIR = Path.cwd()


def _resolve_simulator_path() -> Path:
    """Find the base simulator without relying on notebook-only variables."""
    candidates: List[Path] = []

    if SIMULATOR_PATH_OVERRIDE:
        candidates.append(Path(SIMULATOR_PATH_OVERRIDE).expanduser())

    candidates.extend([
        DRIVER_DIR / SIMULATOR_FILENAME,
        Path.cwd() / SIMULATOR_FILENAME,
        Path("/content") / SIMULATOR_FILENAME,  # Useful in Google Colab.
    ])

    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()

    searched = "\n".join(f"  - {p}" for p in candidates)
    raise FileNotFoundError(
        "The main simulator file was not found.\n\n"
        "Upload or place this file beside the driver:\n"
        f"  {SIMULATOR_FILENAME}\n\n"
        "Locations checked:\n"
        f"{searched}\n\n"
        "Or edit SIMULATOR_PATH_OVERRIDE at the top of this driver."
    )


def _load_simulator(simulator_path: Path):
    """Import the simulator as a module without running its __main__ block."""
    module_name = "iot_blockchain_repeated_single_tps_simulator"
    spec = importlib.util.spec_from_file_location(module_name, str(simulator_path))

    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load the simulator from: {simulator_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    required_functions = [
        "run_simulation",
        "summarize_simulation",
        "calculate_iot_qos_metrics",
        "compute_pre_during_post_attack_analysis",
    ]

    missing = [name for name in required_functions if not hasattr(module, name)]
    if missing:
        raise AttributeError(
            "The base simulator is missing these required functions: "
            + ", ".join(missing)
        )

    return module


# =============================================================================
# STATISTICAL AND CSV HELPERS
# =============================================================================

def _is_numeric(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, (numbers.Real, np.number)):
        try:
            return bool(np.isfinite(float(value)))
        except (TypeError, ValueError):
            return False
    return False


def _mean(values: Iterable[Any]) -> float:
    valid = [float(v) for v in values if _is_numeric(v)]
    return float(np.mean(valid)) if valid else 0.0


def _sample_sd(values: Iterable[Any]) -> float:
    """Sample standard deviation, using ddof=1."""
    valid = [float(v) for v in values if _is_numeric(v)]
    return float(np.std(valid, ddof=1)) if len(valid) > 1 else 0.0


def _write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> Path:
    path = Path(path)

    if not rows:
        path.write_text("", encoding="utf-8")
        return path

    fields: List[str] = []
    for row in rows:
        for field in row.keys():
            if field not in fields:
                fields.append(field)

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    return path


def _aggregate_mean_sd(rows: Sequence[Mapping[str, Any]]) -> Dict[str, float]:
    """Aggregate every numeric column from the repeated-run summaries."""
    numeric_columns = set()

    for row in rows:
        for key, value in row.items():
            if _is_numeric(value):
                numeric_columns.add(key)

    result: Dict[str, float] = {"n_runs": len(rows)}

    for key in sorted(numeric_columns):
        values = [row.get(key) for row in rows]
        result[f"{key}_mean"] = _mean(values)
        result[f"{key}_sd"] = _sample_sd(values)

    return result


# =============================================================================
# METRIC EXTRACTION
# =============================================================================

def _ewma_metrics(framework, threshold: float) -> Dict[str, Any]:
    """Epoch-level EWMA detection metrics for one completed run."""
    truth = np.asarray(framework.attack_campaign.truth_attack_epoch_flags, dtype=bool)
    ewma = np.asarray(framework.metrics.get("ewma_threat", []), dtype=float)
    n = min(len(truth), len(ewma))

    if n == 0:
        return {
            "ewma_precision": 0.0,
            "ewma_recall": 0.0,
            "ewma_f1": 0.0,
            "ewma_far": 0.0,
            "ewma_tp": 0,
            "ewma_fp": 0,
            "ewma_fn": 0,
            "ewma_tn": 0,
        }

    truth = truth[:n]
    predicted = ewma[:n] > float(threshold)

    tp = int(np.sum(predicted & truth))
    fp = int(np.sum(predicted & ~truth))
    fn = int(np.sum(~predicted & truth))
    tn = int(np.sum(~predicted & ~truth))

    precision = tp / max(1, tp + fp)
    recall = tp / max(1, tp + fn)
    f1 = 0.0 if precision + recall == 0 else 2.0 * precision * recall / (precision + recall)
    far = fp / max(1, fp + tn)

    return {
        "ewma_precision": precision,
        "ewma_recall": recall,
        "ewma_f1": f1,
        "ewma_far": far,
        "ewma_tp": tp,
        "ewma_fp": fp,
        "ewma_fn": fn,
        "ewma_tn": tn,
    }


def _build_run_summary(simulator, framework, run_number: int, seed: int) -> Dict[str, Any]:
    """Collect all main paper metrics from one completed simulation run."""
    summary = simulator.summarize_simulation(framework, float(TARGET_TPS))
    timing = framework.tx.timing_summary()
    qos = simulator.calculate_iot_qos_metrics(framework)
    detection = _ewma_metrics(framework, simulator.EWMA_THRESHOLD)
    trust = framework.markov_trust_model.current_state_distribution()

    row: Dict[str, Any] = {
        "run": int(run_number),
        "seed": int(seed),
        "target_tps": int(TARGET_TPS),
        "num_nodes": int(simulator.NUM_NODES),
        "num_shards": int(simulator.NUM_SHARDS),
        "deployment_mode": DEPLOYMENT_MODE,
    }

    row.update(summary)
    row.update(detection)

    row.update({
        "avg_confirmation_latency_ms": timing.get("avg_confirmation_latency_ms", 0.0),
        "avg_queue_wait_ms": timing.get("avg_queue_wait_ms", 0.0),
        "avg_service_time_ms": timing.get("avg_service_time_ms", 0.0),
        "avg_consensus_time_ms": timing.get("avg_consensus_time_ms", 0.0),
        "avg_finalization_time_ms": timing.get("avg_finalization_time_ms", 0.0),
        "critical_avg_latency_ms": timing.get("critical_avg_latency_ms", 0.0),
        "critical_p95_latency_ms": timing.get("critical_p95_latency_ms", 0.0),
        "critical_p99_latency_ms": timing.get("critical_p99_latency_ms", 0.0),
        "high_avg_latency_ms": timing.get("high_avg_latency_ms", 0.0),
        "medium_avg_latency_ms": timing.get("medium_avg_latency_ms", 0.0),
        "low_avg_latency_ms": timing.get("low_avg_latency_ms", 0.0),
        "qos_reliability": qos.get("reliability", 0.0),
        "qos_data_freshness": qos.get("data_freshness", 0.0),
        "qos_real_time_success_rate": qos.get("real_time_success_rate", 0.0),
        "qos_deadline_miss_ratio": qos.get("deadline_miss_ratio", 0.0),
        "qos_critical_p95_latency_ms": qos.get("critical_p95_latency_ms", 0.0),
        "total_blocks": framework.total_blocks,
        "block_production_rate_blocks_s": framework.total_blocks / max(1e-9, framework.sim_t),
        "final_trusted": trust.get("TRUSTED", 0.0),
        "final_neutral": trust.get("NEUTRAL", 0.0),
        "final_risky": trust.get("RISKY", 0.0),
        "final_malicious": trust.get("MALICIOUS", 0.0),
    })

    return row


def _format_mean_sd(mean: float, sd: float, decimals: int = 4) -> str:
    return f"{mean:.{decimals}f} ± {sd:.{decimals}f}"


def _write_final_report(path: Path, aggregate: Mapping[str, Any], results_dir: Path) -> Path:
    """Write and return the single final report displayed after all runs."""
    path = Path(path)

    with path.open("w", encoding="utf-8") as f:
        def write(text: str = "") -> None:
            f.write(text + "\n")

        write("=" * 100)
        write("REPEATED-RUN FINAL REPORT: ONE MANUAL TPS VALUE")
        write("=" * 100)
        write(f"Target offered load: {TARGET_TPS:,} TPS")
        write(f"Independent runs: {NUMBER_OF_RUNS}")
        write(f"Fixed number of nodes: {FIXED_NUM_NODES}")
        write(f"Fixed number of shards: {aggregate.get('num_shards_mean', 0):.0f}")
        write(f"Deployment mode: {DEPLOYMENT_MODE}")
        write("Standard deviation: sample SD (ddof=1).")
        write(f"Individual reports folder: {results_dir / 'runs'}")
        write()

        write("=" * 100)
        write("OVERALL PERFORMANCE: MEAN ± SAMPLE SD")
        write("=" * 100)
        write(f"Achieved throughput (TPS):        {_format_mean_sd(aggregate.get('throughput_tps_mean', 0.0), aggregate.get('throughput_tps_sd', 0.0), 2)}")
        write(f"Average confirmation latency (ms): {_format_mean_sd(aggregate.get('avg_confirmation_latency_ms_mean', 0.0), aggregate.get('avg_confirmation_latency_ms_sd', 0.0), 3)}")
        write(f"Critical average latency (ms):     {_format_mean_sd(aggregate.get('critical_avg_latency_ms_mean', 0.0), aggregate.get('critical_avg_latency_ms_sd', 0.0), 3)}")
        write(f"Critical P95 latency (ms):        {_format_mean_sd(aggregate.get('critical_p95_latency_ms_mean', 0.0), aggregate.get('critical_p95_latency_ms_sd', 0.0), 3)}")
        write(f"Critical P99 latency (ms):        {_format_mean_sd(aggregate.get('critical_p99_latency_ms_mean', 0.0), aggregate.get('critical_p99_latency_ms_sd', 0.0), 3)}")
        write(f"Real-time success rate:           {_format_mean_sd(aggregate.get('real_time_success_rate_mean', 0.0), aggregate.get('real_time_success_rate_sd', 0.0), 4)}")
        write(f"Deadline-miss ratio:              {_format_mean_sd(aggregate.get('deadline_miss_ratio_mean', 0.0), aggregate.get('deadline_miss_ratio_sd', 0.0), 4)}")
        write(f"Pending transactions at end:      {_format_mean_sd(aggregate.get('pending_tx_mean', 0.0), aggregate.get('pending_tx_sd', 0.0), 2)}")
        write()

        write("=" * 100)
        write("TIMING DECOMPOSITION: MEAN ± SAMPLE SD")
        write("=" * 100)
        write(f"Queue waiting time (ms):          {_format_mean_sd(aggregate.get('avg_queue_wait_ms_mean', 0.0), aggregate.get('avg_queue_wait_ms_sd', 0.0), 3)}")
        write(f"Service time (ms):                {_format_mean_sd(aggregate.get('avg_service_time_ms_mean', 0.0), aggregate.get('avg_service_time_ms_sd', 0.0), 3)}")
        write(f"Consensus time (ms):              {_format_mean_sd(aggregate.get('avg_consensus_time_ms_mean', 0.0), aggregate.get('avg_consensus_time_ms_sd', 0.0), 3)}")
        write(f"Finalization overhead (ms):       {_format_mean_sd(aggregate.get('avg_finalization_time_ms_mean', 0.0), aggregate.get('avg_finalization_time_ms_sd', 0.0), 3)}")
        write()

        write("=" * 100)
        write("QUEUE, ENERGY, AND TRUST: MEAN ± SAMPLE SD")
        write("=" * 100)
        write(f"Average shard utilization rho:    {_format_mean_sd(aggregate.get('avg_shard_rho_mean', 0.0), aggregate.get('avg_shard_rho_sd', 0.0), 4)}")
        write(f"Maximum shard rho:                {_format_mean_sd(aggregate.get('avg_max_shard_rho_mean', 0.0), aggregate.get('avg_max_shard_rho_sd', 0.0), 4)}")
        write(f"Overloaded shards:                {_format_mean_sd(aggregate.get('avg_overloaded_shards_mean', 0.0), aggregate.get('avg_overloaded_shards_sd', 0.0), 3)}")
        write(f"Average active validators:        {_format_mean_sd(aggregate.get('avg_validators_mean', 0.0), aggregate.get('avg_validators_sd', 0.0), 2)}")
        write(f"Total modeled energy (Wh):        {_format_mean_sd(aggregate.get('total_energy_wh_mean', 0.0), aggregate.get('total_energy_wh_sd', 0.0), 6)}")
        write(f"Energy per transaction (Wh/tx):   {_format_mean_sd(aggregate.get('energy_per_tx_wh_mean', 0.0), aggregate.get('energy_per_tx_wh_sd', 0.0), 8)}")
        write(f"Final trusted proportion:         {_format_mean_sd(aggregate.get('final_trusted_mean', 0.0), aggregate.get('final_trusted_sd', 0.0), 4)}")
        write(f"Final malicious proportion:       {_format_mean_sd(aggregate.get('final_malicious_mean', 0.0), aggregate.get('final_malicious_sd', 0.0), 4)}")
        write()

        write("=" * 100)
        write("EWMA EPOCH-LEVEL DETECTION QUALITY: MEAN ± SAMPLE SD")
        write("=" * 100)
        write(f"Precision:                        {_format_mean_sd(aggregate.get('ewma_precision_mean', 0.0), aggregate.get('ewma_precision_sd', 0.0), 4)}")
        write(f"Recall:                           {_format_mean_sd(aggregate.get('ewma_recall_mean', 0.0), aggregate.get('ewma_recall_sd', 0.0), 4)}")
        write(f"F1-score:                         {_format_mean_sd(aggregate.get('ewma_f1_mean', 0.0), aggregate.get('ewma_f1_sd', 0.0), 4)}")
        write(f"False-alarm rate:                 {_format_mean_sd(aggregate.get('ewma_far_mean', 0.0), aggregate.get('ewma_far_sd', 0.0), 4)}")
        write()

        write("=" * 100)
        write("FILES CREATED")
        write("=" * 100)
        write(f"runs/run_01_full_report.txt ... runs/run_{NUMBER_OF_RUNS:02d}_full_report.txt")
        write("raw_run_results.csv")
        write("mean_sd_summary.csv")
        write("final_report.txt")
        write("package.zip")
        write()
        write("Important interpretation note:")
        write("All results are simulation-based outputs of the modeled IoT blockchain framework.")
        write("=" * 100)

    return path


# =============================================================================
# MAIN EXECUTION FUNCTION
# =============================================================================

def run_repeated_single_tps_experiment() -> Dict[str, Path]:
    """Run one manually selected TPS value exactly NUMBER_OF_RUNS times."""
    simulator_path = _resolve_simulator_path()
    simulator = _load_simulator(simulator_path)

    original_num_nodes = simulator.NUM_NODES
    simulator.NUM_NODES = int(FIXED_NUM_NODES)

    output_dir = DRIVER_DIR / OUTPUT_FOLDER_NAME
    runs_dir = output_dir / "runs"

    if output_dir.exists():
        if OVERWRITE_OUTPUT_FOLDER:
            shutil.rmtree(output_dir)
        else:
            raise FileExistsError(
                f"The output folder already exists: {output_dir}\n"
                "Change OUTPUT_FOLDER_NAME or set OVERWRITE_OUTPUT_FOLDER = True."
            )

    output_dir.mkdir(parents=True, exist_ok=True)
    runs_dir.mkdir(parents=True, exist_ok=True)

    run_rows: List[Dict[str, Any]] = []

    try:
        for run_number in range(1, int(NUMBER_OF_RUNS) + 1):
            seed = int(SEED_BASE + run_number - 1)
            random.seed(seed)
            np.random.seed(seed)

            report_path = runs_dir / f"run_{run_number:02d}_full_report.txt"

            # verbose=False suppresses epoch messages and individual reports.
            framework = simulator.run_simulation(
                target_tps=float(TARGET_TPS),
                report_path=str(report_path),
                verbose=False,
                deployment_mode=DEPLOYMENT_MODE,
            )

            run_rows.append(_build_run_summary(simulator, framework, run_number, seed))

        raw_csv = _write_csv(output_dir / "raw_run_results.csv", run_rows)
        aggregate = _aggregate_mean_sd(run_rows)
        aggregate.update({
            "target_tps": int(TARGET_TPS),
            "fixed_num_nodes": int(FIXED_NUM_NODES),
            "deployment_mode": DEPLOYMENT_MODE,
        })
        mean_sd_csv = _write_csv(output_dir / "mean_sd_summary.csv", [aggregate])

        final_report = _write_final_report(
            output_dir / "final_report.txt",
            aggregate,
            output_dir,
        )

        # Copy the exact driver and simulator used into the output folder.
        shutil.copy2(simulator_path, output_dir / simulator_path.name)
        try:
            shutil.copy2(Path(__file__).resolve(), output_dir / Path(__file__).name)
        except NameError:
            pass

        zip_path = Path(
            shutil.make_archive(
                base_name=str(output_dir),
                format="zip",
                root_dir=str(output_dir),
            )
        )

        # The user requested that only one final report appear after all runs.
        print(final_report.read_text(encoding="utf-8"))

        return {
            "output_dir": output_dir,
            "runs_dir": runs_dir,
            "raw_csv": raw_csv,
            "mean_sd_csv": mean_sd_csv,
            "final_report": final_report,
            "zip_path": zip_path,
        }

    finally:
        simulator.NUM_NODES = original_num_nodes


# =============================================================================
# RUN AUTOMATICALLY WHEN EXECUTED AS A PYTHON FILE OR WITH %run
# =============================================================================

# Disabled here; a bundled direct runner is defined below.
if False:
    run_repeated_single_tps_experiment()



# =============================================================================
# BUNDLED ONE-FILE RUNNER (NO SEPARATE SIMULATOR FILE REQUIRED)
# =============================================================================
# Edit only TARGET_TPS near the top of this file. NUMBER_OF_RUNS remains 10.
# This function uses the simulator code already contained in this same file.

def run_repeated_single_tps_experiment() -> Dict[str, Path]:
    """Run one manually selected TPS value exactly NUMBER_OF_RUNS times.

    Every run is stored in its own TXT file. Only the final aggregated report
    is printed after all repetitions finish.
    """
    simulator = sys.modules[__name__]
    original_num_nodes = simulator.NUM_NODES
    simulator.NUM_NODES = int(FIXED_NUM_NODES)

    output_dir = DRIVER_DIR / OUTPUT_FOLDER_NAME
    runs_dir = output_dir / "runs"
    if output_dir.exists():
        if OVERWRITE_OUTPUT_FOLDER:
            shutil.rmtree(output_dir)
        else:
            raise FileExistsError(
                f"The output folder already exists: {output_dir}\n"
                "Change OUTPUT_FOLDER_NAME or set OVERWRITE_OUTPUT_FOLDER = True."
            )
    output_dir.mkdir(parents=True, exist_ok=True)
    runs_dir.mkdir(parents=True, exist_ok=True)
    run_rows: List[Dict[str, Any]] = []

    try:
        for run_number in range(1, int(NUMBER_OF_RUNS) + 1):
            seed = int(SEED_BASE + run_number - 1)
            random.seed(seed)
            np.random.seed(seed)
            report_path = runs_dir / f"run_{run_number:02d}_full_report.txt"
            framework = simulator.run_simulation(
                target_tps=float(TARGET_TPS),
                report_path=str(report_path),
                verbose=False,
                deployment_mode=DEPLOYMENT_MODE,
            )
            run_rows.append(_build_run_summary(simulator, framework, run_number, seed))

        raw_csv = _write_csv(output_dir / "raw_run_results.csv", run_rows)
        aggregate = _aggregate_mean_sd(run_rows)
        aggregate.update({
            "target_tps": int(TARGET_TPS),
            "fixed_num_nodes": int(FIXED_NUM_NODES),
            "deployment_mode": DEPLOYMENT_MODE,
        })
        mean_sd_csv = _write_csv(output_dir / "mean_sd_summary.csv", [aggregate])
        final_report = _write_final_report(output_dir / "final_report.txt", aggregate, output_dir)
        try:
            this_file = Path(__file__).resolve()
            shutil.copy2(this_file, output_dir / this_file.name)
        except NameError:
            pass
        zip_path = Path(shutil.make_archive(
            base_name=str(output_dir), format="zip", root_dir=str(output_dir)
        ))
        print(final_report.read_text(encoding="utf-8"))
        return {
            "output_dir": output_dir,
            "runs_dir": runs_dir,
            "raw_csv": raw_csv,
            "mean_sd_csv": mean_sd_csv,
            "final_report": final_report,
            "zip_path": zip_path,
        }
    finally:
        simulator.NUM_NODES = original_num_nodes


if __name__ == "__main__":
    run_repeated_single_tps_experiment()
