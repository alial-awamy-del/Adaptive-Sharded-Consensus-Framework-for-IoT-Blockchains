# -*- coding: utf-8 -*-
"""
ENHANCED MARKOV CHAIN TRUST MODEL - FULL ANALYSIS
Images saved to separate folder
"""

import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import random
import os

# ============================================================
# إنشاء مجلد خاص للصور
# ============================================================
# المجلد الحالي للنتائج
CURRENT_DIR = os.getcwd()

# إنشاء مجلد للصور داخل مجلد النتائج
IMAGES_FOLDER = os.path.join(CURRENT_DIR, "markov_images")

# إنشاء المجلد إذا لم يكن موجوداً
if not os.path.exists(IMAGES_FOLDER):
    os.makedirs(IMAGES_FOLDER)
    print(f"Created images folder: {IMAGES_FOLDER}")

print(f"\nSaving images to: {IMAGES_FOLDER}")

TRANSITION_MATRIX = np.array([
    [0.85, 0.10, 0.04, 0.01],
    [0.20, 0.65, 0.12, 0.03],
    [0.10, 0.30, 0.50, 0.10],
    [0.05, 0.15, 0.20, 0.60]
])

STATE_NAMES = {0: "TRUSTED", 1: "NEUTRAL", 2: "RISKY", 3: "MALICIOUS"}

CONVERGENCE_THRESHOLD = 0.05
CONVERGENCE_WINDOW = 20

def compute_stationary_distribution(P):
    n = P.shape[0]
    A = P.T - np.eye(n)
    A[-1] = np.ones(n)
    b = np.zeros(n)
    b[-1] = 1.0
    
    try:
        pi = np.linalg.solve(A, b)
        pi = np.maximum(pi, 0) / np.sum(np.maximum(pi, 0))
    except np.linalg.LinAlgError:
        pi = np.ones(n) / n
        for _ in range(1000):
            pi_new = pi @ P
            if np.linalg.norm(pi_new - pi) < 1e-10:
                break
            pi = pi_new
        pi = pi / np.sum(pi)
    
    return pi

class BaselineMarkovChain:
    def __init__(self, num_validators, transition_matrix, initial_distribution=None):
        self.num_validators = num_validators
        self.P = transition_matrix.copy()
        self.n_states = self.P.shape[0]
        
        if initial_distribution is None:
            self.current_states = np.zeros(num_validators, dtype=int)
        else:
            self.current_states = np.random.choice(
                self.n_states, size=num_validators, p=initial_distribution
            )
        
        self.state_history = [self.current_states.copy()]
        self.distribution_history = []
        self._record_distribution()
    
    def _record_distribution(self):
        counts = np.bincount(self.current_states, minlength=self.n_states)
        distribution = counts / self.num_validators
        self.distribution_history.append(distribution)
    
    def step(self):
        new_states = np.zeros(self.num_validators, dtype=int)
        
        for i in range(self.num_validators):
            current = self.current_states[i]
            probs = self.P[current]
            new_states[i] = np.random.choice(self.n_states, p=probs)
        
        self.current_states = new_states
        self.state_history.append(self.current_states.copy())
        self._record_distribution()
        
        return self.current_states
    
    def run(self, num_epochs):
        for _ in range(num_epochs):
            self.step()
        return self
    
    def get_current_distribution(self):
        return self.distribution_history[-1]
    
    def get_distribution_history(self):
        return np.array(self.distribution_history)
    
    def get_distance_to_stationary(self, stationary_dist):
        current_dist = self.get_current_distribution()
        return np.linalg.norm(current_dist - stationary_dist)
    
    def get_convergence_epoch(self, stationary_dist, threshold=CONVERGENCE_THRESHOLD, window=CONVERGENCE_WINDOW):
        distances = []
        for dist in self.distribution_history:
            distances.append(np.linalg.norm(dist - stationary_dist))
        
        for i in range(len(distances) - window):
            if all(d < threshold for d in distances[i:i+window]):
                return i
        return None

class AdaptiveMarkovChain:
    def __init__(self, num_validators, transition_matrix, initial_distribution=None):
        self.num_validators = num_validators
        self.base_P = transition_matrix.copy()
        self.n_states = self.base_P.shape[0]
        
        if initial_distribution is None:
            self.current_states = np.zeros(num_validators, dtype=int)
        else:
            self.current_states = np.random.choice(
                self.n_states, size=num_validators, p=initial_distribution
            )
        
        self.state_history = [self.current_states.copy()]
        self.distribution_history = []
        self._record_distribution()
    
    def _record_distribution(self):
        counts = np.bincount(self.current_states, minlength=self.n_states)
        distribution = counts / self.num_validators
        self.distribution_history.append(distribution)
    
    def _modify_transition_probs(self, current_state, behavior_score, attack_flag, consensus_success):
        probs = self.base_P[current_state].copy()
        
        if behavior_score >= 90:
            probs[0] += 0.08
            probs[1] += 0.03
            probs[3] -= 0.05
        elif behavior_score <= 40:
            probs[0] -= 0.08
            probs[2] += 0.10
        elif behavior_score <= 20:
            probs[3] += 0.15
            probs[0] -= 0.05
        
        if attack_flag:
            probs[2] += 0.10
            probs[3] += 0.05
            probs[0] -= 0.05
        
        if consensus_success:
            probs[0] += 0.02
            probs[1] += 0.01
        else:
            probs[2] += 0.05
            probs[0] -= 0.03
        
        probs = np.maximum(probs, 0)
        probs = probs / np.sum(probs)
        
        return probs
    
    def step(self, behavior_scores, attack_flags, consensus_success):
        new_states = np.zeros(self.num_validators, dtype=int)
        
        for i in range(self.num_validators):
            current = self.current_states[i]
            probs = self._modify_transition_probs(
                current, behavior_scores[i], attack_flags[i], consensus_success[i]
            )
            new_states[i] = np.random.choice(self.n_states, p=probs)
        
        self.current_states = new_states
        self.state_history.append(self.current_states.copy())
        self._record_distribution()
        
        return self.current_states
    
    def run(self, num_epochs):
        for epoch in range(num_epochs):
            if 50 <= epoch <= 100:
                behavior_scores = np.random.normal(45, 15, self.num_validators)
                attack_flags = np.random.random(self.num_validators) < 0.3
                consensus_success = np.random.random(self.num_validators) < 0.7
            elif epoch > 100 and epoch < 150:
                behavior_scores = np.random.normal(65, 12, self.num_validators)
                attack_flags = np.random.random(self.num_validators) < 0.1
                consensus_success = np.random.random(self.num_validators) < 0.85
            else:
                behavior_scores = np.random.normal(85, 10, self.num_validators)
                attack_flags = np.random.random(self.num_validators) < 0.02
                consensus_success = np.random.random(self.num_validators) < 0.95
            
            behavior_scores = np.clip(behavior_scores, 0, 100)
            self.step(behavior_scores, attack_flags, consensus_success)
        
        return self
    
    def get_current_distribution(self):
        return self.distribution_history[-1]
    
    def get_distribution_history(self):
        return np.array(self.distribution_history)
    
    def get_distance_to_stationary(self, stationary_dist):
        current_dist = self.get_current_distribution()
        return np.linalg.norm(current_dist - stationary_dist)

def run_multiple_seeds_analysis(num_validators=100, num_epochs=500, num_runs=50):
    print("\n" + "="*80)
    print("1. MULTIPLE RUNS ANALYSIS (50 runs with different seeds)")
    print("="*80)
    
    stationary_dist = compute_stationary_distribution(TRANSITION_MATRIX)
    
    results = {
        'final_distributions': [],
        'initial_distances': [],
        'final_distances': [],
        'distance_reductions': [],
        'convergence_epochs': []
    }
    
    for run_id in range(num_runs):
        seed = 1000 + run_id
        np.random.seed(seed)
        random.seed(seed)
        
        model = BaselineMarkovChain(num_validators, TRANSITION_MATRIX)
        initial_dist = model.get_current_distribution()
        initial_distance = np.linalg.norm(initial_dist - stationary_dist)
        
        model.run(num_epochs)
        
        final_dist = model.get_current_distribution()
        final_distance = np.linalg.norm(final_dist - stationary_dist)
        distance_reduction = (initial_distance - final_distance) / initial_distance * 100 if initial_distance > 0 else 0
        
        convergence_epoch = model.get_convergence_epoch(stationary_dist)
        
        results['final_distributions'].append(final_dist)
        results['initial_distances'].append(initial_distance)
        results['final_distances'].append(final_distance)
        results['distance_reductions'].append(distance_reduction)
        results['convergence_epochs'].append(convergence_epoch if convergence_epoch else num_epochs)
        
        if (run_id + 1) % 10 == 0:
            print(f"  Run {run_id+1}/{num_runs} completed")
    
    final_dist_mean = np.mean(results['final_distributions'], axis=0)
    final_dist_std = np.std(results['final_distributions'], axis=0)
    
    print(f"\n{'='*60}")
    print("RESULTS (Mean ± Std over 50 runs):")
    print(f"{'='*60}")
    print(f"\nFinal State Distribution:")
    for i, name in STATE_NAMES.items():
        print(f"  {name:10s}: {final_dist_mean[i]*100:6.2f}% ± {final_dist_std[i]*100:5.2f}%")
    
    print(f"\nInitial Distance to Stationary: {np.mean(results['initial_distances']):.4f} ± {np.std(results['initial_distances']):.4f}")
    print(f"Final Distance to Stationary:   {np.mean(results['final_distances']):.4f} ± {np.std(results['final_distances']):.4f}")
    print(f"Distance Reduction:             {np.mean(results['distance_reductions']):.1f}% ± {np.std(results['distance_reductions']):.1f}%")
    
    converged_count = sum(1 for e in results['convergence_epochs'] if e < num_epochs)
    print(f"Converged within {num_epochs} epochs: {converged_count}/{num_runs} ({converged_count/num_runs*100:.1f}%)")
    
    return results

def run_epoch_horizon_analysis(num_validators=100, horizons=[200, 500, 1000], num_runs=30):
    print("\n" + "="*80)
    print("2. EPOCH HORIZON ANALYSIS")
    print("="*80)
    
    stationary_dist = compute_stationary_distribution(TRANSITION_MATRIX)
    results = {}
    
    for horizon in horizons:
        print(f"\n  Testing horizon: {horizon} epochs")
        
        final_distances = []
        distance_reductions = []
        
        for run_id in range(num_runs):
            seed = 2000 + run_id
            np.random.seed(seed)
            random.seed(seed)
            
            model = BaselineMarkovChain(num_validators, TRANSITION_MATRIX)
            initial_dist = model.get_current_distribution()
            initial_distance = np.linalg.norm(initial_dist - stationary_dist)
            
            model.run(horizon)
            
            final_dist = model.get_current_distribution()
            final_distance = np.linalg.norm(final_dist - stationary_dist)
            reduction = (initial_distance - final_distance) / initial_distance * 100 if initial_distance > 0 else 0
            
            final_distances.append(final_distance)
            distance_reductions.append(reduction)
        
        results[horizon] = {
            'final_distance_mean': np.mean(final_distances),
            'final_distance_std': np.std(final_distances),
            'reduction_mean': np.mean(distance_reductions),
            'reduction_std': np.std(distance_reductions)
        }
        
        print(f"    Final Distance: {results[horizon]['final_distance_mean']:.4f} ± {results[horizon]['final_distance_std']:.4f}")
        print(f"    Reduction: {results[horizon]['reduction_mean']:.1f}% ± {results[horizon]['reduction_std']:.1f}%")
    
    print("\n" + "="*60)
    print("SUMMARY TABLE: Epoch Horizon Analysis")
    print("="*60)
    print(f"{'Horizon (epochs)':<18} | {'Final Distance':>15} | {'Reduction (%)':>15}")
    print("-" * 55)
    for horizon in horizons:
        print(f"{horizon:<18} | {results[horizon]['final_distance_mean']:15.4f} | {results[horizon]['reduction_mean']:15.1f}")
    print("-" * 55)
    
    return results

def plot_convergence(num_validators=100, num_epochs=500):
    print("\n" + "="*80)
    print("3. CONVERGENCE PLOT")
    print("="*80)
    
    stationary_dist = compute_stationary_distribution(TRANSITION_MATRIX)
    
    model = BaselineMarkovChain(num_validators, TRANSITION_MATRIX)
    
    distances = []
    distributions = []
    
    for epoch in range(num_epochs):
        model.step()
        dist = model.get_current_distribution()
        distributions.append(dist)
        distances.append(np.linalg.norm(dist - stationary_dist))
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    axes[0].plot(distances, linewidth=2, color='blue')
    axes[0].axhline(y=CONVERGENCE_THRESHOLD, color='r', linestyle='--', 
                    label=f'Threshold ({CONVERGENCE_THRESHOLD})')
    axes[0].set_xlabel('Epoch', fontsize=12)
    axes[0].set_ylabel('L2 Distance to Stationary Distribution', fontsize=12)
    axes[0].set_title('(a) Convergence to Stationary Distribution', fontsize=14)
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    distributions = np.array(distributions)
    axes[1].plot(distributions[:, 0], 'b-', label='TRUSTED', linewidth=2)
    axes[1].plot(distributions[:, 1], 'g-', label='NEUTRAL', linewidth=2)
    axes[1].plot(distributions[:, 2], 'orange', label='RISKY', linewidth=2)
    axes[1].plot(distributions[:, 3], 'r-', label='MALICIOUS', linewidth=2)
    
    axes[1].axhline(y=stationary_dist[0], color='b', linestyle='--', alpha=0.5)
    axes[1].axhline(y=stationary_dist[1], color='g', linestyle='--', alpha=0.5)
    axes[1].axhline(y=stationary_dist[2], color='orange', linestyle='--', alpha=0.5)
    axes[1].axhline(y=stationary_dist[3], color='r', linestyle='--', alpha=0.5)
    
    axes[1].set_xlabel('Epoch', fontsize=12)
    axes[1].set_ylabel('Proportion of Validators', fontsize=12)
    axes[1].set_title('(b) State Distribution Evolution', fontsize=14)
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # حفظ الصورة في المجلد المخصص
    plot_path = os.path.join(IMAGES_FOLDER, 'fig1_convergence_analysis.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.show()
    
    print(f"\n  Plot saved to: {plot_path}")
    
    return distances

def run_initial_distribution_analysis(num_validators=100, num_epochs=500, num_runs=30):
    print("\n" + "="*80)
    print("4. DIFFERENT INITIAL DISTRIBUTIONS ANALYSIS")
    print("="*80)
    
    stationary_dist = compute_stationary_distribution(TRANSITION_MATRIX)
    
    initial_distributions = {
        "Optimistic (90% TRUSTED)": np.array([0.90, 0.05, 0.03, 0.02]),
        "Balanced (25% each)": np.array([0.25, 0.25, 0.25, 0.25]),
        "Pessimistic (40% RISKY, 30% MALICIOUS)": np.array([0.10, 0.20, 0.40, 0.30]),
    }
    
    results = {}
    
    for name, init_dist in initial_distributions.items():
        print(f"\n  Testing: {name}")
        
        final_distributions = []
        final_distances = []
        
        for run_id in range(num_runs):
            seed = 3000 + run_id
            np.random.seed(seed)
            random.seed(seed)
            
            model = BaselineMarkovChain(num_validators, TRANSITION_MATRIX, init_dist)
            model.run(num_epochs)
            
            final_dist = model.get_current_distribution()
            final_distributions.append(final_dist)
            final_distances.append(np.linalg.norm(final_dist - stationary_dist))
        
        final_dist_mean = np.mean(final_distributions, axis=0)
        final_dist_std = np.std(final_distributions, axis=0)
        
        results[name] = {
            'final_dist_mean': final_dist_mean,
            'final_dist_std': final_dist_std,
            'final_distance_mean': np.mean(final_distances),
            'final_distance_std': np.std(final_distances)
        }
        
        print(f"    Final TRUSTED: {final_dist_mean[0]*100:.1f}±{final_dist_std[0]*100:.1f}%")
        print(f"    Final MALICIOUS: {final_dist_mean[3]*100:.1f}±{final_dist_std[3]*100:.1f}%")
    
    print("\n" + "="*60)
    print("SUMMARY: Initial Distribution Analysis")
    print("="*60)
    for name, res in results.items():
        print(f"  {name}: TRUSTED={res['final_dist_mean'][0]*100:.1f}%, Distance={res['final_distance_mean']:.4f}")
    
    return results

def compare_baseline_vs_adaptive(num_validators=100, num_epochs=500, num_runs=30):
    print("\n" + "="*80)
    print("5. BASELINE vs ADAPTIVE MARKOV CHAIN COMPARISON")
    print("="*80)
    
    stationary_dist = compute_stationary_distribution(TRANSITION_MATRIX)
    
    baseline_results = {'final_distances': [], 'final_distributions': []}
    adaptive_results = {'final_distances': [], 'final_distributions': []}
    
    for run_id in range(num_runs):
        seed = 4000 + run_id
        np.random.seed(seed)
        random.seed(seed)
        
        baseline = BaselineMarkovChain(num_validators, TRANSITION_MATRIX)
        baseline.run(num_epochs)
        baseline_final_dist = baseline.get_current_distribution()
        baseline_results['final_distributions'].append(baseline_final_dist)
        baseline_results['final_distances'].append(np.linalg.norm(baseline_final_dist - stationary_dist))
        
        adaptive = AdaptiveMarkovChain(num_validators, TRANSITION_MATRIX)
        adaptive.run(num_epochs)
        adaptive_final_dist = adaptive.get_current_distribution()
        adaptive_results['final_distributions'].append(adaptive_final_dist)
        adaptive_results['final_distances'].append(np.linalg.norm(adaptive_final_dist - stationary_dist))
        
        if (run_id + 1) % 10 == 0:
            print(f"  Run {run_id+1}/{num_runs} completed")
    
    print("\n" + "="*60)
    print("COMPARISON RESULTS")
    print("="*60)
    
    baseline_dist_mean = np.mean(baseline_results['final_distributions'], axis=0)
    adaptive_dist_mean = np.mean(adaptive_results['final_distributions'], axis=0)
    
    print(f"\n{'State':<12} | {'Baseline (%)':>15} | {'Adaptive (%)':>15} | {'Difference':>12}")
    print("-" * 60)
    for i, name in STATE_NAMES.items():
        diff = adaptive_dist_mean[i] - baseline_dist_mean[i]
        sign = "+" if diff > 0 else ""
        print(f"{name:<12} | {baseline_dist_mean[i]*100:14.2f}% | {adaptive_dist_mean[i]*100:14.2f}% | {sign}{diff*100:11.2f}%")
    
    print(f"\nFinal Distance to Stationary:")
    print(f"  Baseline: {np.mean(baseline_results['final_distances']):.4f} ± {np.std(baseline_results['final_distances']):.4f}")
    print(f"  Adaptive: {np.mean(adaptive_results['final_distances']):.4f} ± {np.std(adaptive_results['final_distances']):.4f}")
    
    # حفظ نتائج المقارنة كصورة
    fig, ax = plt.subplots(figsize=(10, 6))
    
    states = list(STATE_NAMES.values())
    baseline_vals = baseline_dist_mean * 100
    adaptive_vals = adaptive_dist_mean * 100
    
    x = np.arange(len(states))
    width = 0.35
    
    bars1 = ax.bar(x - width/2, baseline_vals, width, label='Baseline (Fixed)', color='blue', alpha=0.7)
    bars2 = ax.bar(x + width/2, adaptive_vals, width, label='Adaptive', color='green', alpha=0.7)
    
    ax.set_ylabel('Percentage (%)', fontsize=12)
    ax.set_title('Baseline vs Adaptive Markov Chain Comparison', fontsize=14)
    ax.set_xticks(x)
    ax.set_xticklabels(states)
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    for bar, val in zip(bars1, baseline_vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5, f'{val:.1f}%', ha='center', va='bottom', fontsize=9)
    for bar, val in zip(bars2, adaptive_vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5, f'{val:.1f}%', ha='center', va='bottom', fontsize=9)
    
    plt.tight_layout()
    
    comparison_plot_path = os.path.join(IMAGES_FOLDER, 'fig2_baseline_vs_adaptive.png')
    plt.savefig(comparison_plot_path, dpi=300, bbox_inches='tight')
    plt.show()
    
    print(f"\n  Comparison plot saved to: {comparison_plot_path}")
    
    return baseline_results, adaptive_results



# ============================================================
# SECTION 5.2.2 AUDIT EXTENSION
# Original Markov classes and original P are above (unaltered).
# ============================================================
import argparse as _argparse
import csv as _csv
import hashlib as _hashlib
import json as _json
from pathlib import Path as _Path
from scipy import stats as _stats
import sys as _sys


def _save(path, rows):
    if not rows:
        return
    path = _Path(path)
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        cols = list(rows[0].keys())
        w = _csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)


def _summary(xs):
    a = np.asarray(xs, dtype=float)
    return {'n':int(len(a)), 'mean':float(np.mean(a)), 'sd_sample':float(np.std(a,ddof=1)) if len(a)>1 else None, 'sd_legacy_population':float(np.std(a,ddof=0))}


def _corrected_transition(self, current_state, behavior_score, attack_flag, consensus_success):
    """Sensitivity ONLY. Fix unreachable <=20 branch, keeping all other rules."""
    probs = self.base_P[current_state].copy()
    if behavior_score >= 90:
        probs[0] += 0.08
        probs[1] += 0.03
        probs[3] -= 0.05
    elif behavior_score <= 20: # moved BEFORE <=40
        probs[3] += 0.15
        probs[0] -= 0.05
    elif behavior_score <= 40:
        probs[0] -= 0.08
        probs[2] += 0.10
    if attack_flag:
        probs[2] += 0.10
        probs[3] += 0.05
        probs[0] -= 0.05
    if consensus_success:
        probs[0] += 0.02
        probs[1] += 0.01
    else:
        probs[2] += 0.05
        probs[0] -= 0.03
    probs = np.maximum(probs, 0)
    return probs / np.sum(probs)


def _create_adaptive(n, variant):
    m = AdaptiveMarkovChain(n, TRANSITION_MATRIX)
    if variant == 'corrected':
        import types
        m._modify_transition_probs = types.MethodType(_corrected_transition, m)
    return m


def _process_summary_rows(rows, group_fields, metrics):
    groups = defaultdict(list)
    for r in rows:
        groups[tuple(r[x] for x in group_fields)].append(r)
    out = []
    for keys, group in sorted(groups.items(), key=lambda k: str(k[0])):
        for m in metrics:
            vals = [float(g[m]) for g in group if m in g and g[m] is not None and np.isfinite(float(g[m]))]
            if vals:
                out.append(dict(zip(group_fields,keys),metric=m,**_summary(vals)))
    return out


def _run_baseline_convergence(n, epochs, runs, output, stationary):
    raw, traces = [], []
    for j in range(runs):
        seed = 1000+j
        np.random.seed(seed); random.seed(seed)
        model = BaselineMarkovChain(n, TRANSITION_MATRIX)
        model.run(epochs)
        dist = model.get_distribution_history()
        d = np.linalg.norm(dist-stationary[None,:],axis=1)
        initial, final = float(d[0]),float(d[-1])
        # The source checks 20 consecutive observations and does not include the final
        # possible window (off-by-one). We report both source and inclusive corrected scan.
        source_epoch = model.get_convergence_epoch(stationary)
        inclusive_epoch = next((i for i in range(len(d)-CONVERGENCE_WINDOW+1)
                if np.all(d[i:i+CONVERGENCE_WINDOW] < CONVERGENCE_THRESHOLD)),None)
        rec={'run':j+1,'seed':seed,'num_entities':n,'epochs':epochs,
             'initial_l2':initial,'final_l2':final,
             'reduction_pct':100*(initial-final)/initial,
             'source_convergence_epoch':source_epoch,
             'source_converged':int(source_epoch is not None),
             'inclusive_convergence_epoch':inclusive_epoch,
             'inclusive_converged':int(inclusive_epoch is not None)}
        for k, name in STATE_NAMES.items():
            rec['final_'+name.lower()+'_pct'] = float(dist[-1,k]*100)
        raw.append(rec)
        for ep in range(epochs+1):
            row={'run':j+1,'epoch':ep,'l2_distance':float(d[ep])}
            for k,name in STATE_NAMES.items():
                row[name.lower()+'_pct']=float(dist[ep,k]*100)
            traces.append(row)
        print(f'Convergence: {j+1}/{runs}',flush=True)
    _save(output/'convergence_per_run.csv',raw)
    _save(output/'convergence_trajectories.csv',traces)
    return raw,traces


def _run_horizon(n, horizons, runs, output, stationary):
    rows=[]
    for h in horizons:
        for j in range(runs):
            seed=2000+j; np.random.seed(seed);random.seed(seed)
            m=BaselineMarkovChain(n,TRANSITION_MATRIX)
            initial=float(np.linalg.norm(m.get_current_distribution()-stationary))
            m.run(h)
            d=float(np.linalg.norm(m.get_current_distribution()-stationary))
            rows.append({'horizon':h,'run':j+1,'seed':seed,'final_l2':d,'reduction_pct':100*(initial-d)/initial})
        print(f'Horizon: {h} epochs ({runs} runs)',flush=True)
    _save(output/'horizon_per_run.csv',rows)
    return rows


def _run_initial(n, epochs, runs, output, stationary):
    initial_distributions={
        'Optimistic':np.array([.90,.05,.03,.02]),
        'Balanced':np.array([.25,.25,.25,.25]),
        'Pessimistic':np.array([.10,.20,.40,.30])}
    rows=[]
    for name,pi in initial_distributions.items():
        for j in range(runs):
            seed=3000+j;np.random.seed(seed);random.seed(seed)
            m=BaselineMarkovChain(n,TRANSITION_MATRIX,pi)
            m.run(epochs)
            d=m.get_current_distribution()
            row={'initial_case':name,'run':j+1,'seed':seed,'final_l2':float(np.linalg.norm(d-stationary))}
            for k,s in STATE_NAMES.items():row['final_'+s.lower()+'_pct']=float(100*d[k])
            rows.append(row)
        print(f'Initial distribution: {name} ({runs} runs)',flush=True)
    _save(output/'initial_distribution_per_run.csv',rows)
    return rows


def _compare(n,epochs,runs,output,stationary,variant, mode):
    """legacy RNG mode reproduces original continuation of RNG stream.
       independent mode explicitly reseeds baseline/adaptive; neither is a
       fully matched exogenous trace, because the adaptive process draws extra
       stochastic inputs.
    """
    rows=[]
    for j in range(runs):
        seed=4000+j
        np.random.seed(seed);random.seed(seed)
        b=BaselineMarkovChain(n,TRANSITION_MATRIX)
        b.run(epochs)
        b_dist=b.get_current_distribution()
        # Original: no reseeding before adaptive -- legacy RNG continuation.
        if mode=='independent':
            np.random.seed(seed);random.seed(seed)
        a=_create_adaptive(n,variant)
        a.run(epochs)
        a_dist=a.get_current_distribution()
        for label,dist in [('Baseline',b_dist),('Adaptive',a_dist)]:
            rec={'variant':variant,'rng_mode':mode,'run':j+1,'seed':seed,
                 'process':label,'final_l2_to_fixed_stationary':float(np.linalg.norm(dist-stationary))}
            for k,s in STATE_NAMES.items():rec['final_'+s.lower()+'_pct']=float(100*dist[k])
            rows.append(rec)
        print(f'{variant} comparison: {j+1}/{runs}',flush=True)
    _save(output/('baseline_adaptive_'+variant+'_per_run.csv'),rows)
    return rows


def _paired_compare(rows, label):
    d = defaultdict(dict)
    for r in rows:d[r['run']][r['process']]=r
    metrics=['final_'+s.lower()+'_pct' for s in STATE_NAMES.values()]+['final_l2_to_fixed_stationary']
    results=[]
    for metric in metrics:
        diffs=np.array([float(p['Adaptive'][metric])-float(p['Baseline'][metric]) for p in d.values()])
        n=len(diffs)
        mean=float(diffs.mean()); sd=float(diffs.std(ddof=1)) if n>1 else float('nan')
        interval=float(_stats.t.ppf(.975,n-1)*sd/np.sqrt(n)) if n>1 else float('nan')
        results.append({'comparison':label,'metric':metric,'n':n,'mean_adaptive_minus_baseline':mean,
                        'sd_paired':sd,'ci95_lower':mean-interval,'ci95_upper':mean+interval,
                        'descriptive_only_due_to_nonmatched_random_events':True})
    return results


def _corrected_sensitivity(original,corrected,mode):
    def index(rows):
        return {(r['run'],r['process']):r for r in rows}
    orig, corr=index(original), index(corrected)
    out=[]
    for key in sorted(orig):
        if key[1]!='Adaptive':continue
        a,b=orig[key],corr[key]
        rec={'run':key[0],'seed':a['seed'],'rng_mode':mode}
        for field in ['final_'+s.lower()+'_pct' for s in STATE_NAMES.values()]+['final_l2_to_fixed_stationary']:
            rec['original_'+field]=a[field]
            rec['corrected_'+field]=b[field]
            rec['corrected_minus_original_'+field]=float(b[field])-float(a[field])
        out.append(rec)
    return out


def _make_figures(output,traces,comparison,stationary):
    # Deterministic plots backed by stored raw outputs.
    fig,axes=plt.subplots(1,2,figsize=(13,4.6))
    first=[x for x in traces if x['run']==1]
    epochs=np.array([x['epoch'] for x in first]);d=np.array([x['l2_distance'] for x in first])
    axes[0].plot(epochs,d,label='Run 1 L2 distance');axes[0].axhline(CONVERGENCE_THRESHOLD,ls='--',label='Threshold 0.05')
    axes[0].set(xlabel='Epoch',ylabel='L2 distance to fixed-chain stationary distribution');axes[0].legend()
    for k,s in STATE_NAMES.items():
        axes[1].plot(epochs,[x[s.lower()+'_pct'] for x in first],label=s)
        axes[1].axhline(100*stationary[k],ls=':',alpha=.4)
    axes[1].set(xlabel='Epoch',ylabel='Trust-state population share (%)');axes[1].legend(fontsize=8)
    fig.tight_layout();fig.savefig(output/'figure10_audit.png',dpi=200);plt.close(fig)
    means={name:[np.mean([r['final_'+s.lower()+'_pct'] for r in comparison if r['process']==name]) for s in STATE_NAMES.values()] for name in ['Baseline','Adaptive']}
    fig,ax=plt.subplots(figsize=(8,4.5));x=np.arange(4)
    ax.bar(x-.2,means['Baseline'],.4,label='Baseline');ax.bar(x+.2,means['Adaptive'],.4,label='Adaptive')
    ax.set_xticks(x,[s for s in STATE_NAMES.values()]);ax.set_ylabel('Final modeled trust-state share (%)');ax.legend()
    fig.tight_layout();fig.savefig(output/'figure11_audit.png',dpi=200);plt.close(fig)


def _audit_main():
    parser=_argparse.ArgumentParser(description='Markov Section 5.2.2 reproducibility and corrected-condition audit')
    parser.add_argument('--out',default='/content/Markov_522_Final_Audit')
    parser.add_argument('--entities',type=int,default=100)
    parser.add_argument('--epochs',type=int,default=500)
    parser.add_argument('--convergence-runs',type=int,default=50)
    parser.add_argument('--comparison-runs',type=int,default=30)
    parser.add_argument('--sensitivity-runs',type=int,default=30)
    parser.add_argument('--auxiliary-runs',type=int,default=30)
    parser.add_argument('--horizons',type=int,nargs='+',default=[200,500,1000])
    parser.add_argument('--rng-mode',choices=['legacy','independent'],default='legacy')
    parser.add_argument('--skip-auxiliary',action='store_true')
    parser.add_argument('--no-plots',action='store_true')
    args=parser.parse_args()
    if min(args.entities,args.epochs,args.convergence_runs,args.comparison_runs,args.sensitivity_runs,args.auxiliary_runs,*args.horizons)<1:
        parser.error('all numeric parameters must be positive')
    out=_Path(args.out).expanduser().resolve();out.mkdir(parents=True,exist_ok=True)
    stationary=compute_stationary_distribution(TRANSITION_MATRIX)
    assert np.allclose(stationary@TRANSITION_MATRIX,stationary,atol=1e-10)
    _save(out/'stationary_distribution.csv',[{'state':STATE_NAMES[i],'probability':float(v),'percentage':float(v*100)} for i,v in enumerate(stationary)])
    print('Stationary distribution:',stationary,flush=True)
    raw,traces=_run_baseline_convergence(args.entities,args.epochs,args.convergence_runs,out,stationary)
    original=_compare(args.entities,args.epochs,args.comparison_runs,out,stationary,'original',args.rng_mode)
    corrected=_compare(args.entities,args.epochs,args.sensitivity_runs,out,stationary,'corrected',args.rng_mode)
    aux=[];inits=[]
    if not args.skip_auxiliary:
        aux=_run_horizon(args.entities,args.horizons,args.auxiliary_runs,out,stationary)
        inits=_run_initial(args.entities,args.epochs,args.auxiliary_runs,out,stationary)
    _save(out/'convergence_summary.csv',_process_summary_rows(raw,[],['initial_l2','final_l2','reduction_pct','source_converged','inclusive_converged']+['final_'+s.lower()+'_pct' for s in STATE_NAMES.values()]))
    combined=original+corrected
    _save(out/'comparison_summary.csv',_process_summary_rows(combined,['variant','process'],['final_l2_to_fixed_stationary']+['final_'+s.lower()+'_pct' for s in STATE_NAMES.values()]))
    _save(out/'paired_contrasts_descriptive.csv',_paired_compare(original,'original')+_paired_compare(corrected,'corrected'))
    overlap_original=[r for r in original if r['run']<=min(args.comparison_runs,args.sensitivity_runs)]
    overlap_corrected=[r for r in corrected if r['run']<=min(args.comparison_runs,args.sensitivity_runs)]
    change=_corrected_sensitivity(overlap_original,overlap_corrected,args.rng_mode)
    _save(out/'condition_sensitivity_per_run.csv',change)
    if aux:_save(out/'horizon_summary.csv',_process_summary_rows(aux,['horizon'],['final_l2','reduction_pct']))
    if inits:_save(out/'initial_distribution_summary.csv',_process_summary_rows(inits,['initial_case'],['final_l2','final_trusted_pct','final_malicious_pct']))
    # Legacy publication source reports ddof=0; use this for paper comparison.
    expected={'final_l2':.0681,'reduction_pct':88.6,'final_trusted_pct':50.20,
              'final_neutral_pct':29.80,'final_risky_pct':13.28,'final_malicious_pct':6.72}
    comparisons=[]
    for key,ref in expected.items():
        values=np.array([r[key] for r in raw]);actual=float(values.mean())
        comparisons.append({'section':'convergence','metric':key,'manuscript_value':ref,'reproduced_mean':actual,'difference':actual-ref})
    baseline=[r for r in original if r['process']=='Baseline']
    adaptive=[r for r in original if r['process']=='Adaptive']
    baseline_paper={'final_trusted_pct':50.77,'final_neutral_pct':28.67,'final_risky_pct':13.10,'final_malicious_pct':7.47,'final_l2_to_fixed_stationary':.0608}
    adapt_paper={'final_trusted_pct':53.07,'final_neutral_pct':29.37,'final_risky_pct':12.93,'final_malicious_pct':4.63,'final_l2_to_fixed_stationary':.0784}
    for process,arr,refs in [('Baseline',baseline,baseline_paper),('Adaptive',adaptive,adapt_paper)]:
        for key,ref in refs.items():
            actual=float(np.mean([r[key] for r in arr]));comparisons.append({'section':'comparison_'+process,'metric':key,'manuscript_value':ref,'reproduced_mean':actual,'difference':actual-ref})
    _save(out/'manuscript_comparison.csv',comparisons)
    if not args.no_plots:_make_figures(out,traces,original,stationary)
    source=_Path(__file__)
    config={'source_script':str(source),'sha256':_hashlib.sha256(source.read_bytes()).hexdigest(),
            'simulation':'Original code baseline/adaptive definitions preserved; corrected variant changes ONLY unreachable <=20 condition',
            'args':vars(args),'stationary':stationary.tolist(),
            'baseline_seeds':[1000+j for j in range(args.convergence_runs)],
            'comparison_seeds':[4000+j for j in range(args.comparison_runs)],
            'corrected_seeds':[4000+j for j in range(args.sensitivity_runs)],
            'rng_mode_notes':'legacy = baseline consumes original NumPy draws before adaptive; independent = reset NumPy seed, but different call patterns still preclude identical stochastic events',
            'condition_fix':'if behavior_score >=90 / elif <=20 / elif <=40',
            'convergence_rule':f'L2 < {CONVERGENCE_THRESHOLD} for {CONVERGENCE_WINDOW} consecutive recorded observations',
            'legacy_SD':'ddof=0 (original print output)','sample_SD':'ddof=1 for descriptive reporting',
            'known_limitations':['100 modeled trust-state entities not 1000 physical IoT nodes','Model outcomes synthetic, not observed malicious validator detection','No matched exogenous attack/behavior draws in original comparison','Corrected scenario is sensitivity, not evidence of original implementation','Only fixed-chain stationary distribution derived mathematically']}
    (out/'config_and_provenance.json').write_text(_json.dumps(config,indent=2,ensure_ascii=False),encoding='utf8')
    converged=sum(r['source_converged'] for r in raw)
    total_tests=len(comparisons)
    report=[ '# Section 5.2.2 Markov reproducibility audit', '',
             f'- Baseline convergence: {len(raw)} runs; source criterion satisfied {converged}/{len(raw)}.',
             f'- Baseline vs adaptive original: {args.comparison_runs} repeated seed settings.',
             f'- Corrected-condition sensitivity: {args.sensitivity_runs} repeated seed settings.',
             '- **Corrected condition is NOT the original model and should not automatically replace Table 13.**',
             f'- Compared {total_tests} manuscript scalar values; see manuscript_comparison.csv.',
             '- Legacy original uses population SD (ddof=0). Output includes both original and sample SD.',
             '- Source comparator requires 20 consecutive values below threshold; inclusive audit also checks final possible window.',
             '- Original RNG comparison uses a continuous NumPy stream: matching seed labels do not imply identical exogenous inputs.',
             '- Trust-state percentages describe standalone Markov entities, not integrated-network validator committees.',
             '', '## Reproduced original comparison means']
    for process,arr in [('Baseline',baseline),('Adaptive',adaptive)]:
        report.append(f'### {process}')
        for key in baseline_paper:
            report.append(f'- {key}: {np.mean([r[key] for r in arr]):.6f}')
    report+=['','## Condition change (corrected minus original)']
    for key in ['final_'+s.lower()+'_pct' for s in STATE_NAMES.values()]:
        d=np.array([r['corrected_minus_original_'+key] for r in change]);report.append(f'- {key}: {d.mean():+.5f} percentage points (n={len(d)})')
    (out/'AUDIT_REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf8')
    print('\n'+ '\n'.join(report),flush=True)
    print(f'\nSaved audit files in: {out}',flush=True)


if __name__ == '__main__':
    _audit_main()
