# Markov Trust — Option B: Activity-Aware Audit and Quarantine

## Status
**Research prototype / controlled sensitivity intervention**, not a re-validated primary result. It changes the model, so prior Section 5.1 Tables 5–9 and Section 5.1.4 trust fractions cannot simply be carried over. No claim of empirical detector accuracy or genuine consensus observation is made.

## Precisely modified
1. Active validators retain the original Markov transition formula and stochastic consensus-success evidence.
2. Inactive validator **candidates** (gateway, edge, cloud only) undergo an independent *synthetic audit* once every 20 epochs. An audit is **not** a consensus event. The audit pass probability depends on quality and attack intensity and is a modeling assumption, not measured evidence. Passing candidates may recover by **at most one state**, with 0.25 probability. Failed audits do not automatically constitute malicious behavior.
3. A node labeled MALICIOUS cannot be selected through the former last-resort fallback. If a shard has zero non-malicious candidates, the simulator raises a descriptive exception rather than silently simulating phantom validators.
4. Re-selection is enforced whenever a currently active validator turns MALICIOUS, even if the target committee size is unchanged.
5. Active Markov transition counts and synthetic audit transition counts are kept separately. `markov_trust_model.audit_transition_counts` records the latter.
6. Audit events, passes, rehabilitations and violations are traceable in the model and epoch metrics.
7. Default offered load is explicitly set to 80,000 TPS for alignment with Section 5.1. All other simulator options should be audited independently.
8. Synthetic audits use a dedicated random generator so they do not themselves consume the main simulator's global random stream; the two trajectories can still diverge through changed selections.

## Tests performed
- Syntax compilation succeeded.
- Integration smoke test with a 200-node, 5-shard, 30 s configuration completed, including audits, with zero MALICIOUS validators at final selection; per-epoch population diagnostics have matching 600 entries.
- Paired-comparison smoke test with one seed, 200 nodes, 5 shards and 1.1 s for both variants completed. **Neither test establishes production validity, full-load stability, or manuscript values.**

## Full comparative protocol
Unzip both files and execute:
```
python run_markov_option_B_comparison.py --runs 10 --tps 80000 --duration 30 --nodes 1000 --shards 10 --seed-base 6100 --out markov_B_comparison
```
Report `per_run.csv`, `summary.csv`, and `protocol.json`, plus raw model versions and their checksums. Inspect queue, trust, security detection, deadline, throughput, energy and recovery metrics. The comparison is **paired-seed**, not a perfectly identical exogenous arrival/attack trace (global RNG trajectories may diverge).

## Important remaining design limitations
- Audit outcomes are **synthetically sampled**, not derived from actual intrusion alerts or externally corroborated evidence. The mechanism should be described as a *simulation assumption*.
- Active validator consensus outcomes remain stochastically simulated, rather than event-verified.
- The simulator’s queue uses bounded approximations for M/M/c and is not equivalent to the independent V3 DES. The existing deadline metric may exclude pending expired-due transactions; separate deadline accounting still requires audit.
- `MarkovTrustModel.current_state_distribution()` measures **all 1,000 nodes**, including sensors whose states are not updated by validator-trust evolution. Report *all-node state distribution*, not “validator state distribution” without denominator clarification.
- The fixed stationary reference is for P_BASE, not a stationary law for the adaptive state-dependent process.
- For a stronger future study, replace the synthetic audit with a properly specified independent security-observation channel and test parameter sensitivity (`INACTIVE_AUDIT_*`).

## Acceptance criteria before changing the paper
1. Run 10 or more matched seeds at the intended 80K TPS and archive raw outputs.
2. Confirm no MALICIOUS active validators after each re-selection and no fake validation capacity assigned to empty shards.
3. Quantify changes in final TRUSTED/MALICIOUS, inactive audit rehabilitations, time in quarantine, throughput, deadlines, service latency, energy, backlog, and workload drift.
4. Separate claims about the model’s internal state distribution from actual detection/mitigation efficacy.
5. If primary mechanism or equations change, revise Methods and any affected Results/Supplementary, not just Section 5.1.4.
