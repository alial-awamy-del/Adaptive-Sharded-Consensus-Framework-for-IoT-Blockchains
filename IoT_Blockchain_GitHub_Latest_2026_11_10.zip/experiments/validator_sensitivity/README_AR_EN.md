# Validator-Selection Weight Sensitivity V3 — Reproducible Experiment

## التشغيل على Colab أو Terminal

```bash
pip install numpy scipy
python validator_weight_sensitivity_v3.py --runs 50 --duration 30 --out validator_sensitivity_v3_results
```

يمكن رفع الملف إلى Google Colab وتشغيله عن طريق `!python validator_weight_sensitivity_v3.py --runs 50 --duration 30 --out /content/results`، وليس لصق المحتوى داخل خلية Notebook. لا تعتمد النتائج القديمة لـTable 10 بعد استبدال الكود.

**مخرجات التنفيذ**: `per_run.csv` (250 صفًا في التشغيل الكامل)، `summary.csv` (mean وsample SD)، `friedman.csv`، `wilcoxon_holm.csv`، `metadata.json`.

## What was corrected

1. Only gateway, edge, and cloud nodes can serve as validators; sensors remain traffic producers and contribute modeled baseline device energy.
2. Fixed scenario seeds: same 1000-node population, Poisson traffic, attack interval, transaction class and service-demand trace across all five weight configurations in each run.
3. Exactly 600 epochs for 30 s, 10 shards. Attack multipliers apply *only* in the designated attack window and reset automatically thereafter.
4. Service is an event-driven, non-preemptive, strict-priority microbatch scheduler with heterogeneous workers, not Erlang-C waiting-time substitutions. Validators finishing an existing batch after committee retirement do not accept new jobs.
5. Gini is computed over **all eligible candidates**, including never-selected nodes. Also report selection shares by device category and Gini of shard-level selection exposure.
6. Uniform horizon for throughput, completed-job latency and model-based energy. Deadline denominator includes arrivals whose deadline matures within the observation horizon (unconfirmed count as missed).
7. Baseline sleep power is counted once for all 1000 nodes; only *incremental* validator service energy is added. Assumptions are not hardware calibrated.
8. Paired Friedman across the five configurations; 10 two-sided paired Wilcoxon comparisons per metric with Holm correction. Run-level SD uses `ddof=1`.

## Critical methodological notes

- **This is a NEW component simulator**, not a drop-in reproduction of the legacy code. The original score used unnormalized features and a constant security value; this version uses five normalized predictors and heterogeneous static security. To claim faithful implementation, update the selection score equation and feature definitions in the manuscript (Section 3.3) or modify `selection_score()` to match the approved equation.
- A weight-sensitivity experiment does not need to equal baseline or consensus-comparison energy, throughput, or latency numerically. This engine's power accounting, capacity model, attack stress, and committee control assumptions differ.
- Gini of selection **frequency** can remain identical between different weight configurations when each selects a fixed-sized, unchanging committee. That is mathematically expected; it is not a software error. Device composition and shard allocation are reported as additional diagnostics. Do not force the desired Gini significance.
- Committee adaptation is an explicit lagged offered-load controller (`rho_min`, `rho_max`, `adjustment_step`); it is NOT asserted to reproduce every aspect of the original system-level adaptive validator-pool controller or Markov reputation evolution.
- This simulation uses homogeneous network transit and per-batch consensus-delay assumptions, not protocol-specific message propagation or hardware telemetry. It cannot substantiate hardware energy savings.
- Inference across multiple metrics is descriptive: Holm controls the ten pairwise tests *within* a metric, not across all analyzed metrics.
- Do not paste previously reported Table 10 values into a revised manuscript; use a complete 50-run output and audit the generated run-level CSV.
