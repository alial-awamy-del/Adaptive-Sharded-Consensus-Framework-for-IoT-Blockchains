#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validator-selection weight sensitivity V3.1 with dynamic Markov trust.

Design: five predefined weights; 50 paired scenarios by default; 1000 IoT nodes;
10 shards; 30s; 50-ms selection epochs; discrete-event nonpreemptive
strict-priority microbatch servicing; explicit full-population Gini and
model-based power accounting and evidence-modulated four-state trust evolution.
This is an INDEPENDENT component simulator,
not an exact re-execution of Sections 5.1, 5.2.3 or 5.2.4.

Requires numpy, scipy. CSV output: per_run.csv, summary.csv,
friedman.csv, wilcoxon_holm.csv, trust_trace_first_run.csv,
trust_transitions.csv, metadata.json.
"""
from __future__ import annotations
import argparse
import csv
import heapq
import json
import math
import random
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import NamedTuple
import numpy as np
from scipy import stats

SCENARIOS = {
    'Baseline':        (.25, .25, .30, .15, .05),
    'High Reputation': (.50, .15, .15, .15, .05),
    'High Hardware':   (.15, .15, .50, .15, .05),
    'High Security':   (.15, .15, .15, .50, .05),
    'Balanced':        (.20, .20, .20, .20, .20),
}
CLASSES = ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW')
CLASS_PROBS = (.10, .20, .30, .40)
DEADLINE = (.10, .20, .50, 1.00)
# Assumed power profiles (watts) and service capacities (transactions/second).
POWER = {
    'sensor': {'sleep': .0005, 'compute': .05, 'radio': .15, 'capacity': 10},
    'gateway': {'sleep': 2.5, 'compute': 4.5, 'radio': 6.0, 'capacity': 100},
    'edge': {'sleep': 1.0, 'compute': 8.0, 'radio': 4.0, 'capacity': 500},
    'cloud': {'sleep': 20.0, 'compute': 60.0, 'radio': 20.0, 'capacity': 2000},
}
VALIDATOR_PROFILES = {'gateway', 'edge', 'cloud'}
NODE_COUNTS = {'sensor': 600, 'gateway': 250, 'edge': 100, 'cloud': 50}

@dataclass(frozen=True)
class Node:
    nid: int
    shard: int
    profile: str
    reputation: float
    validator_score: float
    security: float
    stake: float

class Job(NamedTuple):
    arrival: float
    cls: int
    size: int
    difficulty: float
    transit: float
    attack: bool


def make_nodes(seed: int, shards: int) -> list[Node]:
    rng = random.Random(seed + 11)
    profiles = [k for k, n in NODE_COUNTS.items() for _ in range(n)]
    rng.shuffle(profiles)
    return [Node(i, i % shards, typ, rng.uniform(60, 100),
                 rng.uniform(50, 100), rng.uniform(.5, 1.0),
                 rng.uniform(30, 100)) for i, typ in enumerate(profiles)]


def make_trace(seed: int, args):
    """Identical Poisson arrival/class/batch/difficulty trace for all weight sets."""
    rng = np.random.default_rng(seed + 29)
    epochs = int(round(args.duration / args.epoch))
    by_shard = [[] for _ in range(args.shards)]
    epoch_arrivals = np.zeros(epochs, dtype=np.int64)
    epoch_shard_arrivals = np.zeros((epochs,args.shards),dtype=np.int64)
    job_count = 0
    tx_total = 0
    for epoch in range(epochs):
        t0 = epoch * args.epoch
        attack = args.attack_start <= t0 < args.attack_end
        mult = args.attack_arrival_mult if attack else 1.0
        n = int(rng.poisson(args.offered_tps * args.epoch * mult))
        epoch_arrivals[epoch] = n
        tx_total += n
        shard_counts = rng.multinomial(n, [1.0 / args.shards] * args.shards)
        epoch_shard_arrivals[epoch] = shard_counts
        for shard, count in enumerate(shard_counts):
            cls_counts = rng.multinomial(int(count), CLASS_PROBS)
            for cls, nc in enumerate(cls_counts):
                while nc:
                    batch = min(args.batch_size, nc)
                    nc -= batch
                    by_shard[shard].append(Job(
                        float(t0 + rng.random() * args.epoch), cls, batch,
                        float(rng.uniform(.9, 1.1)),
                        float(rng.uniform(.001, .003)), attack))
                    job_count += 1
    for arr in by_shard:
        arr.sort(key=lambda x: x.arrival)
    return by_shard, epoch_arrivals, tx_total, job_count, epoch_shard_arrivals


def selection_score(node: Node, weights):
    """Five normalized [0,1] predictors. Update methodology if replacing old score."""
    reputation = node.reputation / 100.0
    validator_quality = node.validator_score / 100.0
    hw = POWER[node.profile]['capacity'] / 2000.0
    security = node.security
    stake = node.stake / 100.0
    return sum(a * b for a, b in zip(weights,
               (reputation, validator_quality, hw, security, stake)))


def select_committee(candidates, weights, count, shards, min_per_shard):
    """Highest score subject to a deterministic minimum representation per shard."""
    ordered = sorted(candidates, key=lambda n: (-selection_score(n, weights), n.nid))
    byshard = [[] for _ in range(shards)]
    for n in ordered:
        byshard[n.shard].append(n)
    chosen = []
    used = set()
    for pool in byshard:
        for node in pool[:min_per_shard]:
            chosen.append(node)
            used.add(node.nid)
    if len(chosen) > count:
        raise ValueError('Committee count is smaller than shard minima')
    for node in ordered:
        if len(chosen) >= count:
            break
        if node.nid not in used:
            chosen.append(node)
            used.add(node.nid)
    return chosen


# From the original full-system Markov model; state order is fixed.
TRUST_STATES = ('TRUSTED', 'NEUTRAL', 'RISKY', 'MALICIOUS')
P_BASE = np.array([
    [.85, .10, .04, .01],
    [.20, .65, .12, .03],
    [.10, .30, .50, .10],
    [.05, .15, .20, .60],
], dtype=float)
assert np.allclose(P_BASE.sum(axis=1), 1.0)


def _normalize_rows(a):
    x = np.maximum(a, 1e-12)
    return x / x.sum(axis=1, keepdims=True)


class DynamicMarkovTrust:
    """Per-eligible-node trust state and mutable scores.

    Mirrors the original Markov reference matrix and performance/security/
    consensus/recovery bias rules. Extension for this component experiment:
    eligible noncommittee candidates receive background performance/security
    and recovery updates but no fictitious consensus success or failure.

    A common RNG stream per paired seed supplies identically indexed random
    innovations. Endogenous selected-committee differences remain allowed.
    """
    def __init__(self, eligible, seed):
        self.eligible = eligible
        self.rng = np.random.default_rng(seed + 73)
        self.states = np.zeros(len(eligible), dtype=np.int8)  # all TRUSTED initially
        self.reputation = np.array([n.reputation for n in eligible], float)
        self.validator_score = np.array([n.validator_score for n in eligible], float)
        self.security = np.array([n.security for n in eligible], float)
        self.stake = np.array([n.stake for n in eligible], float)
        self.capacity = np.array([POWER[n.profile]['capacity'] for n in eligible], float)
        self.shard = np.array([n.shard for n in eligible], dtype=np.int32)
        self.ids = np.array([n.nid for n in eligible], dtype=np.int32)
        self.index = {n.nid: i for i, n in enumerate(eligible)}
        self.transitions = np.zeros((4, 4), dtype=np.int64)

    def score(self, weights):
        w = np.asarray(weights, dtype=float)
        features = np.column_stack((self.reputation / 100,
                                    self.validator_score / 100,
                                    self.capacity / 2000,
                                    self.security,
                                    self.stake / 100))
        return features @ w

    def eligible_mask(self):
        return ((self.states != 3) & (self.reputation >= 50) &
                (self.validator_score >= 40))

    def update(self, committee, attack_intensity, args):
        n = len(self.eligible)
        old = self.states.copy()
        selected = np.zeros(n, dtype=bool)
        selected[[self.index[x.nid] for x in committee]] = True
        # Quality follows original whole-system model: .45 reputation,
        # .45 validator quality, .10 hardware capacity.
        q = np.clip(.45*self.reputation/100 + .45*self.validator_score/100 +
                    .10*self.capacity/2000, 0, 1)
        a = float(np.clip(attack_intensity, 0, 1))
        prob = P_BASE[old].copy()
        d = np.clip(q - .5, -.5, .5)
        prob[:, 0] += .10*d
        prob[:, 1] += .04*d
        prob[:, 2] -= .06*d
        prob[:, 3] -= .08*d
        prob = _normalize_rows(prob)
        ae = a**1.2
        prob[:, 0] -= .070*ae
        prob[:, 1] -= .030*ae
        prob[:, 2] += .060*ae
        prob[:, 3] += .040*ae
        affected = selected & (self.rng.random(n) < .10*a)
        prob[affected, 0] -= .015
        prob[affected, 2] += .010
        prob[affected, 3] += .005
        prob = _normalize_rows(prob)
        # Observed consensus outcomes *only* for selected validator nodes.
        success_p = np.clip(.82 + .14*q - .25*a, .58, .975)
        success = selected & (self.rng.random(n) < success_p)
        fail = selected & ~success
        prob[success] += np.array([.030, .012, -.020, -.022])
        prob[fail] += np.array([-.025, -.008, .023, .010])
        prob = _normalize_rows(prob)
        # Same state-dependent recovery biases as original framework.
        if a <= .05:
            m = old == 0
            removed = prob[m, 3]*.60 + prob[m, 2]*.20
            prob[m, 3] *= .40; prob[m, 2] *= .80
            prob[m, 0] += removed*.70; prob[m, 1] += removed*.30
            m = old == 1
            removed = prob[m, 3]*.45 + prob[m, 2]*.10
            prob[m, 3] *= .55; prob[m, 2] *= .90
            prob[m, 0] += removed*.30; prob[m, 1] += removed*.70
            m = (old == 2) & (q >= .50)
            removed = prob[m, 3]*.30 + prob[m, 2]*.08
            prob[m, 3] *= .70; prob[m, 2] *= .92
            prob[m, 0] += removed*.20; prob[m, 1] += removed*.80
            m = (old == 3) & (q >= .45)
            removed = prob[m, 3]*.25
            prob[m, 3] *= .75
            prob[m, 2] += removed*.55; prob[m, 1] += removed*.35
            prob[m, 0] += removed*.10
        elif a <= .50:
            m = (old == 0) | (old == 1)
            removed = prob[m, 3]*.20
            prob[m, 3] *= .80
            prob[m, 2] += removed*.70; prob[m, 1] += removed*.30
        prob = _normalize_rows(prob)
        u = self.rng.random(n)
        new = np.minimum((u[:, None] > np.cumsum(prob, axis=1)).sum(axis=1), 3).astype(np.int8)
        np.add.at(self.transitions, (old, new), 1)
        self.states = new
        # Original state-dependent score updates with paired innovations.
        rep_u = self.rng.random(n)
        val_u = self.rng.random(n)
        self.reputation += np.select([new==0, new==1, new==2, new==3],
            [.20+.80*rep_u, -.30+.60*rep_u,
             -(.35+.75*rep_u)*(1+.8*a), -(1.+1.8*rep_u)*(1.+a)])
        self.validator_score += np.select([new==0, new==1, new==2, new==3],
            [.20+.60*val_u, -.30+.60*val_u,
             -(.30+.65*val_u)*(1+.8*a), -(1.+1.8*val_u)*(1.+a)])
        self.validator_score[fail] -= .15+.45*self.rng.random(n)[fail]
        np.clip(self.reputation, 0, 100, out=self.reputation)
        np.clip(self.validator_score, 0, 100, out=self.validator_score)


def select_committee_dynamic(trust, weights, count, shards, min_per_shard):
    scores = trust.score(weights)
    allowed = np.flatnonzero(trust.eligible_mask())
    ordered = sorted(allowed, key=lambda i: (-scores[i], int(trust.ids[i])))
    byshard = [[] for _ in range(shards)]
    for idx in ordered:
        byshard[trust.shard[idx]].append(idx)
    if any(len(pool) < min_per_shard for pool in byshard):
        raise RuntimeError('Too few non-MALICIOUS eligible candidates to meet shard minimum')
    chosen_idx = [idx for pool in byshard for idx in pool[:min_per_shard]]
    selected = set(chosen_idx)
    for idx in ordered:
        if len(chosen_idx) >= count:
            break
        if idx not in selected:
            chosen_idx.append(idx)
            selected.add(idx)
    return tuple(trust.eligible[i] for i in chosen_idx)


def schedule_committees(nodes, weights, epoch_arrivals, epoch_shard_arrivals, args, seed):
    """Dynamic trust + capacity adaptation using *lagged* fluid backlog estimates.

    This controller has no access to DES actual queue completions. The virtual
    workload is a causal fluid approximation used for capacity planning only.
    Genuine transaction latency/backlog is computed separately by simulate_shard.
    """
    eligible = [n for n in nodes if n.profile in VALIDATOR_PROFILES]
    trust = DynamicMarkovTrust(eligible, seed)
    max_allowed = min(args.max_validators, len(eligible))
    min_allowed = args.shards * args.min_per_shard
    count = max(min_allowed, min(args.initial_validators, max_allowed))
    epoch_committees = []
    frequencies = defaultdict(int)
    device_exposures = defaultdict(int)
    shard_exposures = np.zeros(args.shards, dtype=float)
    size_trace, churn_trace = [], []
    trusted_trace, malicious_trace = [], []
    trust_rows = []
    prior_ids = set()
    backlog_proxy = np.zeros(args.shards, dtype=float)
    proxy_peak, rho_peak, overloaded_epochs, saturated_epochs = 0., 0., 0, 0
    capacity_trace, proxy_trace = [], []
    committee = ()
    last_resize_ep = -10**9
    window_arrivals = np.zeros(args.shards, dtype=float)
    for ep, n_arrivals in enumerate(epoch_arrivals):
        if ep == 0 or ep % args.selection_interval == 0:
            committee = select_committee_dynamic(trust, weights, count, args.shards, args.min_per_shard)
            # If candidates are screened out by trust, the committee may be smaller
            # than requested. Record actual size; never invent unavailable workers.
            current_ids = {n.nid for n in committee}
            if ep > 0:
                churn_trace.append(len(current_ids.symmetric_difference(prior_ids)) /
                                   max(1, len(current_ids.union(prior_ids))))
            prior_ids = current_ids
        for n in committee:
            frequencies[n.nid] += 1
            device_exposures[n.profile] += 1
            shard_exposures[n.shard] += 1
        epoch_committees.append(tuple(committee))
        size_trace.append(len(committee))
        t0 = ep * args.epoch
        attack = args.attack_start <= t0 < args.attack_end
        service_factor = args.attack_service_mult if attack else 1.
        # Realized committee capacity, per shard, in transactions per epoch.
        capacities = np.zeros(args.shards, dtype=float)
        for node in committee:
            capacities[node.shard] += POWER[node.profile]['capacity'] * args.service_scale * service_factor * args.epoch
        incoming = epoch_shard_arrivals[ep].astype(float)
        window_arrivals += incoming
        backlog_proxy = np.maximum(0., backlog_proxy + incoming - capacities)
        proxy_peak = max(proxy_peak, float(backlog_proxy.sum()))
        max_rho = float(np.max(incoming / np.maximum(capacities, 1e-12)))
        rho_peak = max(rho_peak, max_rho)
        overloaded_epochs += int(np.any(incoming > capacities))
        capacity_trace.append(float(capacities.sum() / args.epoch))
        proxy_trace.append(float(backlog_proxy.sum()))
        attack_intensity = args.trust_attack_intensity if attack else 0.
        if (ep + 1) % args.trust_update_interval == 0:
            trust.update(committee, attack_intensity, args)
        dist = np.bincount(trust.states, minlength=4) / len(eligible)
        trusted_trace.append(float(dist[0]))
        malicious_trace.append(float(dist[3]))
        if args.trace_first_run:
            trust_rows.append({'epoch': ep+1, 'time_s': (ep+1)*args.epoch,
                               **{f'trust_{name.lower()}_pct': float(100*dist[i])
                                  for i,name in enumerate(TRUST_STATES)},
                               'committee_size': len(committee),
                               'controller_queue_proxy_tx': float(backlog_proxy.sum()),
                               'controller_capacity_tps': float(capacities.sum()/args.epoch),
                               'controller_max_shard_rho': max_rho,
                               'committee_malicious': sum(trust.states[trust.index[n.nid]]==3
                                                        for n in committee)})
        # Controller uses only arrivals, estimated backlog and capacity from epochs
        # already elapsed. Selection at the NEXT epoch boundary is causal.
        if (ep + 1) % args.selection_interval == 0:
            elapsed = args.selection_interval * args.epoch
            per_shard_target = (window_arrivals / elapsed +
                                backlog_proxy / max(args.backlog_clear_seconds, args.epoch)) / args.rho_target
            window_arrivals[:] = 0.
            desired = float(per_shard_target.sum())
            current = float(sum(POWER[n.profile]['capacity'] for n in committee) *
                            args.service_scale * service_factor)
            # Never shrink with unresolved backlog or a shard over the utilization cap.
            stressed = bool(backlog_proxy.sum() >= args.backlog_trigger_tx or
                            np.any(incoming / np.maximum(capacities,1e-12) > args.rho_max))
            too_idle = bool(not stressed and backlog_proxy.sum() < 1. and
                            current > desired / max(args.rho_min/args.rho_target,1e-12))
            can_resize = (ep - last_resize_ep >= args.resize_cooldown_epochs)
            if can_resize and (stressed or desired > current * (1+args.resize_deadband)):
                # Increase until requested capacity reached, but clip by actual
                # eligible pool and configured maximum; no guarantee if infeasible.
                next_count = count
                step = max(1, int(math.ceil(max(count,1) * args.adjustment_step)))
                while next_count < max_allowed:
                    next_count = min(max_allowed, next_count + step)
                    prospective = select_committee_dynamic(
                        trust, weights, next_count, args.shards, args.min_per_shard)
                    prospective_cap = sum(POWER[n.profile]['capacity'] for n in prospective) * args.service_scale * service_factor
                    shard_caps = np.zeros(args.shards, dtype=float)
                    for node in prospective:
                        shard_caps[node.shard] += POWER[node.profile]['capacity'] * args.service_scale * service_factor
                    if (prospective_cap >= desired and
                        np.all(shard_caps >= per_shard_target)):
                        break
                    if len(prospective) < next_count:
                        break
                if next_count != count:
                    count = next_count
                    last_resize_ep = ep
            elif can_resize and too_idle:
                next_count = max(min_allowed, count - max(1, int(math.ceil(count*args.adjustment_step))))
                prospective = select_committee_dynamic(trust, weights, next_count,
                                                      args.shards, args.min_per_shard)
                shard_caps = np.zeros(args.shards, dtype=float)
                for node in prospective:
                    shard_caps[node.shard] += POWER[node.profile]['capacity'] * args.service_scale * service_factor
                if np.all(shard_caps >= per_shard_target):
                    count = next_count
                    last_resize_ep = ep
            if count >= max_allowed and (desired > current or stressed):
                saturated_epochs += 1
    vals = np.sort(np.array([frequencies.get(n.nid, 0) for n in eligible], float))
    gini = (2*np.dot(np.arange(1,len(vals)+1), vals)/(len(vals)*vals.sum()) -
            (len(vals)+1)/len(vals)) if vals.sum() else 0.
    ordered_shards = np.sort(shard_exposures)
    shard_gini = (2*np.dot(np.arange(1,args.shards+1), ordered_shards)/
                  (args.shards*ordered_shards.sum())-(args.shards+1)/args.shards) if ordered_shards.sum() else 0.
    exposure_total = sum(device_exposures.values())
    shares = {typ: (device_exposures.get(typ,0)/exposure_total*100 if exposure_total else 0.)
              for typ in ('gateway','edge','cloud')}
    extra = {'final_trusted_pct':trusted_trace[-1]*100,
             'final_neutral_pct':float(np.mean(trust.states==1)*100),
             'final_risky_pct':float(np.mean(trust.states==2)*100),
             'final_malicious_pct':malicious_trace[-1]*100,
             'mean_trusted_pct':float(np.mean(trusted_trace)*100),
             'mean_malicious_pct':float(np.mean(malicious_trace)*100),
             'committee_churn_jaccard':float(np.mean(churn_trace)) if churn_trace else 0.,
             'unique_selected_pct':sum(v>0 for v in frequencies.values())/len(eligible)*100,
             'trust_transition_count':int(trust.transitions.sum()),
             'min_validators':int(min(size_trace)),
             'max_validators':int(max(size_trace)),
             'validator_size_changed':int(len(set(size_trace))>1),
             'controller_peak_backlog_proxy_tx':proxy_peak,
             'controller_final_backlog_proxy_tx':float(backlog_proxy.sum()),
             'controller_peak_shard_rho':rho_peak,
             'controller_overloaded_epochs':int(overloaded_epochs),
             'controller_saturated_checkpoints':int(saturated_epochs),
             'controller_mean_capacity_tps':float(np.mean(capacity_trace))}
    return (epoch_committees,float(gini),float(np.mean(size_trace)),len(eligible),
            float(shard_gini),shares,extra,trust_rows,trust.transitions)


def simulate_shard(shard_jobs, committees, shard: int, args):
    """Arrival, committee-change and service-completion events; strict nonpreemptive priority.

    Validator retirement is nonpreemptive: an in-service batch may finish; no new
    batch is allocated to its retired worker. Confirmation after service has a
    modeled asynchronous transit delay; it does not occupy a worker.
    """
    ready = [deque() for _ in CLASSES]
    total_ontime = np.zeros(4, dtype=np.int64)
    mature = np.zeros(4, dtype=np.int64)
    confirmed = np.zeros(4, dtype=np.int64)
    class_latency_sum = np.zeros(4, dtype=float)
    energy_increment_wh = 0.0
    # All jobs arriving early enough for their deadline to mature are in denominator.
    for j in shard_jobs:
        if j.arrival + DEADLINE[j.cls] <= args.duration:
            mature[j.cls] += j.size
    n, i, ce, counter = len(shard_jobs), 0, 0, 0
    events = []    # (time, monotonic_id, worker_id, job)
    busy = set()
    active = {}
    idle = []
    t = 0.0
    while True:
        next_arrival = shard_jobs[i].arrival if i < n else math.inf
        next_completion = events[0][0] if events else math.inf
        next_committee = ce * args.epoch if ce < len(committees) else math.inf
        t = min(next_arrival, next_completion, next_committee)
        if t >= args.duration or not math.isfinite(t):
            break
        if next_committee == t:
            ids = {node.nid: node for node in committees[ce] if node.shard == shard}
            active = ids
            # Idle heap membership reconstructed on committee changes.
            idle = [nid for nid in active if nid not in busy]
            heapq.heapify(idle)
            ce += 1
        if next_completion == t:
            while events and events[0][0] <= t + 1e-12:
                finish, _, worker, j = heapq.heappop(events)
                busy.remove(worker)
                delivered = finish + j.transit + args.consensus_delay
                if delivered <= args.duration:
                    confirmed[j.cls] += j.size
                    class_latency_sum[j.cls] += (delivered - j.arrival) * j.size
                    if delivered - j.arrival <= DEADLINE[j.cls]:
                        total_ontime[j.cls] += j.size
                if worker in active:
                    heapq.heappush(idle, worker)
        if next_arrival == t:
            while i < n and shard_jobs[i].arrival <= t + 1e-12:
                ready[shard_jobs[i].cls].append(shard_jobs[i])
                i += 1
        while idle and any(ready):
            worker = heapq.heappop(idle)
            if worker not in active or worker in busy:
                continue
            cls = next(idx for idx, line in enumerate(ready) if line)
            j = ready[cls].popleft()
            node = active[worker]
            rate = POWER[node.profile]['capacity'] * args.service_scale
            duration = (j.size / max(rate, .001)) * j.difficulty
            if j.attack:
                duration /= args.attack_service_mult
            finish = t + duration
            busy.add(worker)
            counter += 1
            heapq.heappush(events, (finish, counter, worker, j))
            # Include active processing *only* up to the observation horizon.
            active_s = min(duration, max(0.0, args.duration - t))
            p = POWER[node.profile]
            # Fixed 85% compute / 15% radio activity during service.
            power_delta = .85 * (p['compute'] - p['sleep']) + .15 * (p['radio'] - p['sleep'])
            power_factor = args.attack_power_mult if j.attack else 1.0
            energy_increment_wh += power_delta * power_factor * active_s / 3600.0
    return confirmed, mature, total_ontime, class_latency_sum, energy_increment_wh


def evaluate(seed: int, weights, nodes, trace, args):
    by_shard, epoch_arrivals, generated, jobs, epoch_shard_arrivals = trace
    committees, gini, avg_validators, eligible, shard_gini, profile_shares, trust_metrics, trust_rows, transitions = schedule_committees(nodes, weights, epoch_arrivals, epoch_shard_arrivals, args, seed)
    totals = np.zeros((4, 4), dtype=float)
    busy_energy = 0.0
    for shard in range(args.shards):
        conf, mature, ontime, lsum, e = simulate_shard(by_shard[shard], committees, shard, args)
        totals[0] += conf
        totals[1] += mature
        totals[2] += ontime
        totals[3] += lsum
        busy_energy += e
    confirmed = int(totals[0].sum())
    # Baseline whole-node sleep energy; additive only to incremental service energy.
    sleep_wh = sum(POWER[n.profile]['sleep'] for n in nodes) * args.duration / 3600.0
    energy_wh = sleep_wh + busy_energy
    overall_latency = float(totals[3].sum() / confirmed * 1e3) if confirmed else math.nan
    out = {
        'seed': seed, 'generated_tx': int(generated), 'confirmed_tx': confirmed,
        'completion_pct': confirmed / generated * 100 if generated else math.nan,
        'backlog_tx': int(generated - confirmed),
        'throughput_k_tps': confirmed / args.duration / 1000.0,
        'overall_latency_ms': overall_latency,
        'full_system_energy_uwh_tx': energy_wh / confirmed * 1e6 if confirmed else math.nan,
        'energy_wh': energy_wh, 'gini_eligible': gini,
        'average_validators': avg_validators, 'eligible_validator_candidates': eligible,
        'shard_selection_gini': shard_gini,
        'gateway_selection_share_pct': profile_shares['gateway'],
        'edge_selection_share_pct': profile_shares['edge'],
        'cloud_selection_share_pct': profile_shares['cloud'],
        **trust_metrics,
    }
    for k, cls in enumerate(CLASSES):
        out[f'{cls.lower()}_latency_ms'] = (totals[3, k] / totals[0, k] * 1e3
                                              if totals[0, k] else math.nan)
        out[f'{cls.lower()}_deadline_pct'] = (totals[2, k] / totals[1, k] * 100
                                               if totals[1, k] else math.nan)
    return out, trust_rows, transitions


def save_csv(path, rows):
    if not rows:
        return
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def statistics(per_runs, outdir):
    metrics = ['throughput_k_tps', 'overall_latency_ms',
               'full_system_energy_uwh_tx', 'gini_eligible', 'shard_selection_gini',
               'gateway_selection_share_pct', 'edge_selection_share_pct',
               'cloud_selection_share_pct', 'average_validators',
               'critical_latency_ms', 'critical_deadline_pct',
               'high_latency_ms', 'high_deadline_pct', 'completion_pct',
               'final_trusted_pct', 'final_malicious_pct', 'mean_trusted_pct',
               'mean_malicious_pct', 'committee_churn_jaccard', 'unique_selected_pct',
               'min_validators','max_validators','validator_size_changed',
               'controller_peak_backlog_proxy_tx',
               'controller_final_backlog_proxy_tx',
               'controller_peak_shard_rho',
               'controller_overloaded_epochs','controller_saturated_checkpoints']
    names = list(SCENARIOS)
    byname = {n: sorted((r for r in per_runs if r['scenario'] == n), key=lambda r: r['run']) for n in names}
    summary, omnibus, pairs = [], [], []
    for metric in metrics:
        xs = [np.array([r[metric] for r in byname[name]], float) for name in names]
        for name, x in zip(names, xs):
            finite = x[np.isfinite(x)]
            summary.append({'metric': metric, 'scenario': name,
                            'mean': float(np.mean(finite)) if finite.size else math.nan,
                            'sd': float(np.std(finite, ddof=1)) if finite.size > 1 else math.nan,
                            'n': int(finite.size)})
        paired = np.column_stack(xs)
        paired = paired[np.isfinite(paired).all(axis=1)]
        if len(paired) < 3:
            omnibus.append({'metric': metric, 'n_pairs': len(paired), 'friedman_chi2': math.nan, 'p': math.nan})
            continue
        if np.all(paired == paired[:, :1]):
            chi, p = 0.0, 1.0
        else:
            res = stats.friedmanchisquare(*[paired[:, j] for j in range(len(names))])
            chi, p = float(res.statistic), float(res.pvalue)
        omnibus.append({'metric': metric, 'n_pairs': len(paired), 'friedman_chi2': chi, 'p': p})
        tests = []
        for a in range(len(names)):
            for b in range(a + 1, len(names)):
                d = paired[:, a] - paired[:, b]
                if not np.any(d):
                    w, raw = 0.0, 1.0
                else:
                    res = stats.wilcoxon(paired[:, a], paired[:, b], zero_method='wilcox',
                                         alternative='two-sided', method='auto')
                    w, raw = float(res.statistic), float(res.pvalue)
                tests.append({'metric': metric, 'comparison': names[a] + ' vs ' + names[b],
                              'n_pairs': len(paired), 'wilcoxon_W': w, 'p_raw': raw})
        # Holm step-down within each metric; conservatively computed across all 10 pairs.
        order = sorted(range(len(tests)), key=lambda j: tests[j]['p_raw'])
        prev = 0.0
        for rank, j in enumerate(order):
            adjusted = min(1., (len(tests) - rank) * tests[j]['p_raw'])
            prev = max(prev, adjusted)
            tests[j]['p_holm'] = prev
            tests[j]['significant_05'] = prev < .05
        pairs += tests
    save_csv(outdir / 'summary.csv', summary)
    save_csv(outdir / 'friedman.csv', omnibus)
    save_csv(outdir / 'wilcoxon_holm.csv', pairs)
    return summary, omnibus


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=int, default=50)
    parser.add_argument('--duration', type=float, default=30.)
    parser.add_argument('--epoch', type=float, default=.05)
    parser.add_argument('--shards', type=int, default=10)
    parser.add_argument('--offered-tps', type=float, default=80000.)
    parser.add_argument('--batch-size', type=int, default=50)
    parser.add_argument('--service-scale', type=float, default=1.5)
    parser.add_argument('--consensus-delay', type=float, default=.002)
    parser.add_argument('--seed-base', type=int, default=20261108)
    parser.add_argument('--attack-start', type=float, default=6.)
    parser.add_argument('--attack-end', type=float, default=11.05)
    parser.add_argument('--attack-arrival-mult', type=float, default=1.15)
    parser.add_argument('--attack-service-mult', type=float, default=.95)
    parser.add_argument('--attack-power-mult', type=float, default=1.05)
    parser.add_argument('--initial-validators', type=int, default=100)
    parser.add_argument('--max-validators', type=int, default=350)
    parser.add_argument('--min-per-shard', type=int, default=2)
    parser.add_argument('--selection-interval', type=int, default=3)
    parser.add_argument('--rho-min', type=float, default=.40)
    parser.add_argument('--rho-max', type=float, default=.80)
    parser.add_argument('--adjustment-step', type=float, default=.10)
    parser.add_argument('--rho-target', type=float, default=.60)
    parser.add_argument('--backlog-clear-seconds', type=float, default=.5)
    parser.add_argument('--backlog-trigger-tx', type=float, default=150.)
    parser.add_argument('--resize-deadband', type=float, default=.05)
    parser.add_argument('--resize-cooldown-epochs', type=int, default=3)
    parser.add_argument('--trust-update-interval', type=int, default=1)
    parser.add_argument('--trust-attack-intensity', type=float, default=.5)
    parser.add_argument('--out', default='validator_sensitivity_v3_dynamic_results')
    args = parser.parse_args()
    if (args.runs < 1 or args.duration <= 0 or args.epoch <= 0 or args.shards < 1 or
            args.batch_size < 1 or args.trust_update_interval < 1 or args.selection_interval < 1):
        parser.error('runs, duration, epoch, shards and batch-size must be positive')
    if abs(args.duration / args.epoch - round(args.duration / args.epoch)) > 1e-8:
        parser.error('duration must be a multiple of epoch')
    if args.initial_validators > args.max_validators or args.shards * args.min_per_shard > args.max_validators:
        parser.error('initial-validators and shard minima cannot exceed max-validators')
    if not (0 < args.rho_min < args.rho_target < args.rho_max < 1):
        parser.error('require 0 < rho-min < rho-target < rho-max < 1')
    if args.backlog_clear_seconds <= 0 or args.resize_cooldown_epochs < 1:
        parser.error('backlog-clear-seconds must be positive; cooldown must be >=1')
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    all_runs = []
    transition_rows = []
    trust_trace_rows = []
    for run in range(1, args.runs + 1):
        seed = args.seed_base + run
        nodes = make_nodes(seed, args.shards)
        trace = make_trace(seed, args)
        assert len(nodes) == 1000 and trace[2] == sum(trace[1])
        for name, weights in SCENARIOS.items():
            args.trace_first_run = (run == 1)
            r, trace_rows, transition_counts = evaluate(seed, weights, nodes, trace, args)
            for row in trace_rows:
                trust_trace_rows.append({'run': run, 'scenario': name, **row})
            for old_state, state in enumerate(TRUST_STATES):
                for new_state, destination in enumerate(TRUST_STATES):
                    transition_rows.append({'run': run, 'scenario': name, 'from_state': state,
                                            'to_state': destination, 'count': int(transition_counts[old_state,new_state])})
            all_runs.append({'run': run, 'scenario': name, **r})
        save_csv(outdir / 'per_run.csv', all_runs)
        save_csv(outdir / 'trust_transitions.csv', transition_rows)
        if run == 1:
            save_csv(outdir / 'trust_trace_first_run.csv', trust_trace_rows)
        print(f'run {run}/{args.runs}: {len(all_runs)} evaluations complete', flush=True)
    summary, omnibus = statistics(all_runs, outdir)
    with open(outdir / 'metadata.json', 'w', encoding='utf8') as f:
        json.dump({'design': 'paired fixed scenario; independent component-level simulation',
                   'args': vars(args), 'weights': SCENARIOS,
                   'device_counts': NODE_COUNTS, 'power_profiles': POWER,
                   'gini_population': 'all eligible gateway/edge/cloud nodes, including never selected',
                   'scheduler': 'nonpreemptive strict-priority DES on transaction microbatches',
                    'markov_state_order': TRUST_STATES,
                    'markov_reference_transition': P_BASE.tolist(),
                    'trust_update': 'at epoch end; performance, attack, success/failure of selected validators, and recovery modulation; nonselected candidates undergo background trust evolution without consensus outcome',
                    'trust_rng': 'same indexed innovations per seed across weight configurations; selection-specific masks differ',
                    'trust_initialization': 'all eligible begin TRUSTED; this is a modeling assumption, not inherited from Section 5.2.2 initial distributions',
                   'capacity_controller': 'lagged observed offered arrivals + per-shard fluid backlog proxy; target utilization and backlog clearance; selection interval, cooldown and deadband; actual DES backlog separately measured',
                   'deadline_denominator': 'arrivals with deadline reached by end of observation; unconfirmed count as missed',
                   'latency': 'confirmed jobs only; service finish + asynchronous transit + consensus delay',
                   'energy': 'baseline sleep power all 1000 nodes plus incremental compute/radio of working validators; assumed, not hardware calibrated',
                   'limitations': ['No empirical calibration', 'Simple fixed power profiles',
                                   'No observed per-transaction trust evidence; synthetic event-based outcome and security intensity',
                                   'Results not numerically comparable with Sections 5.1/5.2.3/5.2.4',
                                   'Committee changes are applied at epoch boundaries; in-service work is nonpreemptive',
                                   'Fluid backlog is a proxy, NOT feedback from actual DES completions',
                                   'Stability is not guaranteed if available validators are capacity-limited or lose eligibility'],
                   }, f, indent=2)
    print('\nPrimary output:', outdir / 'per_run.csv')
    for item in summary:
        if item['metric'] in ('throughput_k_tps','overall_latency_ms','full_system_energy_uwh_tx','gini_eligible'):
            print(f"{item['metric']:30s} {item['scenario']:17s} {item['mean']:.5f} ± {item['sd']:.5f}")
    for item in omnibus:
        print('Friedman:', item)

if __name__ == '__main__':
    main()
