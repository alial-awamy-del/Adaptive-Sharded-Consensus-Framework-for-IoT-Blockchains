#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent, capacity-constrained inter-shard *aggregate* fluid simulation (V4).

NOT a packet-level / transaction-level DES, nor an implementation of an actual
2-phase-commit consensus protocol. Pair-level transaction equivalents and cross-shard service legs persist
across epochs; paired source/target service is accounted cumulatively. All service, contention, and communication parameters are
scenario assumptions and must be disclosed when interpreting the results.

Design: shard count [2,4,8,16,32,64] x cross-shard ratio [5,10,15,25,35%]
        x 10 independent scenario seeds by default. 30 seconds, 80,000 offered TPS.

Outputs: per_run.csv, summary_by_configuration.csv, table18_by_shard.csv,
         statistical_tests.csv, config.json, README.txt.
"""
import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

SHARD_COUNTS = (2, 4, 8, 16, 32, 64)
CROSS_RATIOS = (0.05, 0.10, 0.15, 0.25, 0.35)
DEVICE_COUNTS = {"sensor": 600, "gateway": 250, "edge": 100, "cloud": 50}
# Assumed *effective processing capacities* (work-units/s), not empirical specs.
VALIDATOR_CAPACITY = {"gateway": 120.0, "edge": 350.0, "cloud": 650.0}
CONFIG = {
    "scenario": "independent aggregate fluid/bulk-service inter-shard model",
    "node_population": DEVICE_COUNTS,
    "sensor_role": "transaction generation only, never a validator",
    "effective_capacity_work_units_per_s_by_validator_class": VALIDATOR_CAPACITY,
    "cross_source_work_units": 1.15,
    "cross_target_work_units": 1.00,
    "retry_work_units_per_conflict": 0.65,
    "lock_slots_per_node_per_epoch": 16,
    "base_local_confirmation_ms": 2.0,
    "base_network_ms": 5.0,
    "network_delay_per_log2_shards_ms": 0.22,
    "commit_coordination_ms": 2.0,
    "message_count_per_cross_transaction": 4,
    "protocol_header_kb_per_message": 0.25,
    "validator_metadata_kb_per_validator_per_cross_tx": 0.08,
    "cross_pair_confirmations": "min(cumulative_src_leg_completed, cumulative_dst_leg_completed) per ordered shard pair, with persistent work and cumulative pair matching",
    "scheduling": "fluid processor-sharing across local, source-leg, destination-leg and retry-work backlogs",
    "delay_boundary": "modeled backlog-based delay proxy for arrival epochs; NOT observed confirmation latency",
    "shard_validator_provisioning": "Exactly one eligible validator reserved per shard, sampled without replacement from global eligible classes; all remaining nodes distributed multinomially. No synthetic nodes added.",
    "model_warning": "Epoch-level, pair-aggregated fluid processor-sharing model; source/target legs paired cumulatively by shard pair, not actual atomic 2PC or a production consensus implementation. All costs are assumed.",
}


def _balanced_node_counts(num_shards, rng):
    """Provision at least one validator per shard while conserving node classes.

    Every shard first receives exactly one eligible validator drawn without
    replacement from the global gateway/edge/cloud population. Remaining
    validator nodes and all sensors are distributed stochastically.

    This explicitly models a shard-liveness provisioning constraint. It is NOT
    evidence that random unconstrained assignment avoids empty committees.
    """
    total_eligible = sum(DEVICE_COUNTS[k] for k in VALIDATOR_CAPACITY)
    if num_shards > total_eligible:
        raise ValueError(
            f"Cannot provision {num_shards} shards with {total_eligible} eligible validators. "
            "Reduce shard count or increase eligible validators."
        )
    counts = {kind: np.zeros(num_shards, dtype=int) for kind in DEVICE_COUNTS}
    # Choose the class of each shard's mandatory validator from the available
    # pool, preserving the class proportions without replacement.
    available = dict(DEVICE_COUNTS)
    for sid in rng.permutation(num_shards):
        types = tuple(VALIDATOR_CAPACITY)
        probabilities = np.array([available[t] for t in types], dtype=float)
        probabilities /= probabilities.sum()
        chosen = types[int(rng.choice(len(types), p=probabilities))]
        counts[chosen][sid] += 1
        available[chosen] -= 1
    for kind, original_count in DEVICE_COUNTS.items():
        remaining = available[kind] if kind in VALIDATOR_CAPACITY else original_count
        counts[kind] += rng.multinomial(remaining, np.full(num_shards, 1.0 / num_shards))
        assert int(counts[kind].sum()) == original_count
    validator_per_shard = sum((counts[k] for k in VALIDATOR_CAPACITY),
                              start=np.zeros(num_shards, dtype=int))
    assert np.all(validator_per_shard >= 1)
    return counts


def _run_one(shards, ratio, seed, duration, epoch_s, offered_tps, capacity_multiplier=1.0):
    """Pair-cohort fluid processor-sharing model with persistent backlog.

    Local transaction mass and the two validation legs of each source-target
    cross-shard pair persist across epochs. Each epoch's service applies to all
    outstanding work (new + earlier). Completion of cross-shard transaction mass
    for a given pair is bounded by BOTH cumulatively served legs of that pair.

    This is not a discrete-event atomic-commit protocol, and fractional
    completions are expected: the units are aggregate transaction equivalents.
    """
    rng = np.random.default_rng(seed)
    n_epochs = int(round(duration / epoch_s))
    if not np.isclose(n_epochs * epoch_s, duration):
        raise ValueError('duration must be an integer multiple of epoch')
    node_counts = _balanced_node_counts(shards, rng)
    validator_counts = sum((node_counts[k] for k in VALIDATOR_CAPACITY),
                           start=np.zeros(shards, dtype=int))
    all_nodes_by_shard = sum(node_counts.values(), start=np.zeros(shards, dtype=int))
    cap_per_s = sum((node_counts[k] * VALIDATOR_CAPACITY[k] for k in VALIDATOR_CAPACITY),
                    start=np.zeros(shards, dtype=float))
    coordination_factor = 1.0 / (1.0 + 0.012 * np.log2(shards))
    if not (np.isfinite(capacity_multiplier) and capacity_multiplier > 0):
        raise ValueError('capacity_multiplier must be positive and finite')
    cap_per_s = cap_per_s * capacity_multiplier
    cap_epoch = cap_per_s * epoch_s * coordination_factor
    if not np.all(cap_epoch > 0):
        raise AssertionError('Invalid provisioning: a shard has no service capacity')

    # Outstanding transaction equivalents; pair matrices have diagonal zero.
    outstanding_local = np.zeros(shards, dtype=float)
    outstanding_src = np.zeros((shards, shards), dtype=float)
    outstanding_dst = np.zeros((shards, shards), dtype=float)
    outstanding_retry_work = np.zeros(shards, dtype=float)
    cumulative_src_done = np.zeros((shards, shards), dtype=float)
    cumulative_dst_done = np.zeros((shards, shards), dtype=float)
    arrived_cross_by_pair = np.zeros((shards, shards), dtype=float)
    cumulative_cross_confirmed = np.zeros((shards, shards), dtype=float)

    total_arrivals = total_local_arrivals = total_cross_arrivals = 0
    total_conflicts = 0
    total_local_completed = 0.0
    sync_kb = 0.0
    sync_payload_header_kb = 0.0
    sync_validator_metadata_kb = 0.0
    cross_queue_delay_weighted = 0.0
    cross_conflict_delay_weighted = 0.0
    peak_pending = peak_backlog_work = peak_shard_rho = 0.0
    overloaded_epochs = 0
    latency_local_weighted = latency_cross_weighted = coord_delay_weighted = 0.0
    local_delay_weight = cross_delay_weight = 0.0
    max_mass_conservation_error = max_work_conservation_error = 0.0

    cross_source_unit = float(CONFIG['cross_source_work_units'])
    cross_target_unit = float(CONFIG['cross_target_work_units'])
    retry_unit = float(CONFIG['retry_work_units_per_conflict'])

    for _ in range(n_epochs):
        # Work generated this epoch; offer is actually sampled at 80K TPS.
        arrivals = int(rng.poisson(offered_tps * epoch_s))
        total_arrivals += arrivals
        sources = rng.multinomial(arrivals, np.full(shards, 1.0 / shards))
        cross_sources = rng.binomial(sources, ratio)
        local = sources - cross_sources
        cross_count = int(cross_sources.sum())
        total_local_arrivals += int(local.sum())
        total_cross_arrivals += cross_count

        # Explicit source-target pair totals, excludes self-routing.
        pair_arrivals = np.zeros((shards, shards), dtype=int)
        if cross_count:
            for src in np.nonzero(cross_sources)[0]:
                n = int(cross_sources[src])
                targets = rng.multinomial(n, np.full(shards - 1, 1.0 / (shards - 1)))
                pair_arrivals[src, :src] = targets[:src]
                pair_arrivals[src, src + 1:] = targets[src:]
        if int(pair_arrivals.sum()) != cross_count:
            raise AssertionError('Cross-pair allocation lost transactions')
        arrived_cross_by_pair += pair_arrivals
        cross_target_arrivals = pair_arrivals.sum(axis=0)

        # Lock-contention proxy depends on target occupancy and node resources.
        lock_slots = np.maximum(1, all_nodes_by_shard * CONFIG['lock_slots_per_node_per_epoch'])
        collision_prob = -np.expm1(-np.maximum(0, cross_target_arrivals - 1) / lock_slots)
        conflicts = rng.binomial(cross_target_arrivals, collision_prob)
        n_conflicts = int(conflicts.sum())
        total_conflicts += n_conflicts
        # Cross-shard conflict retry is *extra work*, not a new transaction.
        retry_new = retry_unit * conflicts.astype(float)
        # Source side retry approximation charges the same total quantity.
        if cross_count:
            retry_new += retry_unit * cross_sources * (n_conflicts / cross_count)

        # Existing backlogs are never discarded when a new epoch arrives.
        outstanding_local += local
        outstanding_src += pair_arrivals
        outstanding_dst += pair_arrivals
        outstanding_retry_work += retry_new

        local_before = outstanding_local.copy()
        src_before = outstanding_src.copy()
        dst_before = outstanding_dst.copy()
        retry_before = outstanding_retry_work.copy()
        work_local = local_before
        work_src = cross_source_unit * src_before
        work_dst = cross_target_unit * dst_before
        work_retry = retry_before
        available_work = work_local + work_src.sum(axis=1) + work_dst.sum(axis=0) + work_retry
        if not np.all(np.isfinite(available_work)):
            raise AssertionError('Nonfinite backlog')
        # All outstanding fluid work competes for finite shard capacity.
        fraction = np.minimum(1.0, cap_epoch / np.maximum(1e-15, available_work))
        utilized_work = np.minimum(available_work, cap_epoch)
        epoch_work_conservation = np.max(np.abs(available_work - utilized_work - available_work * (1.0 - fraction)))
        max_work_conservation_error = max(max_work_conservation_error, float(epoch_work_conservation))
        outstanding_local *= (1.0 - fraction)
        outstanding_src *= (1.0 - fraction[:, None])
        outstanding_dst *= (1.0 - fraction[None, :])
        outstanding_retry_work *= (1.0 - fraction)

        local_done = local_before * fraction
        source_done = src_before * fraction[:, None]
        target_done = dst_before * fraction[None, :]
        total_local_completed += float(local_done.sum())
        cumulative_src_done += source_done
        cumulative_dst_done += target_done
        # Critical correction: confirmations are cumulative and are paired by
        # SOURCE and TARGET, so service from earlier epochs is never forgotten.
        cross_confirmed_new_total = np.minimum(
            cumulative_src_done, cumulative_dst_done
        )
        if np.any(cross_confirmed_new_total + 1e-9 < cumulative_cross_confirmed):
            raise AssertionError('Nonmonotonic pair confirmation')
        cumulative_cross_confirmed = cross_confirmed_new_total
        if np.any(cumulative_cross_confirmed > arrived_cross_by_pair + 1e-7):
            raise AssertionError('Confirmed more than generated for a shard pair')

        total_confirmed = total_local_completed + float(cumulative_cross_confirmed.sum())
        outstanding_tx = total_arrivals - total_confirmed
        if not (-1e-6 <= outstanding_tx <= total_arrivals + 1e-6):
            raise AssertionError('Transaction mass conservation failed')
        max_mass_conservation_error = max(
            max_mass_conservation_error,
            abs(total_arrivals - total_confirmed - outstanding_tx)
        )
        peak_pending = max(peak_pending, outstanding_tx)
        remaining_work = (
            outstanding_local
            + cross_source_unit * outstanding_src.sum(axis=1)
            + cross_target_unit * outstanding_dst.sum(axis=0)
            + outstanding_retry_work
        )
        peak_backlog_work = max(peak_backlog_work, float(remaining_work.sum()))
        arrival_load = (
            local + cross_source_unit * cross_sources
            + cross_target_unit * cross_target_arrivals + retry_new
        ) / cap_epoch
        peak_shard_rho = max(peak_shard_rho, float(arrival_load.max()))
        overloaded_epochs += int(np.any(arrival_load >= 1.0))

        # These are delay proxies for arrivals, NOT realized confirmation times.
        wait_ms = 1000.0 * remaining_work / cap_per_s
        # No clipping: record the actual proxy, even if it exceeds 30s.
        coord_ms = (CONFIG['base_network_ms']
                    + CONFIG['network_delay_per_log2_shards_ms'] * np.log2(shards)
                    + CONFIG['commit_coordination_ms'])
        local_delay_ms = CONFIG['base_local_confirmation_ms'] + wait_ms
        local_delay_weight += int(local.sum())
        latency_local_weighted += float(np.dot(local, local_delay_ms))
        if cross_count:
            src_wait = float(np.sum(pair_arrivals * wait_ms[:, None])) / cross_count
            dst_wait = float(np.sum(pair_arrivals * wait_ms[None, :])) / cross_count
            cross_delay_ms = (CONFIG['base_local_confirmation_ms']
                              + coord_ms + src_wait + dst_wait
                              + 12.5 * n_conflicts / cross_count)
            latency_cross_weighted += cross_count * cross_delay_ms
            cross_queue_delay_weighted += cross_count * (src_wait + dst_wait)
            cross_conflict_delay_weighted += 12.5 * n_conflicts
            cross_delay_weight += cross_count
            coord_delay_weighted += cross_count * coord_ms
            mean_payload_kb = float(rng.uniform(0.5, 2.0))
            n_target_validators = float(np.dot(cross_target_arrivals, validator_counts)) / cross_count
            per_message = mean_payload_kb + CONFIG['protocol_header_kb_per_message']
            payload_part = (cross_count * CONFIG['message_count_per_cross_transaction'] * per_message
                            + n_conflicts * 2 * per_message)
            metadata_part = (cross_count * n_target_validators *
                             CONFIG['validator_metadata_kb_per_validator_per_cross_tx'])
            sync_payload_header_kb += payload_part
            sync_validator_metadata_kb += metadata_part
            sync_kb += payload_part + metadata_part

    final_confirmed = total_local_completed + float(cumulative_cross_confirmed.sum())
    # Tolerate only floating-roundoff (not a physically impossible >100%).
    if final_confirmed > total_arrivals + 1e-6:
        raise AssertionError("Completed more transactions than generated")
    final_confirmed = min(float(total_arrivals), max(0.0, final_confirmed))
    final_pending = float(total_arrivals) - final_confirmed
    # Unmatched legs exist while one shard of a pair has completed more than
    # the other. These are NOT fully confirmed transactions.
    unpaired_src = float(np.maximum(0.0, cumulative_src_done - cumulative_cross_confirmed).sum())
    unpaired_dst = float(np.maximum(0.0, cumulative_dst_done - cumulative_cross_confirmed).sum())
    if abs(total_arrivals - (total_local_arrivals + total_cross_arrivals)) > 0:
        raise AssertionError('Incorrect local/cross arrival split')
    if not np.isfinite([final_confirmed, final_pending, peak_shard_rho,
                        peak_backlog_work, max_work_conservation_error]).all():
        raise AssertionError('Nonfinite outputs')
    if (max_work_conservation_error > 1e-7 or max_mass_conservation_error > 1e-6):
        raise AssertionError('Fluid mass/work accounting failed')

    return {
        'seed': int(seed), 'shards': int(shards), 'cross_ratio_target': float(ratio),
        'cross_ratio_actual': float(total_cross_arrivals / max(1, total_arrivals)),
        'duration_s': float(duration), 'epochs': int(n_epochs),
        'offered_tps_configured': float(offered_tps), 'generated_tx': int(total_arrivals),
        'cross_tx': int(total_cross_arrivals), 'local_tx': int(total_local_arrivals),
        'confirmed_tx_est': float(final_confirmed),
        'local_confirmed_est': float(total_local_completed),
        'cross_confirmed_est': float(cumulative_cross_confirmed.sum()),
        'goodput_est_tps': float(final_confirmed / duration),
        'completion_fraction_est': float(final_confirmed / max(1, total_arrivals)),
        'pending_tx_est': float(max(0.0, final_pending)),
        'peak_pending_tx_est': float(peak_pending),
        'unmatched_cross_src_legs_est': float(unpaired_src),
        'unmatched_cross_dst_legs_est': float(unpaired_dst),
        'cross_shard_delay_proxy_ms': float(latency_cross_weighted / max(1, cross_delay_weight)),
        'local_delay_proxy_ms': float(latency_local_weighted / max(1, local_delay_weight)),
        'coordination_delay_assumption_ms': float(coord_delay_weighted / max(1, cross_delay_weight)),
        'sync_overhead_mb': float(sync_kb / 1024.0),
        'sync_payload_header_mb': float(sync_payload_header_kb / 1024.0),
        'sync_validator_metadata_mb': float(sync_validator_metadata_kb / 1024.0),
        'cross_queue_delay_proxy_ms': float(cross_queue_delay_weighted / max(1, cross_delay_weight)),
        'cross_conflict_delay_assumption_ms': float(cross_conflict_delay_weighted / max(1, cross_delay_weight)),
        'cross_local_base_delay_ms': float(CONFIG['base_local_confirmation_ms']),
        'final_drain_time_proxy_s': float(np.max(remaining_work / cap_per_s)),
        'capacity_multiplier': float(capacity_multiplier),
        'conflict_pct_of_cross_tx': float(100.0 * total_conflicts / max(1, total_cross_arrivals)),
        'total_conflicts': int(total_conflicts),
        'overloaded_epoch_fraction': float(overloaded_epochs / n_epochs),
        'peak_shard_arrival_load_ratio': float(peak_shard_rho),
        'peak_queued_work_units': float(peak_backlog_work),
        'final_queued_work_units': float(remaining_work.sum()),
        'max_work_balance_error': float(max_work_conservation_error),
        'max_mass_balance_error': float(max_mass_conservation_error),
        'min_shard_validators': int(validator_counts.min()),
        'max_shard_validators': int(validator_counts.max()),
        'total_validator_nodes': int(validator_counts.sum()),
        'shards_with_zero_validators': int(np.sum(validator_counts == 0)),
    }


# --- Sensitivity experiment runner ---
#!/usr/bin/env python3
"""Auditable sensitivity analysis of InterShard V4 (independent aggregate model).

Replays V4 exactly when capacity_multiplier=1, and constructs alternative
communication-accounting rules using SAME simulated cross-transaction events.
Does not treat modeled delay as observed confirmation latency.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


CAPACITY_FACTORS = (0.75, 1.00, 1.25)
ROUTING_KB_PER_LOG2 = (0.5, 2.0, 4.0, 8.0)
DIGEST_KB_PER_TX = 1.0


def expected_seed(base, shards, ratio, run):
    return base + 100000 * SHARD_COUNTS.index(shards) + 1000 * CROSS_RATIOS.index(ratio) + run


def config_dict(args):
    return {
        'version': 'InterShard V4 sensitivity audit 1.0',
        'duration_s': args.duration, 'epoch_s': args.epoch,
        'offered_tps': args.offered_tps, 'seed_base': args.seed_base,
        'runs_per_cell': args.runs, 'shards': SHARD_COUNTS,
        'cross_ratios': CROSS_RATIOS, 'capacity_multipliers': CAPACITY_FACTORS,
        'routing_kb_per_cross_tx_per_log2_shard': ROUTING_KB_PER_LOG2,
        'digest_kb_per_cross_tx': DIGEST_KB_PER_TX,
        'V4_cost_assumptions': CONFIG,
        'measurement_warning': 'All policy costs are hypothetical bookkeeping scenarios. Alternative routing overhead is not fed back into queues. The capacity multiplier is a scenario assumption. Delay is a backlog proxy, not measured confirmation latency.',
        'overhead_unit': 'MiB (1024 KiB), historically named mb in V4',
        'reference_5_1': 'No direct numeric calibration to the integrated simulator; fixed validator allocation and service assumptions differ.'
    }


def check_existing(df, args):
    required = {'shards','cross_ratio_target','run','seed','capacity_multiplier',
                'sync_payload_header_mb','sync_validator_metadata_mb'}
    if not required.issubset(df.columns):
        raise ValueError(f'Existing checkpoint lacks columns: {required-set(df.columns)}')
    if df.duplicated(['shards','cross_ratio_target','run','capacity_multiplier']).any():
        raise ValueError('Duplicate records in checkpoint')
    for r in df.itertuples(index=False):
        s,ratio,run,factor=int(r.shards),float(r.cross_ratio_target),int(r.run),float(r.capacity_multiplier)
        if s not in SHARD_COUNTS or not any(np.isclose(ratio, q) for q in CROSS_RATIOS) or not any(np.isclose(factor, x) for x in CAPACITY_FACTORS):
            raise ValueError('Checkpoint contains incompatible design')
        ratio_index=int(np.argmin(np.abs(np.asarray(CROSS_RATIOS)-ratio)))
        if int(r.seed)!=expected_seed(args.seed_base,s,CROSS_RATIOS[ratio_index],run-1):
            raise ValueError('Seed mismatch in checkpoint')
        if not (np.isclose(r.duration_s,args.duration) and
                np.isclose(r.offered_tps_configured,args.offered_tps) and
                int(r.epochs)==int(round(args.duration/args.epoch))):
            raise ValueError('Run specification mismatch in checkpoint')


def regenerate_tables(df,out):
    # 7 counterfactual accounting policies from identical simulated events.
    policies=[('V4_validator_metadata',None,None),('fixed_digest_1KB',DIGEST_KB_PER_TX,None)]
    policies += [(f'routing_aware_{v:g}KB_log2',None,v) for v in ROUTING_KB_PER_LOG2]
    rows=[]
    for label,digest,routing in policies:
        part=df[['shards','cross_ratio_target','run','seed','capacity_multiplier',
                 'cross_tx','sync_payload_header_mb','sync_validator_metadata_mb',
                 'sync_overhead_mb','completion_fraction_est','goodput_est_tps',
                 'cross_shard_delay_proxy_ms']].copy()
        if digest is not None:
            metadata_mb=part.cross_tx * digest / 1024
        else:
            metadata_mb=part.sync_validator_metadata_mb
        routing_mb=0.0 if routing is None else part.cross_tx * (np.log2(part.shards) * routing) / 1024.0
        part['communication_policy']=label
        part['metadata_component_mib']=metadata_mb
        part['routing_component_mib']=routing_mb
        part['sync_overhead_mib']=part.sync_payload_header_mb + metadata_mb + routing_mb
        rows.append(part)
    policy_runs=pd.concat(rows,ignore_index=True)
    policy_runs.to_csv(out/'communication_sensitivity_per_run.csv',index=False)
    policy_summary=policy_runs.groupby(['communication_policy','capacity_multiplier','shards','cross_ratio_target'],as_index=False).agg(
        n=('sync_overhead_mib','size'),
        sync_mean_mib=('sync_overhead_mib','mean'),
        sync_sd_mib=('sync_overhead_mib','std'),
        metadata_mean_mib=('metadata_component_mib','mean'),
        routing_mean_mib=('routing_component_mib','mean'),
    )
    policy_summary.to_csv(out/'communication_sensitivity_summary.csv',index=False)

    metrics=['completion_fraction_est','goodput_est_tps','pending_tx_est','cross_shard_delay_proxy_ms',
             'cross_queue_delay_proxy_ms','coordination_delay_assumption_ms','cross_conflict_delay_assumption_ms',
             'final_drain_time_proxy_s','final_queued_work_units','overloaded_epoch_fraction']
    groups=df.groupby(['capacity_multiplier','shards','cross_ratio_target'],as_index=False)
    results=groups.agg(n=('seed','size'),**{m+'_mean':(m,'mean') for m in metrics},
                       **{m+'_sd':(m,'std') for m in metrics})
    results.to_csv(out/'capacity_sensitivity_summary.csv',index=False)
    df[['capacity_multiplier','shards','cross_ratio_target','run','seed',
        'cross_shard_delay_proxy_ms','cross_queue_delay_proxy_ms',
        'coordination_delay_assumption_ms','cross_conflict_delay_assumption_ms',
        'final_drain_time_proxy_s','final_queued_work_units','pending_tx_est',
        'overloaded_epoch_fraction']].to_csv(out/'delay_diagnostics_per_run.csv',index=False)

    # Fully paired within cell and seed; report changes, not circular p-values.
    baseline=df[np.isclose(df.capacity_multiplier,1)].copy()
    comparison=df[~np.isclose(df.capacity_multiplier,1)].merge(
        baseline[['shards','cross_ratio_target','run','seed','completion_fraction_est','cross_shard_delay_proxy_ms']],
        on=['shards','cross_ratio_target','run','seed'],suffixes=('','_at_base'),validate='many_to_one')
    comparison['completion_difference_pp']=100*(comparison.completion_fraction_est-comparison.completion_fraction_est_at_base)
    comparison['delay_difference_ms']=comparison.cross_shard_delay_proxy_ms-comparison.cross_shard_delay_proxy_ms_at_base
    comparison.to_csv(out/'capacity_paired_differences.csv',index=False)

    # Verify decomposition exactly; denominator includes base/local component.
    recomposed=df.cross_queue_delay_proxy_ms+df.coordination_delay_assumption_ms+df.cross_conflict_delay_assumption_ms+df.cross_local_base_delay_ms
    delay_error=float(np.max(np.abs(recomposed-df.cross_shard_delay_proxy_ms)))
    sync_error=float(np.max(np.abs(df.sync_payload_header_mb+df.sync_validator_metadata_mb-df.sync_overhead_mb)))
    tx_error=float(np.max(np.abs(df.generated_tx-df.confirmed_tx_est-df.pending_tx_est)))
    if not (delay_error < 1e-7 and sync_error < 1e-7 and tx_error < 1e-5):
        raise AssertionError((delay_error,sync_error,tx_error))
    if ((df.shards_with_zero_validators!=0).any() or not np.isfinite(df.select_dtypes(include='number').to_numpy()).all()):
        raise AssertionError('Invalid validator count or nonfinite result')
    report={
        'simulation_runs':len(df), 'expected_runs':30*len(CAPACITY_FACTORS)*int(df.run.max()),
        'policy_accounting_rows':len(policy_runs), 'maximum_delay_decomposition_error_ms':delay_error,
        'maximum_sync_decomposition_error_mib':sync_error,
        'maximum_transaction_balance_error':tx_error,
        'delays_over_simulation_window_count':int((df.cross_shard_delay_proxy_ms>df.duration_s*1000).sum()),
        'high_delay_over_10_seconds_count':int((df.cross_shard_delay_proxy_ms>10000).sum()),
        'warning':'Queue delay estimates are arrival-weighted backlog clearing proxies and can extend beyond observation window; exclude them from confirmed transaction latency statistics.'
    }
    (out/'VALIDATION.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    summary_lines=['# InterShard V4 sensitivity audit','',
        f"- Independent core evaluations: **{len(df)}**",f"- Communication accounting counterfactuals: **{len(policy_runs)}**",'',
        '## Interpretation',
        'The reference communication accounting scales validator metadata with validators in the target shard. With a fixed population of 400 eligible validators, metadata per target tends to decline as shard count increases.',
        'The fixed-digest policy replaces the target-validator-proportional term with a hypothetical constant 1 KiB per cross transaction. Routing-aware policies add 0.5/2/4/8 KiB per cross transaction per log2(number of shards). These are counterfactual billing assumptions, not implemented network traffic.',
        'Capacity sensitivities (0.75x, 1.00x, 1.25x) rerun the identical pair-cohort fluid model with capacity multiplied; they DO change modeled completion and queue backlogs.',
        'Communication policy alternatives are POST-HOC accounting only; they do NOT change service capacity, delays, confirmations or transaction paths, and must not be presented as a full rerun of protocol mechanics.',
        'The backlog-based delay proxy is not measured confirmation latency and may approach/exceed simulation duration because it extrapolates required time for existing work; the final drain-time proxy assumes zero future arrivals and constant per-shard capacity.',
        'Do not calculate significance tests comparing deterministic accounting transformations on the same event records. Differences are assumption-driven, not independent replications.',
        '', '## Validation',f'- Max delay decomposition error (ms): {delay_error:.3g}',
        f'- Max sync decomposition error (MiB): {sync_error:.3g}',f'- Max transaction mass error: {tx_error:.3g}',
        '', '## Comparison to Section 5.1',
        'The integrated model and the independent V4 fluid model use different service scheduling, validator activation and confirmation definitions; only nominal load and population match. This study is a conditional sensitivity supplement, not a numerical replication of Section 5.1.',
        '', '## Not addressed',
        'This analysis does not fix the manuscript abstract, publish a repository DOI or validate unmodeled blockchain communication/2PC/consensus. Those require manuscript/repository work.'
    ]
    (out/'REPORT.md').write_text('\n'.join(summary_lines)+'\n',encoding='utf-8')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs',type=int,default=10)
    p.add_argument('--duration',type=float,default=30.0)
    p.add_argument('--epoch',type=float,default=0.05)
    p.add_argument('--offered-tps',type=float,default=80000.0)
    p.add_argument('--seed-base',type=int,default=20261108)
    p.add_argument('--out',type=Path,default=Path('intershard_v4_sensitivity_results'))
    args=p.parse_args()
    if args.runs < 1 or args.duration<=0 or args.epoch<=0 or args.offered_tps<=0:
        p.error('runs,duration,epoch,offered-tps must be positive')
    if not np.isclose(round(args.duration/args.epoch)*args.epoch,args.duration):
        p.error('duration must be divisible by epoch')
    args.out.mkdir(parents=True,exist_ok=True)
    config=config_dict(args)
    config_path=args.out/'config.json'
    if config_path.exists():
        old=json.loads(config_path.read_text(encoding='utf-8'))
        if old != json.loads(json.dumps(config)):
            raise ValueError('Existing output folder contains different experiment settings. Use a new --out.')
    else:
        config_path.write_text(json.dumps(config,indent=2),encoding='utf-8')
    checkpoint=args.out/'simulation_core_per_run.csv'
    if checkpoint.exists():
        df=pd.read_csv(checkpoint)
        check_existing(df,args)
        existing=df.to_dict('records')
    else:
        existing=[]
    done={(int(r['shards']),round(float(r['cross_ratio_target']),8),int(r['run']),round(float(r['capacity_multiplier']),5)) for r in existing}
    for cap in CAPACITY_FACTORS:
        for s in SHARD_COUNTS:
            for ratio in CROSS_RATIOS:
                count=0
                for run in range(args.runs):
                    key=(s,round(ratio,8),run+1,round(cap,5))
                    if key in done: continue
                    seed=expected_seed(args.seed_base,s,ratio,run)
                    r=_run_one(s,ratio,seed,args.duration,args.epoch,args.offered_tps,capacity_multiplier=cap)
                    r['run']=run+1
                    existing.append(r)
                    done.add(key)
                    count+=1
                pd.DataFrame(existing).to_csv(checkpoint,index=False)
                print(f'Capacity {cap:.2f}x | {s} shards | {ratio:.0%} cross | {count} new (total {len(existing)})',flush=True)
    df=pd.DataFrame(existing)
    report=regenerate_tables(df,args.out)
    print('Completed:',report['simulation_runs'],'core evaluations /',report['policy_accounting_rows'],'accounting cases',flush=True)
    print('Results:',args.out.resolve(),flush=True)

if __name__=='__main__':
    main()
