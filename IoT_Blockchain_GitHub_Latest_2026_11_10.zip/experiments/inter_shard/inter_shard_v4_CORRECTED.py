#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent, capacity-constrained inter-shard *aggregate* fluid simulation (V4).

NOT a packet-level / transaction-level DES, nor an implementation of an actual
2-phase-commit consensus protocol. Pair-level transaction equivalents and cross-shard service legs persist
across epochs; paired source/target service is accounted cumulatively. All service, contention, and communication parameters are
scenario assumptions and must be disclosed when interpreting the results.

Design: shard count [2,4,8,16,32,64] x cross-shard ratio [5,10,15,25,35%]
        x 10 independent scenario seeds by default. 30 seconds, 80,000 offered TPS.

Outputs: per_run.csv, summary_by_configuration.csv, table18_by_shard.csv,
         statistical_tests.csv, config.json, README.txt.
"""
import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

SHARD_COUNTS = (2, 4, 8, 16, 32, 64)
CROSS_RATIOS = (0.05, 0.10, 0.15, 0.25, 0.35)
DEVICE_COUNTS = {"sensor": 600, "gateway": 250, "edge": 100, "cloud": 50}
# Assumed *effective processing capacities* (work-units/s), not empirical specs.
VALIDATOR_CAPACITY = {"gateway": 120.0, "edge": 350.0, "cloud": 650.0}
CONFIG = {
    "scenario": "independent aggregate fluid/bulk-service inter-shard model",
    "node_population": DEVICE_COUNTS,
    "sensor_role": "transaction generation only, never a validator",
    "effective_capacity_work_units_per_s_by_validator_class": VALIDATOR_CAPACITY,
    "cross_source_work_units": 1.15,
    "cross_target_work_units": 1.00,
    "retry_work_units_per_conflict": 0.65,
    "lock_slots_per_node_per_epoch": 16,
    "base_local_confirmation_ms": 2.0,
    "base_network_ms": 5.0,
    "network_delay_per_log2_shards_ms": 0.22,
    "commit_coordination_ms": 2.0,
    "message_count_per_cross_transaction": 4,
    "protocol_header_kb_per_message": 0.25,
    "validator_metadata_kb_per_validator_per_cross_tx": 0.08,
    "cross_pair_confirmations": "min(cumulative_src_leg_completed, cumulative_dst_leg_completed) per ordered shard pair, with persistent work and cumulative pair matching",
    "scheduling": "fluid processor-sharing across local, source-leg, destination-leg and retry-work backlogs",
    "delay_boundary": "modeled backlog-based delay proxy for arrival epochs; NOT observed confirmation latency",
    "shard_validator_provisioning": "Exactly one eligible validator reserved per shard, sampled without replacement from global eligible classes; all remaining nodes distributed multinomially. No synthetic nodes added.",
    "model_warning": "Epoch-level, pair-aggregated fluid processor-sharing model; source/target legs paired cumulatively by shard pair, not actual atomic 2PC or a production consensus implementation. All costs are assumed.",
}


def _balanced_node_counts(num_shards, rng):
    """Provision at least one validator per shard while conserving node classes.

    Every shard first receives exactly one eligible validator drawn without
    replacement from the global gateway/edge/cloud population. Remaining
    validator nodes and all sensors are distributed stochastically.

    This explicitly models a shard-liveness provisioning constraint. It is NOT
    evidence that random unconstrained assignment avoids empty committees.
    """
    total_eligible = sum(DEVICE_COUNTS[k] for k in VALIDATOR_CAPACITY)
    if num_shards > total_eligible:
        raise ValueError(
            f"Cannot provision {num_shards} shards with {total_eligible} eligible validators. "
            "Reduce shard count or increase eligible validators."
        )
    counts = {kind: np.zeros(num_shards, dtype=int) for kind in DEVICE_COUNTS}
    # Choose the class of each shard's mandatory validator from the available
    # pool, preserving the class proportions without replacement.
    available = dict(DEVICE_COUNTS)
    for sid in rng.permutation(num_shards):
        types = tuple(VALIDATOR_CAPACITY)
        probabilities = np.array([available[t] for t in types], dtype=float)
        probabilities /= probabilities.sum()
        chosen = types[int(rng.choice(len(types), p=probabilities))]
        counts[chosen][sid] += 1
        available[chosen] -= 1
    for kind, original_count in DEVICE_COUNTS.items():
        remaining = available[kind] if kind in VALIDATOR_CAPACITY else original_count
        counts[kind] += rng.multinomial(remaining, np.full(num_shards, 1.0 / num_shards))
        assert int(counts[kind].sum()) == original_count
    validator_per_shard = sum((counts[k] for k in VALIDATOR_CAPACITY),
                              start=np.zeros(num_shards, dtype=int))
    assert np.all(validator_per_shard >= 1)
    return counts


def _run_one(shards, ratio, seed, duration, epoch_s, offered_tps):
    """Pair-cohort fluid processor-sharing model with persistent backlog.

    Local transaction mass and the two validation legs of each source-target
    cross-shard pair persist across epochs. Each epoch's service applies to all
    outstanding work (new + earlier). Completion of cross-shard transaction mass
    for a given pair is bounded by BOTH cumulatively served legs of that pair.

    This is not a discrete-event atomic-commit protocol, and fractional
    completions are expected: the units are aggregate transaction equivalents.
    """
    rng = np.random.default_rng(seed)
    n_epochs = int(round(duration / epoch_s))
    if not np.isclose(n_epochs * epoch_s, duration):
        raise ValueError('duration must be an integer multiple of epoch')
    node_counts = _balanced_node_counts(shards, rng)
    validator_counts = sum((node_counts[k] for k in VALIDATOR_CAPACITY),
                           start=np.zeros(shards, dtype=int))
    all_nodes_by_shard = sum(node_counts.values(), start=np.zeros(shards, dtype=int))
    cap_per_s = sum((node_counts[k] * VALIDATOR_CAPACITY[k] for k in VALIDATOR_CAPACITY),
                    start=np.zeros(shards, dtype=float))
    coordination_factor = 1.0 / (1.0 + 0.012 * np.log2(shards))
    cap_epoch = cap_per_s * epoch_s * coordination_factor
    if not np.all(cap_epoch > 0):
        raise AssertionError('Invalid provisioning: a shard has no service capacity')

    # Outstanding transaction equivalents; pair matrices have diagonal zero.
    outstanding_local = np.zeros(shards, dtype=float)
    outstanding_src = np.zeros((shards, shards), dtype=float)
    outstanding_dst = np.zeros((shards, shards), dtype=float)
    outstanding_retry_work = np.zeros(shards, dtype=float)
    cumulative_src_done = np.zeros((shards, shards), dtype=float)
    cumulative_dst_done = np.zeros((shards, shards), dtype=float)
    arrived_cross_by_pair = np.zeros((shards, shards), dtype=float)
    cumulative_cross_confirmed = np.zeros((shards, shards), dtype=float)

    total_arrivals = total_local_arrivals = total_cross_arrivals = 0
    total_conflicts = 0
    total_local_completed = 0.0
    sync_kb = 0.0
    peak_pending = peak_backlog_work = peak_shard_rho = 0.0
    overloaded_epochs = 0
    latency_local_weighted = latency_cross_weighted = coord_delay_weighted = 0.0
    local_delay_weight = cross_delay_weight = 0.0
    max_mass_conservation_error = max_work_conservation_error = 0.0

    cross_source_unit = float(CONFIG['cross_source_work_units'])
    cross_target_unit = float(CONFIG['cross_target_work_units'])
    retry_unit = float(CONFIG['retry_work_units_per_conflict'])

    for _ in range(n_epochs):
        # Work generated this epoch; offer is actually sampled at 80K TPS.
        arrivals = int(rng.poisson(offered_tps * epoch_s))
        total_arrivals += arrivals
        sources = rng.multinomial(arrivals, np.full(shards, 1.0 / shards))
        cross_sources = rng.binomial(sources, ratio)
        local = sources - cross_sources
        cross_count = int(cross_sources.sum())
        total_local_arrivals += int(local.sum())
        total_cross_arrivals += cross_count

        # Explicit source-target pair totals, excludes self-routing.
        pair_arrivals = np.zeros((shards, shards), dtype=int)
        if cross_count:
            for src in np.nonzero(cross_sources)[0]:
                n = int(cross_sources[src])
                targets = rng.multinomial(n, np.full(shards - 1, 1.0 / (shards - 1)))
                pair_arrivals[src, :src] = targets[:src]
                pair_arrivals[src, src + 1:] = targets[src:]
        if int(pair_arrivals.sum()) != cross_count:
            raise AssertionError('Cross-pair allocation lost transactions')
        arrived_cross_by_pair += pair_arrivals
        cross_target_arrivals = pair_arrivals.sum(axis=0)

        # Lock-contention proxy depends on target occupancy and node resources.
        lock_slots = np.maximum(1, all_nodes_by_shard * CONFIG['lock_slots_per_node_per_epoch'])
        collision_prob = -np.expm1(-np.maximum(0, cross_target_arrivals - 1) / lock_slots)
        conflicts = rng.binomial(cross_target_arrivals, collision_prob)
        n_conflicts = int(conflicts.sum())
        total_conflicts += n_conflicts
        # Cross-shard conflict retry is *extra work*, not a new transaction.
        retry_new = retry_unit * conflicts.astype(float)
        # Source side retry approximation charges the same total quantity.
        if cross_count:
            retry_new += retry_unit * cross_sources * (n_conflicts / cross_count)

        # Existing backlogs are never discarded when a new epoch arrives.
        outstanding_local += local
        outstanding_src += pair_arrivals
        outstanding_dst += pair_arrivals
        outstanding_retry_work += retry_new

        local_before = outstanding_local.copy()
        src_before = outstanding_src.copy()
        dst_before = outstanding_dst.copy()
        retry_before = outstanding_retry_work.copy()
        work_local = local_before
        work_src = cross_source_unit * src_before
        work_dst = cross_target_unit * dst_before
        work_retry = retry_before
        available_work = work_local + work_src.sum(axis=1) + work_dst.sum(axis=0) + work_retry
        if not np.all(np.isfinite(available_work)):
            raise AssertionError('Nonfinite backlog')
        # All outstanding fluid work competes for finite shard capacity.
        fraction = np.minimum(1.0, cap_epoch / np.maximum(1e-15, available_work))
        utilized_work = np.minimum(available_work, cap_epoch)
        epoch_work_conservation = np.max(np.abs(available_work - utilized_work - available_work * (1.0 - fraction)))
        max_work_conservation_error = max(max_work_conservation_error, float(epoch_work_conservation))
        outstanding_local *= (1.0 - fraction)
        outstanding_src *= (1.0 - fraction[:, None])
        outstanding_dst *= (1.0 - fraction[None, :])
        outstanding_retry_work *= (1.0 - fraction)

        local_done = local_before * fraction
        source_done = src_before * fraction[:, None]
        target_done = dst_before * fraction[None, :]
        total_local_completed += float(local_done.sum())
        cumulative_src_done += source_done
        cumulative_dst_done += target_done
        # Critical correction: confirmations are cumulative and are paired by
        # SOURCE and TARGET, so service from earlier epochs is never forgotten.
        cross_confirmed_new_total = np.minimum(
            cumulative_src_done, cumulative_dst_done
        )
        if np.any(cross_confirmed_new_total + 1e-9 < cumulative_cross_confirmed):
            raise AssertionError('Nonmonotonic pair confirmation')
        cumulative_cross_confirmed = cross_confirmed_new_total
        if np.any(cumulative_cross_confirmed > arrived_cross_by_pair + 1e-7):
            raise AssertionError('Confirmed more than generated for a shard pair')

        total_confirmed = total_local_completed + float(cumulative_cross_confirmed.sum())
        outstanding_tx = total_arrivals - total_confirmed
        if not (-1e-6 <= outstanding_tx <= total_arrivals + 1e-6):
            raise AssertionError('Transaction mass conservation failed')
        max_mass_conservation_error = max(
            max_mass_conservation_error,
            abs(total_arrivals - total_confirmed - outstanding_tx)
        )
        peak_pending = max(peak_pending, outstanding_tx)
        remaining_work = (
            outstanding_local
            + cross_source_unit * outstanding_src.sum(axis=1)
            + cross_target_unit * outstanding_dst.sum(axis=0)
            + outstanding_retry_work
        )
        peak_backlog_work = max(peak_backlog_work, float(remaining_work.sum()))
        arrival_load = (
            local + cross_source_unit * cross_sources
            + cross_target_unit * cross_target_arrivals + retry_new
        ) / cap_epoch
        peak_shard_rho = max(peak_shard_rho, float(arrival_load.max()))
        overloaded_epochs += int(np.any(arrival_load >= 1.0))

        # These are delay proxies for arrivals, NOT realized confirmation times.
        wait_ms = 1000.0 * remaining_work / cap_per_s
        # No clipping: record the actual proxy, even if it exceeds 30s.
        coord_ms = (CONFIG['base_network_ms']
                    + CONFIG['network_delay_per_log2_shards_ms'] * np.log2(shards)
                    + CONFIG['commit_coordination_ms'])
        local_delay_ms = CONFIG['base_local_confirmation_ms'] + wait_ms
        local_delay_weight += int(local.sum())
        latency_local_weighted += float(np.dot(local, local_delay_ms))
        if cross_count:
            src_wait = float(np.sum(pair_arrivals * wait_ms[:, None])) / cross_count
            dst_wait = float(np.sum(pair_arrivals * wait_ms[None, :])) / cross_count
            cross_delay_ms = (CONFIG['base_local_confirmation_ms']
                              + coord_ms + src_wait + dst_wait
                              + 12.5 * n_conflicts / cross_count)
            latency_cross_weighted += cross_count * cross_delay_ms
            cross_delay_weight += cross_count
            coord_delay_weighted += cross_count * coord_ms
            mean_payload_kb = float(rng.uniform(0.5, 2.0))
            n_target_validators = float(np.dot(cross_target_arrivals, validator_counts)) / cross_count
            per_message = mean_payload_kb + CONFIG['protocol_header_kb_per_message']
            sync_kb += (cross_count * (CONFIG['message_count_per_cross_transaction'] * per_message
                        + n_target_validators * CONFIG['validator_metadata_kb_per_validator_per_cross_tx'])
                        + n_conflicts * 2 * per_message)

    final_confirmed = total_local_completed + float(cumulative_cross_confirmed.sum())
    # Tolerate only floating-roundoff (not a physically impossible >100%).
    if final_confirmed > total_arrivals + 1e-6:
        raise AssertionError("Completed more transactions than generated")
    final_confirmed = min(float(total_arrivals), max(0.0, final_confirmed))
    final_pending = float(total_arrivals) - final_confirmed
    # Unmatched legs exist while one shard of a pair has completed more than
    # the other. These are NOT fully confirmed transactions.
    unpaired_src = float(np.maximum(0.0, cumulative_src_done - cumulative_cross_confirmed).sum())
    unpaired_dst = float(np.maximum(0.0, cumulative_dst_done - cumulative_cross_confirmed).sum())
    if abs(total_arrivals - (total_local_arrivals + total_cross_arrivals)) > 0:
        raise AssertionError('Incorrect local/cross arrival split')
    if not np.isfinite([final_confirmed, final_pending, peak_shard_rho,
                        peak_backlog_work, max_work_conservation_error]).all():
        raise AssertionError('Nonfinite outputs')
    if (max_work_conservation_error > 1e-7 or max_mass_conservation_error > 1e-6):
        raise AssertionError('Fluid mass/work accounting failed')

    return {
        'seed': int(seed), 'shards': int(shards), 'cross_ratio_target': float(ratio),
        'cross_ratio_actual': float(total_cross_arrivals / max(1, total_arrivals)),
        'duration_s': float(duration), 'epochs': int(n_epochs),
        'offered_tps_configured': float(offered_tps), 'generated_tx': int(total_arrivals),
        'cross_tx': int(total_cross_arrivals), 'local_tx': int(total_local_arrivals),
        'confirmed_tx_est': float(final_confirmed),
        'local_confirmed_est': float(total_local_completed),
        'cross_confirmed_est': float(cumulative_cross_confirmed.sum()),
        'goodput_est_tps': float(final_confirmed / duration),
        'completion_fraction_est': float(final_confirmed / max(1, total_arrivals)),
        'pending_tx_est': float(max(0.0, final_pending)),
        'peak_pending_tx_est': float(peak_pending),
        'unmatched_cross_src_legs_est': float(unpaired_src),
        'unmatched_cross_dst_legs_est': float(unpaired_dst),
        'cross_shard_delay_proxy_ms': float(latency_cross_weighted / max(1, cross_delay_weight)),
        'local_delay_proxy_ms': float(latency_local_weighted / max(1, local_delay_weight)),
        'coordination_delay_assumption_ms': float(coord_delay_weighted / max(1, cross_delay_weight)),
        'sync_overhead_mb': float(sync_kb / 1024.0),
        'conflict_pct_of_cross_tx': float(100.0 * total_conflicts / max(1, total_cross_arrivals)),
        'total_conflicts': int(total_conflicts),
        'overloaded_epoch_fraction': float(overloaded_epochs / n_epochs),
        'peak_shard_arrival_load_ratio': float(peak_shard_rho),
        'peak_queued_work_units': float(peak_backlog_work),
        'final_queued_work_units': float(remaining_work.sum()),
        'max_work_balance_error': float(max_work_conservation_error),
        'max_mass_balance_error': float(max_mass_conservation_error),
        'min_shard_validators': int(validator_counts.min()),
        'max_shard_validators': int(validator_counts.max()),
        'total_validator_nodes': int(validator_counts.sum()),
        'shards_with_zero_validators': int(np.sum(validator_counts == 0)),
    }

def _holm(pvals):
    p = np.asarray(pvals, dtype=float)
    order = np.argsort(p)
    adj = np.zeros(len(p))
    largest = 0.0
    for rank, idx in enumerate(order):
        largest = max(largest, float(p[idx]) * (len(p) - rank))
        adj[idx] = min(1.0, largest)
    return adj


def summarize(df):
    metrics = ["goodput_est_tps", "completion_fraction_est", "pending_tx_est",
               "cross_shard_delay_proxy_ms", "sync_overhead_mb", "conflict_pct_of_cross_tx",
               "overloaded_epoch_fraction", "peak_shard_arrival_load_ratio", "cross_confirmed_est",
               "unmatched_cross_src_legs_est", "final_queued_work_units"]
    rows = []
    for (s, r), sub in df.groupby(["shards", "cross_ratio_target"], sort=True):
        row = {"shards": int(s), "cross_ratio_pct": float(r * 100), "n_runs": len(sub)}
        for metric in metrics:
            row[metric + "_mean"] = float(sub[metric].mean())
            row[metric + "_sd"] = float(sub[metric].std(ddof=1))
        rows.append(row)
    return pd.DataFrame(rows), metrics


def statistics(df, metrics):
    # Explicit two-factor design: independent runs within each cell.
    # Input ratio is a manipulated factor; effects are CONDITIONAL on cost model.
    all_rows = []
    for metric in metrics:
        working = df.copy()
        observed = working[metric].to_numpy(dtype=float)
        if not np.isfinite(observed).all():
            all_rows.append({"metric": metric, "test": "NOT_TESTABLE_NONFINITE_OUTCOME",
                             "contrast": "all_shard_counts_and_ratios", "statistic": np.nan,
                             "p": np.nan, "p_holm": np.nan})
            continue
        # An identical response at every design point carries no estimable
        # between-group variation.  Do not manufacture a p-value of 1 or 0.
        globally_constant = bool(np.all(observed == observed[0]))
        working["shard_factor"] = working["shards"].astype(str)
        working["ratio_factor"] = (working["cross_ratio_target"] * 100).round(2).astype(str)
        if globally_constant:
            all_rows.append({"metric": metric, "test": "NOT_TESTABLE_CONSTANT_OUTCOME",
                             "contrast": "all_shard_counts_and_ratios", "statistic": np.nan,
                             "p": np.nan, "p_holm": np.nan})
        else:
            try:
                fit = ols(f"{metric} ~ C(shard_factor) * C(ratio_factor)", data=working).fit()
                table = anova_lm(fit, typ=2)
                for term, item in [("shard_count", "C(shard_factor)"),
                                   ("cross_ratio", "C(ratio_factor)"),
                                   ("interaction", "C(shard_factor):C(ratio_factor)")]:
                    all_rows.append({"metric": metric, "test": "two_factor_ANOVA_type_II",
                                     "contrast": term, "statistic": float(table.loc[item, "F"]),
                                     "p": float(table.loc[item, "PR(>F)"]), "p_holm": np.nan})
            except (ValueError, np.linalg.LinAlgError) as e:
                all_rows.append({"metric": metric, "test": "ANOVA_FAILED",
                                 "contrast": str(e), "statistic": np.nan, "p": np.nan, "p_holm": np.nan})
        # Independently generated runs: per ratio, contrast shard counts with
        # Kruskal--Wallis; adjusted across 5 ratios within each metric.
        tmp = []
        for r in CROSS_RATIOS:
            groups = [df.loc[(df.shards == s) &
                             (np.isclose(df.cross_ratio_target, r)), metric].values
                      for s in SHARD_COUNTS]
            if all(len(v) > 0 for v in groups):
                pooled = np.concatenate(groups)
                if np.all(pooled == pooled[0]):
                    all_rows.append({"metric": metric,
                                     "test": "NOT_TESTABLE_CONSTANT_OUTCOME",
                                     "contrast": f"shards_at_{r:.2f}_cross_ratio",
                                     "statistic": np.nan, "p": np.nan, "p_holm": np.nan})
                    continue
                stat, p = stats.kruskal(*groups)
                tmp.append((r, stat, p))
        # Adjust only the valid tests, never include undefined tests in Holm's m.
        adjusted = _holm([x[2] for x in tmp]) if tmp else []
        for (r, stat, p), adj in zip(tmp, adjusted):
            all_rows.append({"metric": metric, "test": "Kruskal_by_ratio",
                             "contrast": f"shards_at_{r:.2f}_cross_ratio", "statistic": stat,
                             "p": p, "p_holm": float(adj)})
    return pd.DataFrame(all_rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=10)
    parser.add_argument("--duration", type=float, default=30.0)
    parser.add_argument("--epoch", type=float, default=0.05)
    parser.add_argument("--offered-tps", type=float, default=80000.0)
    parser.add_argument("--seed-base", type=int, default=20261108)
    parser.add_argument("--out", type=Path, default=Path("inter_shard_v4_results"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    # Idempotent resume: can recover after an interrupted Colab session if the
    # existing output folder is retained. Never rerun a successfully saved key.
    checkpoint = args.out / "per_run.csv"
    if checkpoint.is_file():
        previous = pd.read_csv(checkpoint)
        expected_columns = {"shards", "cross_ratio_target", "run", "seed"}
        if not expected_columns.issubset(previous.columns):
            raise ValueError("Existing checkpoint has incompatible columns; choose a new --out")
        if previous.duplicated(["shards", "cross_ratio_target", "run"]).any():
            raise ValueError("Existing checkpoint contains duplicate design cells")
        if not (np.isclose(previous["duration_s"], args.duration).all()
                and np.isclose(previous["offered_tps_configured"], args.offered_tps).all()
                and (previous["epochs"] == round(args.duration / args.epoch)).all()):
            raise ValueError("Existing checkpoint has different run parameters; choose a new --out")
        for rec in previous.itertuples(index=False):
            expected_seed = (args.seed_base + 100000 * SHARD_COUNTS.index(int(rec.shards))
                             + 1000 * CROSS_RATIOS.index(round(float(rec.cross_ratio_target), 8))
                             + int(rec.run) - 1)
            if int(rec.seed) != expected_seed:
                raise ValueError("Existing checkpoint has incompatible seeds; choose a new --out")
        rows = previous.to_dict("records")
        done = {(int(r["shards"]), round(float(r["cross_ratio_target"]), 8), int(r["run"]))
                for r in rows}
        print(f"Resuming {len(rows)} already-saved evaluations", flush=True)
    else:
        rows, done = [], set()
    for s in SHARD_COUNTS:
        for r in CROSS_RATIOS:
            new_count = 0
            for run in range(args.runs):
                key = (s, round(r, 8), run + 1)
                if key in done:
                    continue
                seed = args.seed_base + 100000 * SHARD_COUNTS.index(s) + 1000 * CROSS_RATIOS.index(r) + run
                row = _run_one(s, r, seed, args.duration, args.epoch, args.offered_tps)
                row["run"] = run + 1
                rows.append(row)
                done.add(key)
                new_count += 1
            pd.DataFrame(rows).to_csv(checkpoint, index=False)
            print(f"Completed {s:2d} shards, {r*100:2.0f}% cross-shard: "
                  f"{args.runs} runs ({new_count} new); checkpoint saved", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(args.out / "per_run.csv", index=False)
    summary, metrics = summarize(df)
    summary.to_csv(args.out / "summary_by_configuration.csv", index=False)
    summary.to_csv(args.out / "table18_by_shard.csv", index=False)
    # Diagnostics are reported explicitly; ANOVA p-values are CONDITIONAL on
    # model assumptions, not evidence of physical blockchain scalability.
    diagnostics = []
    for metric in metrics:
        groups = [g[metric].to_numpy(float) for _, g in df.groupby(["shards", "cross_ratio_target"])]
        try:
            p_lev = float(stats.levene(*groups, center="median").pvalue)
        except (ValueError, ZeroDivisionError):
            p_lev = float("nan")
        diagnostics.append({"metric":metric, "variance_test":"Brown-Forsythe (Levene median)",
                            "p_variance_homogeneity":p_lev,
                            "interpretation":"ANOVA standard-F p-values require additional caution if p<0.05"})
    pd.DataFrame(diagnostics).to_csv(args.out / "model_diagnostics.csv", index=False)
    try:
        stats_df = statistics(df, metrics) if args.runs >= 3 else pd.DataFrame()
    except Exception as exc:
        (args.out / "statistical_error.txt").write_text(repr(exc), encoding="utf-8")
        raise
    stats_df.to_csv(args.out / "statistical_tests.csv", index=False)
    metadata = {"version":"V4 pair-aggregated persistent-backlog", "parameters": CONFIG, "design": {
        "shard_counts": SHARD_COUNTS, "cross_ratios": CROSS_RATIOS,
        "runs_per_cell": args.runs, "duration_s": args.duration,
        "epoch_s": args.epoch, "offered_tps": args.offered_tps,
        "seed_base": args.seed_base, "statistical_caveat":
        "Factorial ANOVA on independent seeded model runs. Run residual/variance diagnostics before inferential manuscript claims. Configured costs create expected dependencies; p-values do not establish empirical protocol scalability."}}
    (args.out / "config.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    (args.out / "README.txt").write_text(
        "INTER-SHARD V4: independent pair-aggregated capacity-constrained fluid MODEL.\n"
        "Replaces circular score S=1-min(0.5,1.5*r) with estimated completion fraction.\n"
        "All results are conditional on assumed device capacities, coordination costs,\n"
        "finite lock contention, and fluid processor-sharing approximation.\n"
        "No real transactions are individually committed; source and destination\n"
        "leg completions are matched by ordered shard pair cumulatively across epochs.\n"
        "This prevents lost backlog service but is NOT atomic 2PC. Metrics ending _est or _proxy are approximations.\n"
        "Do not treat old Table 18 numbers as directly comparable to this new model.\n"
        "All shards receive >=1 eligible validator before random remainder allocation.\n"
        "This is a revised provisioning policy; rerun all cells for fair comparison.\n"
        "Goodput is pair-level aggregate estimated confirmations, not measured consensus TPS.\n"
        "Cross-shard delay is an arrival-weighted queue/backlog proxy, not observed latency.\n"
        "model_diagnostics.csv reports Brown-Forsythe variance-homogeneity checks.\n"
        "Raw per_run.csv checkpointed after each design cell to avoid losing data.\n"
        "Report shard count and cross ratio separately. No equivalence to Section 5.1.\n", encoding="utf-8")
    print("Saved:", args.out.resolve())
    print(summary[["shards", "cross_ratio_pct", "completion_fraction_est_mean", "goodput_est_tps_mean"]].to_string(index=False))


if __name__ == "__main__":
    main()
