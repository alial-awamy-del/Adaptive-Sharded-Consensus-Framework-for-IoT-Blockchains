#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Queue Scheduling Comparison V3 — reproducible, microbatch-level DES.

Compares strict non-preemptive priority, FIFO, and packetized WFQ-inspired
virtual-finish-time scheduling, using IDENTICAL workloads, validator pools,
service-demand draws, attack multipliers, and device power assumptions.

This is an assumption-based simulator, not hardware calibration or a full
consensus protocol implementation. Each job represents up to --batch-size
transactions with one approximate common arrival time and service completion.
The simulated time for one job is proportional to its transaction count.

Usage:
  python queue_scheduling_v3.py --runs 2 --duration 2 --out /content/smoke
  python queue_scheduling_v3.py --runs 50 --duration 30 --out /content/queue_v3

Requires numpy, scipy. Run `!pip install numpy scipy` in Colab if needed.
"""
from __future__ import annotations

import argparse
import csv
import heapq
import math
from collections import deque
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy import stats

CLASSES = ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW')
CLASS_ID = {name: idx for idx, name in enumerate(CLASSES)}
WEIGHTS = np.array([0.10, 0.20, 0.30, 0.40], dtype=float)  # arrival mix
WFQ_WEIGHTS = np.array([0.40, 0.30, 0.20, 0.10], dtype=float)  # service shares
DEADLINES = np.array([0.100, 0.200, 0.500, 1.000], dtype=float)
POLICIES = ('Priority-DES', 'WFQ', 'FIFO')
POWER = {  # W: illustrative profile assumptions, NOT hardware calibration
    'sensor':  {'sleep': 0.0005, 'compute': 0.05, 'radio': 0.15},
    'gateway': {'sleep': 2.5, 'compute': 4.5, 'radio': 6.0},
    'edge':    {'sleep': 1.0, 'compute': 8.0, 'radio': 4.0},
    'cloud':   {'sleep': 20.0, 'compute': 60.0, 'radio': 20.0},
}
# Class-specific rates are intentionally not claimed to be measured hardware TPS.
NOMINAL_TPS = {'gateway': 100.0, 'edge': 500.0, 'cloud': 2000.0}
DEVICE_COUNTS = {'sensor': 600, 'gateway': 250, 'edge': 100, 'cloud': 50}
WORKERS_PER_SHARD = ('gateway', 'gateway', 'edge', 'edge', 'edge', 'edge',
                     'edge', 'edge', 'cloud', 'cloud')
METRICS = (
    'throughput_k_tps', 'overall_latency_ms', 'energy_uwh_per_confirmed_tx',
    'critical_latency_ms', 'critical_deadline_pct', 'high_latency_ms',
    'high_deadline_pct', 'completion_pct', 'backlog_tx',
)

@dataclass(frozen=True, slots=True)
class Job:
    jid: int
    shard: int
    arrival: float
    cls: int
    size: int
    demand_factor: float
    network_delay: float
    consensus_delay: float
    service_multiplier: float
    radio_multiplier: float


def make_workload(seed: int, duration: float, epoch: float, shards: int,
                  offered_tps: float, batch_size: int, attack_start: float,
                  attack_end: float) -> list[list[Job]]:
    """Generate ONE full scenario and reuse it unchanged for all policies."""
    rng = np.random.default_rng(seed)
    all_shards: list[list[Job]] = [[] for _ in range(shards)]
    jid = 0
    num_epochs = math.ceil(duration / epoch)
    for e in range(num_epochs):
        t0 = e * epoch
        dt = min(epoch, duration - t0)
        if dt <= 0:
            break
        under_attack = attack_start <= t0 < attack_end
        load_mult = 1.15 if under_attack else 1.0
        service_mult = 0.95 if under_attack else 1.0
        radio_mult = 1.05 if under_attack else 1.0
        total = int(rng.poisson(offered_tps * dt * load_mult))
        counts_by_shard = rng.multinomial(total, np.full(shards, 1.0 / shards))
        for sid, count in enumerate(counts_by_shard):
            cls_counts = rng.multinomial(int(count), WEIGHTS)
            for cls, cls_count in enumerate(cls_counts):
                if cls_count == 0:
                    continue
                sizes = [batch_size] * (int(cls_count) // batch_size)
                leftover = int(cls_count) % batch_size
                if leftover:
                    sizes.append(leftover)
                n_jobs = len(sizes)
                arrivals = t0 + rng.uniform(0.0, dt, size=n_jobs)
                demand = rng.lognormal(mean=-0.5 * 0.07**2, sigma=0.07, size=n_jobs)
                net = rng.uniform(0.0008, 0.0025, size=n_jobs)
                consensus = rng.uniform(0.0012, 0.0024, size=n_jobs)
                for j, size in enumerate(sizes):
                    all_shards[sid].append(Job(
                        jid, sid, float(arrivals[j]), cls, int(size),
                        float(demand[j]), float(net[j]), float(consensus[j]),
                        service_mult, radio_mult,
                    ))
                    jid += 1
    for shard_jobs in all_shards:
        shard_jobs.sort(key=lambda x: (x.arrival, x.jid))
    return all_shards


class ReadyQueue:
    def __init__(self, policy: str):
        self.policy = policy
        self.fifo = deque()
        self.by_class = [deque() for _ in CLASSES]
        self.fair_heap = []
        self.virtual_time = 0.0
        self.last_finish = [0.0] * len(CLASSES)

    def push(self, job: Job) -> None:
        if self.policy == 'Priority-DES':
            self.by_class[job.cls].append(job)
        elif self.policy == 'FIFO':
            self.fifo.append(job)
        else:
            # Packetized virtual-finish-time scheduler (WFQ approximation).
            # Virtual tags are assigned at arrival, not arbitrary delay factors.
            start_tag = max(self.virtual_time, self.last_finish[job.cls])
            finish_tag = start_tag + job.size / WFQ_WEIGHTS[job.cls]
            self.last_finish[job.cls] = finish_tag
            heapq.heappush(self.fair_heap, (finish_tag, job.arrival, job.jid, job))

    def pop(self) -> Job | None:
        if self.policy == 'Priority-DES':
            for q in self.by_class:
                if q:
                    return q.popleft()
            return None
        if self.policy == 'FIFO':
            return self.fifo.popleft() if self.fifo else None
        if self.fair_heap:
            finish, _, _, job = heapq.heappop(self.fair_heap)
            self.virtual_time = max(self.virtual_time, finish)
            return job
        return None

    def __bool__(self) -> bool:
        if self.policy == 'Priority-DES':
            return any(self.by_class)
        return bool(self.fifo) if self.policy == 'FIFO' else bool(self.fair_heap)


def simulate_shard(jobs: list[Job], policy: str, duration: float,
                   service_scale: float) -> dict:
    """Parallel non-preemptive servers; arrivals and service completions are events.

    A worker completes its current job even if a higher-priority job arrives.
    No job is served twice. Work arriving or finishing beyond the observation
    horizon is NOT counted as confirmed in the primary throughput denominator.
    """
    ready = ReadyQueue(policy)
    idle = deque(range(len(WORKERS_PER_SHARD)))
    completions = []  # (finish_time, sequence, server_idx, job)
    i, sequence = 0, 0
    generated = np.zeros(4, dtype=np.int64)
    mature = np.zeros(4, dtype=np.int64)
    confirmed = np.zeros(4, dtype=np.int64)
    ontime = np.zeros(4, dtype=np.int64)
    latency_weighted_s = np.zeros(4, dtype=float)
    busy_seconds = np.zeros(len(WORKERS_PER_SHARD), dtype=float)
    compute_extra_wh = 0.0
    radio_extra_wh = 0.0
    n = len(jobs)
    for job in jobs:
        generated[job.cls] += job.size
        if job.arrival + DEADLINES[job.cls] <= duration:
            mature[job.cls] += job.size

    while i < n or completions:
        next_arrival = jobs[i].arrival if i < n else math.inf
        next_finish = completions[0][0] if completions else math.inf
        t = min(next_arrival, next_finish)
        if t >= duration:
            break
        # Finish all service events at t BEFORE dispatch; no preemption.
        while completions and completions[0][0] <= t + 1e-12:
            finish, _, worker, job = heapq.heappop(completions)
            delivered = finish + job.network_delay + job.consensus_delay
            if delivered <= duration:
                confirmed[job.cls] += job.size
                delay = delivered - job.arrival
                latency_weighted_s[job.cls] += delay * job.size
                if (job.arrival + DEADLINES[job.cls] <= duration
                        and delay <= DEADLINES[job.cls]):
                    ontime[job.cls] += job.size
            idle.append(worker)
        # Enqueue all jobs that have arrived by t.
        while i < n and jobs[i].arrival <= t + 1e-12:
            ready.push(jobs[i])
            i += 1
        # Parallel assignment, current jobs run to completion (non-preemptive).
        while idle and ready:
            worker = idle.popleft()
            job = ready.pop()
            assert job is not None
            profile = WORKERS_PER_SHARD[worker]
            service_s = (job.size * job.demand_factor /
                         (NOMINAL_TPS[profile] * service_scale * job.service_multiplier))
            end = t + service_s
            # Account busy power up to observation horizon, even if unfinished.
            observed_busy_s = min(end, duration) - t
            busy_seconds[worker] += observed_busy_s
            # Worker's modeled compute and radio phases partition service time.
            pc = POWER[profile]
            compute_s = 0.80 * observed_busy_s
            radio_s = 0.20 * observed_busy_s
            compute_extra_wh += compute_s * (pc['compute'] - pc['sleep']) / 3600.0
            radio_extra_wh += radio_s * (pc['radio'] - pc['sleep']) * job.radio_multiplier / 3600.0
            sequence += 1
            heapq.heappush(completions, (end, sequence, worker, job))
        # No progress situation is impossible while future arrival/completion exists.

    return {
        'generated': generated, 'mature': mature, 'confirmed': confirmed,
        'ontime': ontime, 'latency_weighted_s': latency_weighted_s,
        'compute_extra_wh': compute_extra_wh, 'radio_extra_wh': radio_extra_wh,
        'worker_busy_seconds': float(busy_seconds.sum()),
    }


def evaluate(jobs_by_shard: list[list[Job]], policy: str, duration: float,
             service_scale: float, run: int, seed: int) -> dict:
    totals = {
        key: np.zeros(4, dtype=np.int64) for key in
        ('generated', 'mature', 'confirmed', 'ontime')
    }
    totals['latency_weighted_s'] = np.zeros(4, dtype=float)
    extra_compute = extra_radio = busy = 0.0
    for jobs in jobs_by_shard:
        out = simulate_shard(jobs, policy, duration, service_scale)
        for k in totals:
            totals[k] += out[k]
        extra_compute += out['compute_extra_wh']
        extra_radio += out['radio_extra_wh']
        busy += out['worker_busy_seconds']

    generated = totals['generated']; matured = totals['mature']
    done = totals['confirmed']; ontime = totals['ontime']
    total_arrivals = int(generated.sum()); total_done = int(done.sum())
    baseline_power = sum(DEVICE_COUNTS[d] * POWER[d]['sleep'] for d in DEVICE_COUNTS)
    baseline_wh = baseline_power * duration / 3600.0
    total_wh = baseline_wh + extra_compute + extra_radio
    row = {
        'run': run, 'seed': seed, 'policy': policy,
        'generated_tx': total_arrivals, 'confirmed_tx': total_done,
        'pending_tx': total_arrivals - total_done,
        'throughput_k_tps': total_done / duration / 1000.0,
        'completion_pct': 100.0 * total_done / max(1, total_arrivals),
        'backlog_tx': total_arrivals - total_done,
        'overall_latency_ms': float(1000 * totals['latency_weighted_s'].sum() / max(1, total_done)),
        'energy_uwh_per_confirmed_tx': 1e6 * total_wh / max(1, total_done),
        'baseline_wh': baseline_wh, 'extra_compute_wh': extra_compute,
        'extra_radio_wh': extra_radio, 'total_wh': total_wh,
        'worker_busy_seconds': busy,
    }
    for idx, cls in enumerate(CLASSES):
        name = cls.lower()
        row[f'{name}_arrivals'] = int(generated[idx])
        row[f'{name}_matured_deadlines'] = int(matured[idx])
        row[f'{name}_confirmed'] = int(done[idx])
        row[f'{name}_latency_ms'] = 1000.0 * totals['latency_weighted_s'][idx] / max(1, done[idx])
        # Conservative matured-deadline denominator INCLUDES unfinished jobs.
        row[f'{name}_deadline_pct'] = 100.0 * ontime[idx] / max(1, matured[idx])
        row[f'{name}_completion_pct'] = 100.0 * done[idx] / max(1, generated[idx])
    return row


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0]))
        wr.writeheader(); wr.writerows(rows)


def summarize(rows: list[dict]) -> list[dict]:
    output = []
    for policy in POLICIES:
        subset = [r for r in rows if r['policy'] == policy]
        for metric in METRICS:
            values = np.array([r[metric] for r in subset], dtype=float)
            output.append({'policy': policy, 'metric': metric, 'n': len(values),
                           'mean': float(values.mean()),
                           'sd_sample': float(values.std(ddof=1)) if len(values) > 1 else 0.0,
                           'min': float(values.min()), 'max': float(values.max())})
    return output


def holm_adjust(p_values: list[float]) -> list[float]:
    order = sorted(range(len(p_values)), key=lambda k: p_values[k])
    out = [0.0] * len(p_values)
    running = 0.0
    for position, idx in enumerate(order):
        running = max(running, min(1.0, p_values[idx] * (len(p_values) - position)))
        out[idx] = running
    return out


def paired_inference(rows: list[dict]) -> tuple[list[dict], list[dict]]:
    by_policy = {p: {r['run']: r for r in rows if r['policy'] == p} for p in POLICIES}
    assert all(sorted(by_policy[p]) == sorted(by_policy[POLICIES[0]]) for p in POLICIES)
    run_ids = sorted(by_policy[POLICIES[0]])
    omnibus, pairwise = [], []
    pairs = ((POLICIES[0], POLICIES[1]), (POLICIES[0], POLICIES[2]),
             (POLICIES[1], POLICIES[2]))
    for metric in METRICS:
        cols = {p: np.array([by_policy[p][i][metric] for i in run_ids]) for p in POLICIES}
        vals = np.stack([cols[p] for p in POLICIES], axis=1)
        if np.allclose(vals, vals[:, [0]], rtol=0, atol=1e-12):
            chi, p_omni = 0.0, 1.0
        else:
            chi, p_omni = stats.friedmanchisquare(*(cols[p] for p in POLICIES))
        omnibus.append({'metric': metric, 'test': 'Friedman', 'n_pairs': len(run_ids),
                        'chi_square': float(chi), 'p_value': float(p_omni)})
        pending = []
        for p, q in pairs:
            diff = cols[p] - cols[q]
            if np.allclose(diff, 0, rtol=0, atol=1e-12):
                w, pv = 0.0, 1.0
            else:
                w, pv = stats.wilcoxon(cols[p], cols[q], zero_method='wilcox',
                                       alternative='two-sided', method='auto')
            pending.append({'metric': metric, 'group_1': p, 'group_2': q,
                            'test': 'Wilcoxon paired', 'n_pairs': len(run_ids),
                            'w_statistic': float(w), 'p_raw': float(pv),
                            'mean_difference_group1_minus_group2': float(diff.mean())})
        # Holm within the 3 planned pairs for each metric.
        adj = holm_adjust([r['p_raw'] for r in pending])
        for item, ap in zip(pending, adj):
            item['p_holm'] = ap
            pairwise.append(item)
    return omnibus, pairwise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=int, default=50)
    parser.add_argument('--resume', action='store_true', help='Resume completed matched runs from per_run.csv')
    parser.add_argument('--duration', type=float, default=30.0)
    parser.add_argument('--epoch', type=float, default=0.05)
    parser.add_argument('--shards', type=int, default=10)
    parser.add_argument('--nodes', type=int, default=1000)
    parser.add_argument('--offered-tps', type=float, default=80000.0)
    parser.add_argument('--batch-size', type=int, default=50)
    parser.add_argument('--service-scale', type=float, default=1.5)
    parser.add_argument('--attack-start-epoch', type=int, default=120)
    parser.add_argument('--attack-end-epoch', type=int, default=221,
                        help='Exclusive attack end epoch (default: epoch 220 is last attacked).')
    parser.add_argument('--seed-base', type=int, default=20261108)
    parser.add_argument('--out', type=Path, default=Path('queue_v3_results'))
    args = parser.parse_args()
    if args.runs < 1 or args.duration <= 0 or args.epoch <= 0 or args.shards < 1:
        parser.error('Runs, duration, epoch, and shards must be positive.')
    if args.batch_size < 1 or args.service_scale <= 0 or args.offered_tps < 0:
        parser.error('batch-size and service-scale must be positive; offered-tps nonnegative.')
    if args.shards != 10:
        parser.error('This fixed 100-worker deployment is configured for exactly 10 shards.')
    if args.nodes != sum(DEVICE_COUNTS.values()):
        parser.error('Current device population is fixed to 1,000 nodes; change DEVICE_COUNTS for another population.')
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    existing_path = args.out / 'per_run.csv'
    if args.resume and existing_path.exists():
        with existing_path.open(newline='', encoding='utf-8-sig') as f:
            rows = [dict(r) for r in csv.DictReader(f)]
        for r in rows:
            for col in list(r):
                if col in ('policy',):
                    continue
                if col in ('run', 'seed', 'generated_tx', 'confirmed_tx', 'pending_tx', 'backlog_tx') or col.endswith(('_arrivals', '_confirmed', '_matured_deadlines')):
                    r[col] = int(r[col])
                else:
                    r[col] = float(r[col])
        finished = {run_id for run_id in range(1, args.runs + 1)
                    if {r['policy'] for r in rows if r['run'] == run_id} == set(POLICIES)}
        rows = [r for r in rows if r['run'] in finished]
        print(f'Resuming after {len(finished)} complete matched runs.', flush=True)
    else:
        finished = set()
    for run in range(1, args.runs + 1):
        if run in finished:
            continue
        seed = args.seed_base + run
        jobs_by_shard = make_workload(seed, args.duration, args.epoch, args.shards,
                                      args.offered_tps, args.batch_size,
                                      args.attack_start_epoch * args.epoch,
                                      args.attack_end_epoch * args.epoch)
        for p in POLICIES:
            row = evaluate(jobs_by_shard, p, args.duration, args.service_scale, run, seed)
            rows.append(row)
            print(f'Run {run:3}/{args.runs}, {p:12}: ' 
                  f'{row["throughput_k_tps"]:7.2f} K TPS; '
                  f'critical latency {row["critical_latency_ms"]:7.2f} ms; '
                  f'critical deadline {row["critical_deadline_pct"]:6.2f}%; '
                  f'pending {row["pending_tx"]:,}', flush=True)
        # Incremental save supports interrupted runs.
        write_csv(args.out / 'per_run.csv', rows)
    sums = summarize(rows)
    omni, pair = paired_inference(rows)
    write_csv(args.out / 'summary_mean_sd.csv', sums)
    write_csv(args.out / 'friedman_tests.csv', omni)
    write_csv(args.out / 'wilcoxon_holm_pairs.csv', pair)
    with (args.out / 'methodology_notes.txt').open('w', encoding='utf-8') as f:
        f.write(f'Node population: {DEVICE_COUNTS}; per-shard validators: {WORKERS_PER_SHARD}\n'
                f'Runs: {args.runs}; duration_s: {args.duration}; epochs: {args.epoch}\n'
                f'Offered TPS: {args.offered_tps}; batch_size: {args.batch_size}; '
                f'service_scale: {args.service_scale}; seed_base: {args.seed_base}\n'
                f'Attack window: [{args.attack_start_epoch * args.epoch}, '
                f'{args.attack_end_epoch * args.epoch}) seconds\n'
                'Arrivals Poisson; four-class multinomial allocation; '
                'fixed device-specific worker capacities; batched transaction jobs.\n'
                'Policy comparators: global FIFO by arrival time; strict non-preemptive '
                'priority, FIFO within class; virtual-finish-time packetized WFQ approximation.\n'
                'All policies reuse exactly the same workload and device resources per seed.\n'
                'Energy is a system-wide, assumed device-state model, NOT calibrated. '
                'Wh = baseline sleep power for 1000 nodes + active worker incremental '
                'compute/radio power over modeled execution.\n'
                'Deadline denominator: arrivals whose deadline matures within the 30s window. '
                'Unconfirmed matured transactions count as missed.\n'
                'Latency includes modeled service + network/consensus delay, but is '
                'conditional on confirmation by the window end.\n'
                'The queue experiment is independent of consensus-protocol V3 energy comparison; '
                'do not combine their energy-per-tx estimates.\n'
                'Friedman paired tests across policy, followed by pairwise Wilcoxon with '
                'Holm correction within each metric (not across metrics).\n')
    print('\nCompleted. Output directory:', args.out.resolve())
    for record in sums:
        if record['metric'] in ('throughput_k_tps', 'critical_latency_ms',
                                'critical_deadline_pct', 'energy_uwh_per_confirmed_tx'):
            print(f'{record["policy"]:12} {record["metric"]:32} '
                  f'{record["mean"]:9.3f} ± {record["sd_sample"]:8.3f}')


if __name__ == '__main__':
    main()
