# Reviewer Consistency Audit V3 — Google Colab

هذه الحزمة توسّع تجربة NodeScaling Capacity Audit V2 نفسها، دون تغيير احتمالات الهجمات أو الطاقة أو معدل الخدمة بغرض تحسين النتائج. تسجل جميع القيم الخام وتنتج تقريرًا يحدد الطلبات المنجزة وغير المدعومة.

## التشغيل
1. ارفع ملف ZIP إلى Colab واستخرجه داخل `/content`.
2. نفّذ الأمر:

```bash
!python /content/Reviewer_Consistency_Audit_V3/run_reviewer_audit_v3.py --nodes 500 700 1000 1500 2000 --runs 10 --duration 30 --epoch 0.05 --offered-tps 80000 --shards 10 --seed-base 20261108 --out /content/reviewer_v3_results --resume --audit-shard-epochs
```

3. ثم إنشاء تقرير المراجع:

```bash
!python /content/Reviewer_Consistency_Audit_V3/reviewer_report.py --out /content/reviewer_v3_results
```

4. لتحميل النتائج:

```python
import shutil
from google.colab import files
p = shutil.make_archive('/content/Reviewer_V3_Final_Results','zip','/content/reviewer_v3_results')
files.download(p)
```

**لا تستخدم مجلد نتائج V2 السابق مع `--resume`؛ استخدم مجلدًا جديدًا.**

## الملفات الإضافية
- `ewma_per_epoch.csv`: عتبة EWMA، ألفا، إشارات الحقيقة/التنبؤ والتصنيف مع مقاييس المؤشر في كل epoch.
- `ewma_per_run_scores.csv`: مصفوفة الالتباس وPrecision/Recall/F1 للتشغيل.
- `energy_activity_per_run.csv`: حدود الطاقة والأجهزة والأنشطة وحالات النشاط والوقت.
- `attack_epoch_intensity.csv`: شدة كل حقبة ومضاعفات DDoS والحمل الحقيقي.
- `table22_reviewer_complete.csv`: محاولات الهجوم لكل نوع ومتوسط/SD للمقاومة، مع الإشارة الصريحة لما لم يُنفذ.
- `tables10_14_provenance_audit.csv`: يبين غياب معلومات المصدر لجداول 10 و14.
- `energy_boundary_reconciliation.csv`: يفصل نطاقات 6.63 و76.23 و8081 µWh/tx ولا يدعي تصالحها دون الأدلة المستقلة.
- `REVIEWER_AUDIT_REPORT.md`: تقرير PASS/FAIL ومواضع النقص.

## ملاحظات علمية حاسمة
- هذا ليس كودًا يثبت تلقائيًا جميع النتائج المنشورة. لا يمكن استخلاص 95K TPS في Tables 10/14 أو كاشف دفاع أمني حقيقي أو 6.63 µWh/tx من تجربة Node Scaling وحدها.
- كاشف EWMA في المحرك يستخدم `EWMA_ALPHA=0.30`, `EWMA_THRESHOLD=0.08` وتصنيف epoch واقع داخل نافذة الهجوم. حساب F1 مشتق من هذه الحقيقة المرجعية المبرمجة، ولا يثبت كشف هوية المهاجمين.
- نموذج نجاح الهجمات الأصلي قرعة Bernoulli شبه ثابتة؛ لا تفسر الدرجات كأثر دفاع مقاس.
- الطاقة الكلية تشمل compute/radio/sleep لجميع العقد، مع تقدير عيني عند FAST_MODE. حدود طاقة الإجماع وSmart City غير موثقة من هذا المصدر وحده.
- الأرقام المنشورة تاريخيًا (80.25K، 13.038ms، 188.81، rho=.599) يجب أن تقارن بتشغيلات المصدر الأصلي نفسه وبالبذور نفسها، لا مع أرقام V3 الجديدة دون تفسير.
- يجب إيداع بيانات التشغيل والأكواد والإعدادات في مستودع مُؤرشف قبل الادعاء بإعادة إنتاج مباشرة.

للمقارنة مع Tables 10 و14، املأ ملف `tables10_14_source_manifest_TEMPLATE.csv` ببيانات التجربتين الأصليتين ثم شغّل:

```bash
!python /content/Reviewer_Consistency_Audit_V3/reviewer_report.py --out /content/reviewer_v3_results --external-provenance /content/Reviewer_Consistency_Audit_V3/tables10_14_source_manifest_TEMPLATE.csv
```

وجود صفوف قالب فارغة لن يُعتمد إثباتًا لحل التناقض، بل سيظهر نقص الحقول.
