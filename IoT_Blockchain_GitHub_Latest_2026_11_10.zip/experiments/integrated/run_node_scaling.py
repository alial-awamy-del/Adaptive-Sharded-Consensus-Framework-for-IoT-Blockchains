#!/usr/bin/env python3
"""Auditable wrapper for unchanged original integrated consensus simulation.

IMPORTANT: Does not synthesize reviewer-friendly results, alter model equations,
implement unsupported attack types, or claim experimental validation.
"""
import argparse
import csv
import hashlib
import json
import math
import random
from pathlib import Path
import sys
import traceback
import numpy as np

import integrated_engine_original as eng

SCALES = [500, 700, 1000, 1500, 2000]
ATTACKS = ('sybil', 'ddos', 'eclipse', 'collusion')
UNSUPPORTED = ('selfish_mining', 'bribery', 'long_range')
PRIORITIES = ('CRITICAL','HIGH','MEDIUM','LOW')


def safe_float(value):
    x = float(value)
    return x if math.isfinite(x) else None


def write_dicts(path, rows):
    if not rows:
        return
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def load_dicts(path):
    with open(path, newline='', encoding='utf-8') as fh:
        return list(csv.DictReader(fh))


def extract_run(fw, nodes, run_idx, seed, offered_tps):
    t = fw.tx.metrics
    produced = int(t['tx_generated'])
    processed = int(t['tx_processed'])
    expired = int(t['tx_expired'])
    pending = int(fw.tx.pending_count())
    diff = produced - processed - expired - pending
    # Avoid silently passing broken accounting.
    if diff != 0:
        raise RuntimeError(f'Transaction mass-balance failure: {diff} at {nodes} nodes run {run_idx}')
    ewh = float(fw.total_energy_wh)
    q = fw.metrics['queue_stats']
    qos = eng.calculate_iot_qos_metrics(fw)
    timing = fw.tx.timing_summary()
    per = {p: int(t['priority_tx_processed'].get(p, 0)) for p in PRIORITIES}
    if sum(per.values()) != processed:
        raise RuntimeError('Priority processed counts do not sum to processed total')
    offered_real = float(np.sum(fw.metrics['tx_generated_epoch'])) / fw.sim_t
    # Do not pretend fixed offered input implies exactly fixed generated traffic during attack.
    row = {
        'nodes': nodes, 'run': run_idx, 'seed': seed, 'shards': eng.NUM_SHARDS,
        'baseline_offered_tps': offered_tps,
        'realized_generated_tps': offered_real,
        'duration_s': fw.sim_t, 'generated_tx': produced, 'processed_tx': processed,
        'expired_tx': expired, 'pending_tx': pending, 'mass_balance_error': diff,
        'throughput_tps': processed / fw.sim_t,
        'completion_fraction_generated': processed / produced if produced else None,
        'confirmation_latency_ms_transaction_weighted': timing['avg_confirmation_latency_ms'],
        'latency_epoch_cumulative_average_ms': eng.safe_mean(fw.metrics['latency_ms_per_epoch']),
        'mean_rho_reported': eng.safe_mean([x.get('rho', 0) for x in q]),
        'mean_shard_rho_reported': eng.safe_mean([x.get('avg_shard_rho', 0) for x in q]),
        'mean_max_shard_rho_reported': eng.safe_mean([x.get('max_shard_rho', 0) for x in q]),
        'overloaded_shards_mean': eng.safe_mean([x.get('overloaded_shards', 0) for x in q]),
        'mean_active_validators': eng.safe_mean([x.get('c', 0) for x in q]),
        'realtime_success_fraction_model': qos['real_time_success_rate'],
        'energy_total_wh': ewh,
        'energy_per_processed_tx_uwh': ewh / processed * 1e6 if processed else None,
        'energy_boundary': 'whole_network_modeled_all_nodes_including_sleep',
        'device_sensors': int(fw.device_counts.get('sensor', 0)),
        'device_gateway': int(fw.device_counts.get('gateway', 0)),
        'device_edge': int(fw.device_counts.get('edge', 0)),
        'device_cloud': int(fw.device_counts.get('cloud', 0)),
        'attack_window_epochs': f'{fw.attack_campaign.start_epoch}-{fw.attack_campaign.end_epoch}',
    }
    prio = []
    for priority in PRIORITIES:
        prio.append({
            'nodes': nodes, 'run': run_idx, 'seed': seed, 'priority': priority,
            'processed_tx': per[priority],
            'expired_tx': int(t['priority_tx_expired'].get(priority, 0)),
            'mean_latency_ms': timing[f'{priority.lower()}_avg_latency_ms'],
            'p95_latency_ms': timing[f'{priority.lower()}_p95_latency_ms'],
            'p99_latency_ms': timing[f'{priority.lower()}_p99_latency_ms'],
            'source': 'strict-priority simulator; sampled microbatch timings',
        })
    attacks = []
    for attack in ATTACKS:
        attempted = int(fw.attack_campaign.attack_metrics[f'{attack}_attempts'])
        successes = int(fw.attack_campaign.attack_metrics[f'{attack}_success'])
        if successes > attempted:
            raise RuntimeError('Invalid attack counts')
        attacks.append({'nodes':nodes,'run':run_idx,'seed':seed,'attack_type':attack,
                        'attempts':attempted,'successes':successes,
                        'resistance':1-successes/attempted if attempted else None,
                        'supported':True,
                        'definition':'1 - successes / attempts; independent stochastic attack trial in original engine'})
    for attack in UNSUPPORTED:
        attacks.append({'nodes':nodes,'run':run_idx,'seed':seed,'attack_type':attack,
                        'attempts':None,'successes':None,'resistance':None,
                        'supported':False,'definition':'not implemented in integrated engine; do not report a score'})
    return row, prio, attacks


def grouped_summary(rows, group_fields, numeric_fields):
    groups = {}
    for r in rows:
        key = tuple(str(r[k]) for k in group_fields)
        groups.setdefault(key, []).append(r)
    output=[]
    for key, members in sorted(groups.items(), key=lambda item: tuple(int(x) if x.isdigit() else x for x in item[0])):
        summary = dict(zip(group_fields, key)); summary['n_runs'] = len(members)
        for field in numeric_fields:
            nums = []
            for m in members:
                try: value = float(m.get(field, ''))
                except (ValueError, TypeError): continue
                if math.isfinite(value): nums.append(value)
            summary[field+'_mean'] = float(np.mean(nums)) if nums else None
            summary[field+'_sd'] = float(np.std(nums, ddof=1)) if len(nums)>1 else None
            summary[field+'_valid_n'] = len(nums)
        output.append(summary)
    return output


def validate_results(rows, priorities, attacks, scales, runs):
    keys = [(int(x['nodes']),int(x['run'])) for x in rows]
    if len(keys) != len(set(keys)):
        raise RuntimeError('Duplicated node/run records')
    if len(rows) != len(scales)*runs:
        raise RuntimeError(f'Expected {len(scales)*runs} runs; found {len(rows)}')
    for n in scales:
        found = sorted(r for node,r in keys if node==n)
        if found != list(range(1,runs+1)):
            raise RuntimeError(f'Incomplete runs for nodes={n}: {found}')
    if any(int(float(x['mass_balance_error'])) != 0 for x in rows):
        raise RuntimeError('Nonzero transaction accounting discrepancy')
    if len(priorities)!=len(rows)*len(PRIORITIES) or len(attacks)!=len(rows)*(len(ATTACKS)+len(UNSUPPORTED)):
        raise RuntimeError('Incomplete per-priority or per-attack records')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',default='node_scaling_results')
    ap.add_argument('--runs',type=int,default=10)
    ap.add_argument('--nodes',nargs='+',type=int,default=SCALES)
    ap.add_argument('--seed-base',type=int,default=20261108)
    ap.add_argument('--duration',type=float,default=30.0)
    ap.add_argument('--epoch',type=float,default=0.05)
    ap.add_argument('--offered-tps',type=float,default=80000.0)
    ap.add_argument('--shards',type=int,default=10)
    ap.add_argument('--mode',choices=['edge_dominant'],default='edge_dominant')
    ap.add_argument('--resume',action='store_true')
    args=ap.parse_args()
    if args.runs<1 or args.duration<=0 or args.epoch<=0 or args.offered_tps<=0 or args.shards<1:
        ap.error('Invalid run/epoch/duration/shards/workload')
    if len(set(args.nodes))!=len(args.nodes): ap.error('Duplicate network sizes')
    if any(n<args.shards for n in args.nodes): ap.error('Not enough nodes for specified shards')
    out=Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    source=Path(eng.__file__).resolve()
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()
    cfg={'nodes':args.nodes,'runs':args.runs,'seed_base':args.seed_base,'duration_s':args.duration,
         'epoch_s':args.epoch,'baseline_offered_tps':args.offered_tps,
         'shards':args.shards,'deployment_mode':args.mode,
         'engine_path':str(source.name),'engine_sha256':source_sha256,
         'attack_types_implemented':list(ATTACKS),'unsupported_attack_types':list(UNSUPPORTED),
         'attack_note':'DDoS multiplies arrival rate in the integrated engine. Baseline offered_tps is fixed, but realized traffic is not.',
         'queue_note':'Unstable rho>=1 cannot be analyzed with steady-state Erlang-C; engine has capped/approximate waiting estimates.',
         'energy_note':'Engine estimates energy via activity-based profiles; FAST_MODE uses sampled scaled activity if enabled.',
         'latency_note':'Transaction-weighted microbatch completion time is different from arithmetic mean of per-epoch cumulative latency.',
         'model_warning':'Security attack success model is fixed stochastic Bernoulli trials and not verified defense efficacy.',
         }
    cfg_path=out/'configuration.json'
    if args.resume and cfg_path.exists():
        old=json.loads(cfg_path.read_text(encoding='utf-8'))
        if {k:v for k,v in old.items() if k!='engine_path'} != {k:v for k,v in cfg.items() if k!='engine_path'}:
            raise RuntimeError('Cannot resume: engine or experiment configuration has changed')
    elif cfg_path.exists():
        raise RuntimeError('Output folder already exists; use --resume or a fresh --out')
    cfg_path.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
    raw=out/'per_run.csv'; pp=out/'priority_per_run.csv'; at=out/'attack_per_run.csv'
    rows=load_dicts(raw) if args.resume and raw.exists() else []
    priority=load_dicts(pp) if args.resume and pp.exists() else []
    attacks=load_dicts(at) if args.resume and at.exists() else []
    done={(int(r['nodes']),int(r['run'])) for r in rows}
    eng.NUM_SHARDS=args.shards
    eng.EPOCH_DURATION=args.epoch
    eng.SIMULATION_DURATION=args.duration
    epochs=int(round(args.duration/args.epoch))
    if abs(epochs*args.epoch-args.duration)>1e-8:
        raise RuntimeError('duration must be an exact multiple of epoch')
    for node in args.nodes:
        eng.NUM_NODES=node
        for rep in range(1,args.runs+1):
            if (node,rep) in done:
                print(f'[skip] nodes={node} run={rep}',flush=True);continue
            # Same run index -> identical seed across node counts (paired seeds).
            seed=args.seed_base+rep-1
            random.seed(seed); np.random.seed(seed)
            fw=eng.RealisticHybridConsensusFramework(protocol_mode='proposed',target_tps=args.offered_tps,deployment_mode=args.mode)
            for _ in range(epochs): fw.step_epoch()
            row,pr,att=extract_run(fw,node,rep,seed,args.offered_tps)
            rows.append(row);priority.extend(pr);attacks.extend(att)
            # Persist each completed run BEFORE doing statistical reporting.
            write_dicts(raw,rows);write_dicts(pp,priority);write_dicts(at,attacks)
            print(f'[saved] nodes={node} run={rep}/{args.runs} processed={row["processed_tx"]} generated={row["generated_tx"]} pending={row["pending_tx"]} expired={row["expired_tx"]}',flush=True)
    validate_results(rows,priority,attacks,args.nodes,args.runs)
    metrics=['throughput_tps','realized_generated_tps','confirmation_latency_ms_transaction_weighted',
             'mean_rho_reported','mean_max_shard_rho_reported','mean_active_validators',
             'expired_tx','pending_tx','realtime_success_fraction_model','energy_per_processed_tx_uwh',
             'energy_total_wh','completion_fraction_generated']
    write_dicts(out/'table19_summary.csv',grouped_summary(rows,['nodes'],metrics))
    write_dicts(out/'table20_priority_summary.csv',grouped_summary(priority,['nodes','priority'],['mean_latency_ms','p95_latency_ms','processed_tx','expired_tx']))
    write_dicts(out/'table21_energy_summary.csv',grouped_summary(rows,['nodes'],['energy_per_processed_tx_uwh','energy_total_wh','processed_tx']))
    supported=[r for r in attacks if str(r['supported']).lower()=='true']
    # Per-run resistance distribution and attack counts, NOT fabricated unsupported scores.
    write_dicts(out/'table22_supported_attack_summary.csv',grouped_summary(supported,['nodes','attack_type'],['attempts','successes','resistance']))
    with open(out/'VALIDATION.txt','w',encoding='utf-8') as f:
        f.write(f'PASSED: {len(rows)} runs; {len(priority)} class rows; {len(attacks)} attack rows; zero transaction balance errors.\n')
        f.write('Warning: cannot claim all handling-editor requirements are satisfied. Engine assumptions and other manuscript experiments remain to be audited.\n')
        f.write('Table22: only 4 attack types are simulated; do not report 3 unsupported attack scores.\n')
        f.write('Check 1000-node outputs against Section 5.1 using same seeds and measurement boundaries.\n')
    print('COMPLETED AND VALIDATED:',str(out),flush=True)

if __name__=='__main__':
    main()
