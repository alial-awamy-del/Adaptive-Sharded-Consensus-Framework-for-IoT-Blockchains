#!/usr/bin/env python3
"""Postprocessing reviewer audit. No synthetic results or fabricated p-values."""
import argparse,csv,json,math,hashlib
from collections import defaultdict
from pathlib import Path
import statistics

def read(path):
    with path.open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))
def number(x):
    try: return float(x)
    except (TypeError,ValueError): return None

def save(path,records):
    if not records: return
    keys=list(dict.fromkeys(k for r in records for k in r))
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(records)

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--external-provenance',default='')
    a=p.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    errors=[]; warnings=[]; rows=[]
    required=['per_run.csv','capacity_per_run.csv','attack_per_run.csv','ewma_per_epoch.csv','energy_activity_per_run.csv','attack_epoch_intensity.csv']
    for fn in required:
        if not (out/fn).exists(): errors.append('Missing '+fn)
    if errors:
        (out/'REVIEWER_AUDIT_REPORT.md').write_text('# Reviewer audit\n\n'+ '\n'.join('- ERROR: '+x for x in errors)+'\n',encoding='utf-8')
        raise RuntimeError('; '.join(errors))
    runs=read(out/'per_run.csv'); caps=read(out/'capacity_per_run.csv')
    at=read(out/'attack_per_run.csv'); det=read(out/'ewma_per_epoch.csv'); en=read(out/'energy_activity_per_run.csv')
    epochs=read(out/'attack_epoch_intensity.csv')
    run_index={(r['nodes'],r['run']):r for r in runs}
    if len(run_index)!=len(runs): errors.append('Duplicate run records')
    if len(caps)!=len(runs) or len(en)!=len(runs): errors.append('Capacity/energy row mismatch')
    # EWMA indicators and accuracy from raw epoch flags, per run.
    byrun=defaultdict(list)
    for d in det: byrun[d['nodes'],d['run']].append(d)
    detection=[]
    for key,dr in sorted(byrun.items(),key=lambda z:(int(z[0][0]),int(z[0][1]))):
        counts={k:sum(int(float(x[k])) for x in dr) for k in ('TP','FP','TN','FN')}
        tp,fp,tn,fn=(counts[k] for k in ('TP','FP','TN','FN'))
        prec=tp/(tp+fp) if tp+fp else None; rec=tp/(tp+fn) if tp+fn else None
        f1=2*prec*rec/(prec+rec) if prec is not None and rec is not None and prec+rec else None
        detection.append({'nodes':key[0],'run':key[1],**counts,'precision':prec,'recall':rec,'f1':f1,
           'ground_truth':'active attack campaign epoch, not attacker identity','unit':'epoch'})
        if sum(counts.values())!=len(dr): errors.append('EWMA confusion count mismatch '+str(key))
    save(out/'ewma_per_run_scores.csv',detection)
    stats=[]
    for node in sorted(set(x['nodes'] for x in detection),key=int):
        dr=[d for d in detection if d['nodes']==node]
        for metric in ('precision','recall','f1'):
            z=[number(d[metric]) for d in dr];z=[x for x in z if x is not None]
            stats.append({'nodes':node,'metric':metric,'n_valid_runs':len(z),
                'mean':statistics.mean(z) if z else None,
                'sd_sample':statistics.stdev(z) if len(z)>1 else None})
    save(out/'ewma_mean_sd.csv',stats)
    # Per-category attempted and successful attack trials, no rebranding as defense outcomes.
    attacksummary=[]
    for (node,vector), rr in sorted({(r['nodes'],r['attack_type']):None for r in at}.items(),key=lambda x:(int(x[0][0]),x[0][1])):
        dr=[r for r in at if r['nodes']==node and r['attack_type']==vector]
        vals=[number(r['resistance']) for r in dr if number(r['resistance']) is not None]
        attempts=[number(r['attempts']) for r in dr if number(r['attempts']) is not None]
        successes=[number(r['successes']) for r in dr if number(r['successes']) is not None]
        if len(vals)<len(dr):
            attacksummary.append({'nodes':node,'attack_type':vector,'supported':False,'n_runs':len(dr),'mean_resistance':None,'sd_resistance':None,'mean_attempts_per_run':None,'total_attempts':None,'total_successes':None,'status':'NOT SIMULATED'})
        else:
            attacksummary.append({'nodes':node,'attack_type':vector,'supported':True,'n_runs':len(dr),
                'mean_resistance':statistics.mean(vals),'sd_resistance':statistics.stdev(vals) if len(vals)>1 else None,
                'mean_attempts_per_run':statistics.mean(attempts),'sd_attempts_per_run':statistics.stdev(attempts) if len(attempts)>1 else None,
                'total_attempts':int(sum(attempts)),'total_successes':int(sum(successes)),
                'pooled_resistance':1-sum(successes)/sum(attempts) if sum(attempts)>0 else None,
                'status':'MODEL-INTERNAL BERNOULLI OUTCOME (not measured defense bypass)'})
    save(out/'table22_reviewer_complete.csv',attacksummary)
    # External tables 10/14 require source data provenance, not just printed paper values.
    external=[]
    if a.external_provenance:
        path=Path(a.external_provenance)
        if path.is_file(): external=read(path)
        else: errors.append('External provenance specified but not found: '+str(path))
    else: warnings.append('Tables 10 and 14: original generated-load and attack configuration not supplied; 95 KTPS discrepancy UNRESOLVED')
    prov=[]
    for table in ('Table 10','Table 14'):
        r=next((x for x in external if x.get('table')==table),None)
        if r:
            fields=('source_code_sha256','base_offered_tps','realized_generated_tps','attack_enabled','duration_s','measurement_window','throughput_tps','latency_ms','seed_list','metric_definition')
            missing=[k for k in fields if not r.get(k)]
            prov.append({'table':table,'provided':True,'missing_fields':';'.join(missing),'audit_status':'PROVENANCE INCOMPLETE' if missing else 'PROVENANCE DOCUMENTED; numerical correspondence requires independent rerun'})
        else: prov.append({'table':table,'provided':False,'audit_status':'NOT VERIFIABLE FROM NODE SCALING EXPERIMENT'})
    save(out/'tables10_14_provenance_audit.csv',prov)
    # Distinct energy boundaries are not silently equated.
    energybounds=[
       {'source':'Integrated full-network model','reported_uwh_per_tx':'derived from energy_activity_per_run.csv','population':'all simulated nodes including sensors','activity':'compute + radio + sleep','time_base':'30s run by default','verification':'PROVEN from V3 per-run and activity ledger'},
       {'source':'Reported 6.63 uWh/tx','reported_uwh_per_tx':6.63,'population':'UNKNOWN without Table 10/14 experiment source','activity':'UNKNOWN; claimed consensus only','time_base':'UNKNOWN','verification':'NOT RECONCILED'},
       {'source':'Reported 76.23 uWh/tx original baseline','reported_uwh_per_tx':76.23,'population':'original 1000-node full network (verify original run seed)','activity':'whole network compute + radio + sleep','time_base':'original 30s baseline','verification':'HISTORICAL; do not equate to rerun automatically'},
       {'source':'Reported Smart City 8081 uWh/tx','reported_uwh_per_tx':8081,'population':'UNKNOWN without independent Smart City source','activity':'UNKNOWN','time_base':'UNKNOWN','verification':'NOT RECONCILED; ratio to 100 uWh/tx target = 80.81'}]
    save(out/'energy_boundary_reconciliation.csv',energybounds)
    for r in en:
        total=number(r['total_energy_wh']); tx=number(r['processed_transactions']); per=number(r['energy_per_processed_tx_uwh'])
        if tx is None or tx<=0 or abs(total/tx*1e6-per)>1e-6: errors.append('Energy ratio mismatch '+r['nodes']+'/'+r['run'])
    for r in runs:
        if number(r.get('mass_balance_error')) not in (None,0.): errors.append('Transaction mass balance failure')
    if any(number(r.get('mean_rho_reported')) is not None and number(r.get('mean_rho_reported'))>=1 for r in runs):
        warnings.append('rho>=1 in some runs: no steady-state Erlang-C inference should be made')
    warnings += ['EWMA ground truth is predefined attack-window timing; this is a detection-of-campaign metric, not detection of individual malicious validators.',
       'EWMA_THRESHOLD=0.08 should not be described as calibrated or independently validated without a held-out set.',
       'Attack success uses synthetic Bernoulli draws with base_success=0.15 modified by Uniform(0.8,1.2); scores do not measure actual security-mechanism bypass.',
       'Three attacks (selfish mining, bribery, long range) lack implemented simulations.',
       'Original Section 5.1 data and independent Tables 10/14 and Smart City scenario cannot be made comparable by postprocessing.',
       'Direct reproducibility requires public archived code/data/config with DOI or version; local ZIP alone is insufficient.',
       'E_target=0.0001 Wh/tx = 100 uWh/tx. Reported 8081 uWh/tx / target = 80.81 (different boundaries may make threshold inapplicable).']
    config=out/'configuration.json'
    if config.exists():
        d=json.loads(config.read_text()); engine=Path(__file__).with_name('integrated_engine_original.py')
        if engine.exists():
            h=hashlib.sha256(engine.read_bytes()).hexdigest()
            if d.get('engine_sha256')!=h:errors.append('Engine SHA mismatch: reproducibility violation')
    report=['# Reviewer audit — generated automatically','',f'- Runs: {len(runs)}',f'- EWMA epoch records: {len(det)}',f'- Attack-category records: {len(at)}',f'- Whole-network energy records: {len(en)}','', '## Status']
    report += ['- '+('FAIL' if errors else 'PASS')+': computational cross-file checks']
    report += ['','## Unresolved / limitations']+['- '+x for x in warnings]
    report += ['','## Errors']+(['- '+x for x in errors] if errors else ['- None identified in available ledgers'])
    report+=['','## Outputs','- `ewma_per_run_scores.csv`, `ewma_mean_sd.csv`','- `table22_reviewer_complete.csv`','- `tables10_14_provenance_audit.csv`','- `energy_boundary_reconciliation.csv`']
    (out/'REVIEWER_AUDIT_REPORT.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print('\n'.join(report[:10]))
    if errors: raise SystemExit(2)
if __name__=='__main__':main()
