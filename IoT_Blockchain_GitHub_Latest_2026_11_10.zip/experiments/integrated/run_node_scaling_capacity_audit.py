#!/usr/bin/env python3
"""Auditable wrapper for unchanged original integrated consensus simulation.

IMPORTANT: Does not synthesize reviewer-friendly results, alter model equations,
implement unsupported attack types, or claim experimental validation.
"""
import argparse
import csv
import hashlib
import json
import math
import random
from pathlib import Path
import sys
import traceback
from types import MethodType
import numpy as np

import integrated_engine_original as eng

SCALES = [500, 700, 1000, 1500, 2000]
ATTACKS = ('sybil', 'ddos', 'eclipse', 'collusion')
UNSUPPORTED = ('selfish_mining', 'bribery', 'long_range')
PRIORITIES = ('CRITICAL','HIGH','MEDIUM','LOW')


def safe_float(value):
    x = float(value)
    return x if math.isfinite(x) else None


def write_dicts(path, rows):
    if not rows:
        return
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def load_dicts(path):
    with open(path, newline='', encoding='utf-8') as fh:
        return list(csv.DictReader(fh))


def install_batch_audit(fw):
    """Observe original batches without changing service, priorities, or random draws."""
    fw.batch_audit = {'calls': 0, 'transactions': 0, 'service_time_tx_weighted_s': 0.0,
                      'batch_size_max': 0, 'batch_sizes': []}
    original = fw.tx._record_processed_batch
    def audited(*args, **kwargs):
        # Original signature: (priority, sid, k, queue_wait, service_time, ...)
        k = int(args[2]) if len(args) >= 3 else int(kwargs['k'])
        service = float(args[4]) if len(args) >= 5 else float(kwargs['service_time'])
        v = fw.batch_audit
        v['calls'] += 1; v['transactions'] += k
        v['service_time_tx_weighted_s'] += service * k
        v['batch_size_max'] = max(v['batch_size_max'], k)
        v['batch_sizes'].append(k)
        return original(*args, **kwargs)
    fw.tx._record_processed_batch = audited


def extract_capacity_epoch(fw, nodes, run_idx, seed, epoch_number, previous_shard_processed):
    """Per-epoch capacity provenance, per-shard numbers, and capacity inequalities.

    Not a posthoc calibration. Uses queue stats recorded in the original engine
    at exactly the epoch when the capacity budget was applied.
    """
    q = fw.metrics['queue_stats'][-1]
    shards = q['shards']
    dt = float(eng.EPOCH_DURATION)
    epoch_processed = int(fw.metrics['tx_processed_epoch'][-1])
    epoch_generated = int(fw.metrics['tx_generated_epoch'][-1])
    cap = 0.0; service_budget = 0; c_actual = 0; lam = 0.0
    shard_records = []
    for sid in range(eng.NUM_SHARDS):
        x = shards[sid]
        c = int(x['c_active'])
        m = float(x['mu_avg_per_validator']) if c else 0.0
        service_rate = float(x['mu_total_capacity'])
        arrival = float(x['lambda'])
        processed_now = int(fw.tx.metrics['shard_tx_processed'][sid])
        processed_delta = processed_now - int(previous_shard_processed[sid])
        if processed_delta < 0: raise AssertionError('Shard processed counter decreased')
        # The integer floor is used explicitly by process_shard_epoch.
        epoch_budget = int(max(0, math.floor(max(1, c) * max(1e-6, float(x['mu'])) * dt)))
        if c <= 0:
            # Code uses a small synthetic floor if validators are absent: record that separately.
            epoch_budget = int(max(0, math.floor(max(1e-6, float(x['mu'])) * dt)))
        if processed_delta > epoch_budget:
            raise AssertionError(f'Shard {sid}: processed={processed_delta} exceeds budget={epoch_budget}')
        cap += service_rate; service_budget += epoch_budget; c_actual += c; lam += arrival
        shard_records.append({'nodes':nodes,'run':run_idx,'seed':seed,'epoch':epoch_number,
          'shard':sid,'duration_s':dt,'c_active_validators':c,'lambda_tps':arrival,
          'mu_mean_per_validator_tps':m,'capacity_tps_c_mu':service_rate,
          'rho_raw':arrival/service_rate if service_rate>0 else None,
          'integer_epoch_capacity_tx':epoch_budget,'actual_processed_epoch_tx':processed_delta,
          'validation_capacity_floor_without_validators':int(c==0),
          'device_gateway':int(x.get('count_gateway',0)),
          'device_edge':int(x.get('count_edge',0)),
          'device_cloud':int(x.get('count_cloud',0))})
    tol=1e-7*max(1,cap,lam)
    if abs(cap-sum(float(x['mu_total_capacity']) for x in shards.values()))>tol:
        raise AssertionError('Capacity accounting failure')
    if epoch_processed>service_budget:
        raise AssertionError(f'Processed={epoch_processed} exceeds per-shard integer budget={service_budget}')
    if c_actual != sum(len(v) for v in fw.validator_manager.validators_by_shard.values()):
        raise AssertionError('System and shard validator counts disagree')
    return {'nodes':nodes,'run':run_idx,'seed':seed,'epoch':epoch_number,
      'c_system':c_actual,'shards':eng.NUM_SHARDS,'lambda_total_tps':lam,
      'mean_mu_per_active_validator_tps':cap/c_actual if c_actual else None,
      'capacity_total_tps_sum_c_mu':cap,'rho_total_raw_ratio_of_sums':lam/cap if cap>0 else None,
      'rho_engine_aggregate_raw':float(q['rho']),
      'offered_base_tps':float(fw.target_tps),
      'generated_epoch_tps':epoch_generated/dt,'processed_epoch_tps':epoch_processed/dt,
      'epoch_integer_service_budget_tx':service_budget,'processed_epoch_tx':epoch_processed,
      'generated_epoch_tx':epoch_generated,
      'capacity_slack_tx':service_budget-epoch_processed,
      'overloaded_shard_count':sum(1 for x in shard_records if x['rho_raw'] is not None and x['rho_raw']>=1),
      'zero_validator_shards':sum(1 for x in shard_records if x['c_active_validators']==0)
      }, shard_records


def capacity_run_summary(epoch_rows, shard_rows, batch):
    if not epoch_rows: raise ValueError('no epoch data')
    s=lambda field: sum(float(r[field]) for r in epoch_rows)
    n=len(epoch_rows)
    mean=lambda field: s(field)/n
    txsum=sum(int(r['processed_epoch_tx']) for r in epoch_rows)
    totalbudget=sum(int(r['epoch_integer_service_budget_tx']) for r in epoch_rows)
    assert txsum<=totalbudget
    cap_total=sum(float(r['capacity_total_tps_sum_c_mu']) for r in epoch_rows)
    lambda_total=sum(float(r['lambda_total_tps']) for r in epoch_rows)
    avgmu=mean('mean_mu_per_active_validator_tps')
    return {
      'capacity_audit_epoch_count':n,
      'mean_active_validators_system_capacity_audit':mean('c_system'),
      'mean_mu_per_validator_tps_epoch_avg':avgmu,
      'mean_mu_total_capacity_tps':cap_total/n,
      'mean_lambda_total_tps':lambda_total/n,
      'mean_rho_raw_epoch_avg':mean('rho_total_raw_ratio_of_sums'),
      'rho_ratio_of_time_avg_lambda_and_capacity':lambda_total/cap_total if cap_total else None,
      'mean_epoch_integer_budget_tx':mean('epoch_integer_service_budget_tx'),
      'total_integer_service_budget_tx':totalbudget,
      'observed_processed_tx_capacity_audit':txsum,
      'capacity_budget_utilization_processed_over_budget':txsum/totalbudget if totalbudget else None,
      'epochs_with_any_overloaded_shard':sum(int(r['overloaded_shard_count'])>0 for r in epoch_rows),
      'epochs_with_any_zero_validator_shard':sum(int(r['zero_validator_shards'])>0 for r in epoch_rows),
      'batch_calls':batch['calls'],
      'batch_tx_total':batch['transactions'],
      'batch_size_mean_per_call':batch['transactions']/batch['calls'] if batch['calls'] else None,
      'batch_size_max':batch['batch_size_max'],
      'service_time_ms_transaction_weighted_batch_component':batch['service_time_tx_weighted_s']*1000/max(1,batch['transactions']),
      'batch_factor_in_mu_equation':'NOT IDENTIFIED: batches are scheduler aggregation, not validated physical parallelism',
      'mu_capacity_definition':'per-validator device-class nominal transaction service capacity (tx/s), scaled by MU_SCALE and attack service_mult',
      'service_time_definition':'synthetic priority-specific duration attributed equally to k transactions in a processed microbatch; not reciprocal of capacity mu',
    }

def extract_run(fw, nodes, run_idx, seed, offered_tps):
    t = fw.tx.metrics
    produced = int(t['tx_generated'])
    processed = int(t['tx_processed'])
    expired = int(t['tx_expired'])
    pending = int(fw.tx.pending_count())
    diff = produced - processed - expired - pending
    # Avoid silently passing broken accounting.
    if diff != 0:
        raise RuntimeError(f'Transaction mass-balance failure: {diff} at {nodes} nodes run {run_idx}')
    ewh = float(fw.total_energy_wh)
    q = fw.metrics['queue_stats']
    qos = eng.calculate_iot_qos_metrics(fw)
    timing = fw.tx.timing_summary()
    per = {p: int(t['priority_tx_processed'].get(p, 0)) for p in PRIORITIES}
    if sum(per.values()) != processed:
        raise RuntimeError('Priority processed counts do not sum to processed total')
    offered_real = float(np.sum(fw.metrics['tx_generated_epoch'])) / fw.sim_t
    # Do not pretend fixed offered input implies exactly fixed generated traffic during attack.
    row = {
        'nodes': nodes, 'run': run_idx, 'seed': seed, 'shards': eng.NUM_SHARDS,
        'baseline_offered_tps': offered_tps,
        'realized_generated_tps': offered_real,
        'duration_s': fw.sim_t, 'generated_tx': produced, 'processed_tx': processed,
        'expired_tx': expired, 'pending_tx': pending, 'mass_balance_error': diff,
        'throughput_tps': processed / fw.sim_t,
        'completion_fraction_generated': processed / produced if produced else None,
        'confirmation_latency_ms_transaction_weighted': timing['avg_confirmation_latency_ms'],
        'latency_epoch_cumulative_average_ms': eng.safe_mean(fw.metrics['latency_ms_per_epoch']),
        'mean_rho_reported': eng.safe_mean([x.get('rho', 0) for x in q]),
        'mean_shard_rho_reported': eng.safe_mean([x.get('avg_shard_rho', 0) for x in q]),
        'mean_max_shard_rho_reported': eng.safe_mean([x.get('max_shard_rho', 0) for x in q]),
        'overloaded_shards_mean': eng.safe_mean([x.get('overloaded_shards', 0) for x in q]),
        'mean_active_validators': eng.safe_mean([x.get('c', 0) for x in q]),
        'realtime_success_fraction_model': qos['real_time_success_rate'],
        'energy_total_wh': ewh,
        'energy_per_processed_tx_uwh': ewh / processed * 1e6 if processed else None,
        'energy_boundary': 'whole_network_modeled_all_nodes_including_sleep',
        'device_sensors': int(fw.device_counts.get('sensor', 0)),
        'device_gateway': int(fw.device_counts.get('gateway', 0)),
        'device_edge': int(fw.device_counts.get('edge', 0)),
        'device_cloud': int(fw.device_counts.get('cloud', 0)),
        'attack_window_epochs': f'{fw.attack_campaign.start_epoch}-{fw.attack_campaign.end_epoch}',
    }
    prio = []
    for priority in PRIORITIES:
        prio.append({
            'nodes': nodes, 'run': run_idx, 'seed': seed, 'priority': priority,
            'processed_tx': per[priority],
            'expired_tx': int(t['priority_tx_expired'].get(priority, 0)),
            'mean_latency_ms': timing[f'{priority.lower()}_avg_latency_ms'],
            'p95_latency_ms': timing[f'{priority.lower()}_p95_latency_ms'],
            'p99_latency_ms': timing[f'{priority.lower()}_p99_latency_ms'],
            'source': 'strict-priority simulator; sampled microbatch timings',
        })
    attacks = []
    for attack in ATTACKS:
        attempted = int(fw.attack_campaign.attack_metrics[f'{attack}_attempts'])
        successes = int(fw.attack_campaign.attack_metrics[f'{attack}_success'])
        if successes > attempted:
            raise RuntimeError('Invalid attack counts')
        attacks.append({'nodes':nodes,'run':run_idx,'seed':seed,'attack_type':attack,
                        'attempts':attempted,'successes':successes,
                        'resistance':1-successes/attempted if attempted else None,
                        'supported':True,
                        'definition':'1 - successes / attempts; independent stochastic attack trial in original engine'})
    for attack in UNSUPPORTED:
        attacks.append({'nodes':nodes,'run':run_idx,'seed':seed,'attack_type':attack,
                        'attempts':None,'successes':None,'resistance':None,
                        'supported':False,'definition':'not implemented in integrated engine; do not report a score'})
    return row, prio, attacks


def grouped_summary(rows, group_fields, numeric_fields):
    groups = {}
    for r in rows:
        key = tuple(str(r[k]) for k in group_fields)
        groups.setdefault(key, []).append(r)
    output=[]
    for key, members in sorted(groups.items(), key=lambda item: tuple(int(x) if x.isdigit() else x for x in item[0])):
        summary = dict(zip(group_fields, key)); summary['n_runs'] = len(members)
        for field in numeric_fields:
            nums = []
            for m in members:
                try: value = float(m.get(field, ''))
                except (ValueError, TypeError): continue
                if math.isfinite(value): nums.append(value)
            summary[field+'_mean'] = float(np.mean(nums)) if nums else None
            summary[field+'_sd'] = float(np.std(nums, ddof=1)) if len(nums)>1 else None
            summary[field+'_valid_n'] = len(nums)
        output.append(summary)
    return output


def validate_results(rows, priorities, attacks, scales, runs):
    keys = [(int(x['nodes']),int(x['run'])) for x in rows]
    if len(keys) != len(set(keys)):
        raise RuntimeError('Duplicated node/run records')
    if len(rows) != len(scales)*runs:
        raise RuntimeError(f'Expected {len(scales)*runs} runs; found {len(rows)}')
    for n in scales:
        found = sorted(r for node,r in keys if node==n)
        if found != list(range(1,runs+1)):
            raise RuntimeError(f'Incomplete runs for nodes={n}: {found}')
    if any(int(float(x['mass_balance_error'])) != 0 for x in rows):
        raise RuntimeError('Nonzero transaction accounting discrepancy')
    if len(priorities)!=len(rows)*len(PRIORITIES) or len(attacks)!=len(rows)*(len(ATTACKS)+len(UNSUPPORTED)):
        raise RuntimeError('Incomplete per-priority or per-attack records')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',default='node_scaling_results')
    ap.add_argument('--runs',type=int,default=10)
    ap.add_argument('--nodes',nargs='+',type=int,default=SCALES)
    ap.add_argument('--seed-base',type=int,default=20261108)
    ap.add_argument('--duration',type=float,default=30.0)
    ap.add_argument('--epoch',type=float,default=0.05)
    ap.add_argument('--offered-tps',type=float,default=80000.0)
    ap.add_argument('--shards',type=int,default=10)
    ap.add_argument('--mode',choices=['edge_dominant'],default='edge_dominant')
    ap.add_argument('--resume',action='store_true')
    ap.add_argument('--audit-shard-epochs',action='store_true',help='Export per-shard per-epoch records (larger CSV)')
    args=ap.parse_args()
    if args.runs<1 or args.duration<=0 or args.epoch<=0 or args.offered_tps<=0 or args.shards<1:
        ap.error('Invalid run/epoch/duration/shards/workload')
    if len(set(args.nodes))!=len(args.nodes): ap.error('Duplicate network sizes')
    if any(n<args.shards for n in args.nodes): ap.error('Not enough nodes for specified shards')
    out=Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    source=Path(eng.__file__).resolve()
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()
    cfg={'nodes':args.nodes,'runs':args.runs,'seed_base':args.seed_base,'duration_s':args.duration,
         'epoch_s':args.epoch,'baseline_offered_tps':args.offered_tps,
         'shards':args.shards,'deployment_mode':args.mode,
         'engine_path':str(source.name),'engine_sha256':source_sha256,
         'attack_types_implemented':list(ATTACKS),'unsupported_attack_types':list(UNSUPPORTED),
         'attack_note':'DDoS multiplies arrival rate in the integrated engine. Baseline offered_tps is fixed, but realized traffic is not.',
         'queue_note':'Unstable rho>=1 cannot be analyzed with steady-state Erlang-C; engine has capped/approximate waiting estimates.',
         'energy_note':'Engine estimates energy via activity-based profiles; FAST_MODE uses sampled scaled activity if enabled.',
         'latency_note':'Transaction-weighted microbatch completion time is different from arithmetic mean of per-epoch cumulative latency.',
         'model_warning':'Security attack success model is fixed stochastic Bernoulli trials and not verified defense efficacy.',
         'capacity_audit_version':'2.0; raw per-epoch capacity and batch observation',
         'audit_shard_epochs':args.audit_shard_epochs,
         'MU_SCALE_source':'engine.RealisticValidatorManager.MU_SCALE; recorded in capacity_per_run from instance',
         'device_capacity_tps':{k: v['capacity'] for k,v in eng.DEVICE_PROFILES.items()},
         }
    cfg_path=out/'configuration.json'
    if args.resume and cfg_path.exists():
        old=json.loads(cfg_path.read_text(encoding='utf-8'))
        if {k:v for k,v in old.items() if k!='engine_path'} != {k:v for k,v in cfg.items() if k!='engine_path'}:
            raise RuntimeError('Cannot resume: engine or experiment configuration has changed')
    elif cfg_path.exists():
        raise RuntimeError('Output folder already exists; use --resume or a fresh --out')
    cfg_path.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
    raw=out/'per_run.csv'; pp=out/'priority_per_run.csv'; at=out/'attack_per_run.csv'
    capacity_path=out/'capacity_per_run.csv'; epochs_path=out/'capacity_per_epoch.csv'; shard_path=out/'capacity_per_shard_epoch.csv'
    rows=load_dicts(raw) if args.resume and raw.exists() else []
    priority=load_dicts(pp) if args.resume and pp.exists() else []
    attacks=load_dicts(at) if args.resume and at.exists() else []
    cap_rows=load_dicts(capacity_path) if args.resume and capacity_path.exists() else []
    epoch_all=load_dicts(epochs_path) if args.resume and epochs_path.exists() else []
    shard_all=load_dicts(shard_path) if args.resume and shard_path.exists() and args.audit_shard_epochs else []
    done={(int(r['nodes']),int(r['run'])) for r in rows}
    cap_keys={(int(r['nodes']),int(r['run'])) for r in cap_rows}
    if done != cap_keys:
        raise RuntimeError('Resume refused: per_run and capacity_per_run are not aligned. Restore from backup; do not skip incomplete audit records.')
    eng.NUM_SHARDS=args.shards
    eng.EPOCH_DURATION=args.epoch
    eng.SIMULATION_DURATION=args.duration
    epochs=int(round(args.duration/args.epoch))
    if abs(epochs*args.epoch-args.duration)>1e-8:
        raise RuntimeError('duration must be an exact multiple of epoch')
    for node in args.nodes:
        eng.NUM_NODES=node
        for rep in range(1,args.runs+1):
            if (node,rep) in done:
                print(f'[skip] nodes={node} run={rep}',flush=True);continue
            # Same run index -> identical seed across node counts (paired seeds).
            seed=args.seed_base+rep-1
            random.seed(seed); np.random.seed(seed)
            fw=eng.RealisticHybridConsensusFramework(protocol_mode='proposed',target_tps=args.offered_tps,deployment_mode=args.mode)
            install_batch_audit(fw)
            epoch_rows=[]; shard_rows=[]
            for ei in range(1,epochs+1):
                before_shard=dict(fw.tx.metrics['shard_tx_processed'])
                fw.step_epoch()
                er,sr=extract_capacity_epoch(fw,node,rep,seed,ei,before_shard)
                epoch_rows.append(er)
                if args.audit_shard_epochs: shard_rows.extend(sr)
            row,pr,att=extract_run(fw,node,rep,seed,args.offered_tps)
            caprow={'nodes':node,'run':rep,'seed':seed,**capacity_run_summary(epoch_rows,shard_rows,fw.batch_audit),
                    'MU_SCALE_applied':float(fw.validator_manager.MU_SCALE)}
            if caprow['observed_processed_tx_capacity_audit'] != int(row['processed_tx']):
                raise RuntimeError('Batch/epoch total and original processed total do not agree')
            if caprow['batch_tx_total'] != int(row['processed_tx']):
                raise RuntimeError('Batched tx count does not agree with original processed total')
            if abs(caprow['mean_active_validators_system_capacity_audit']-float(row['mean_active_validators']))>1e-6:
                raise RuntimeError('Active validator reporting does not match per-epoch data')
            rows.append(row);priority.extend(pr);attacks.extend(att);cap_rows.append(caprow)
            epoch_all.extend(epoch_rows)
            if args.audit_shard_epochs: shard_all.extend(shard_rows)
            # Persist each completed run BEFORE doing statistical reporting.
            write_dicts(raw,rows);write_dicts(pp,priority);write_dicts(at,attacks)
            write_dicts(capacity_path,cap_rows);write_dicts(epochs_path,epoch_all)
            if args.audit_shard_epochs: write_dicts(shard_path,shard_all)
            print(f'[saved] nodes={node} run={rep}/{args.runs} processed={row["processed_tx"]} generated={row["generated_tx"]} pending={row["pending_tx"]} expired={row["expired_tx"]}',flush=True)
    validate_results(rows,priority,attacks,args.nodes,args.runs)
    if len(cap_rows)!=len(rows) or len(epoch_all)!=len(rows)*epochs:
        raise RuntimeError('Capacity audit incomplete')
    metrics=['throughput_tps','realized_generated_tps','confirmation_latency_ms_transaction_weighted',
             'mean_rho_reported','mean_max_shard_rho_reported','mean_active_validators',
             'expired_tx','pending_tx','realtime_success_fraction_model','energy_per_processed_tx_uwh',
             'energy_total_wh','completion_fraction_generated']
    write_dicts(out/'table19_summary.csv',grouped_summary(rows,['nodes'],metrics))
    write_dicts(out/'table20_priority_summary.csv',grouped_summary(priority,['nodes','priority'],['mean_latency_ms','p95_latency_ms','processed_tx','expired_tx']))
    write_dicts(out/'table21_energy_summary.csv',grouped_summary(rows,['nodes'],['energy_per_processed_tx_uwh','energy_total_wh','processed_tx']))
    supported=[r for r in attacks if str(r['supported']).lower()=='true']
    # Per-run resistance distribution and attack counts, NOT fabricated unsupported scores.
    write_dicts(out/'table22_supported_attack_summary.csv',grouped_summary(supported,['nodes','attack_type'],['attempts','successes','resistance']))
    write_dicts(out/'table4_capacity_summary.csv',grouped_summary(cap_rows,['nodes'],[
      'mean_active_validators_system_capacity_audit','mean_mu_per_validator_tps_epoch_avg',
      'mean_mu_total_capacity_tps','mean_lambda_total_tps','mean_rho_raw_epoch_avg',
      'rho_ratio_of_time_avg_lambda_and_capacity','mean_epoch_integer_budget_tx',
      'capacity_budget_utilization_processed_over_budget','batch_size_mean_per_call',
      'service_time_ms_transaction_weighted_batch_component','epochs_with_any_overloaded_shard']))
    with open(out/'VALIDATION.txt','w',encoding='utf-8') as f:
        f.write(f'PASSED: {len(rows)} runs; {len(priority)} class rows; {len(attacks)} attack rows; zero transaction balance errors.\n')
        f.write('PASSED: raw epoch capacity ledger and capacity service budget <= observed throughput; batches tracked.\n')
        f.write('WARNING: Synthetic service time is NOT reciprocal of mu. Eq.(6) batch factor is not identifiable as physical parallelism.\n')
        f.write('WARNING: rho>=1 is not steady-state Erlang-C; original engine caps queue prediction.\n')
        f.write('Warning: cannot claim all handling-editor requirements are satisfied. Engine assumptions and other manuscript experiments remain to be audited.\n')
        f.write('Table22: only 4 attack types are simulated; do not report 3 unsupported attack scores.\n')
        f.write('Check 1000-node outputs against Section 5.1 using same seeds and measurement boundaries.\n')
    print('COMPLETED AND VALIDATED:',str(out),flush=True)

if __name__=='__main__':
    main()
