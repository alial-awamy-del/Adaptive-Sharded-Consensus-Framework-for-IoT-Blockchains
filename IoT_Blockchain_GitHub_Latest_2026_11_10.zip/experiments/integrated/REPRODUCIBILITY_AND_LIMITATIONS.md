# Audit scope and transparent limitations

**Scope of V3.** This package runs the original integrated engine unchanged, records service capacity, actual offered load, per-epoch EWMA indicators and classification, per-run energy budget, and attack attempts. It does **not** reproduce different standalone experiments simply by changing their manuscript values.

## Not automatically resolved

1. **Tables 10 and 14:** The original queue and scheduling experimental traces and their per-run load configuration must be supplied. Use `tables10_14_source_manifest_TEMPLATE.csv` and pass a completed source file to `reviewer_report.py --external-provenance PATH`. This establishes provenance, not numerical replication by itself.
2. **6.63 / 76.23 / 8081 µWh/tx:** Only full-network energy is measured by the integrated engine; consensus-only and Smart City energy require their own sources and audited per-activity energy budgets with the same denominator and time base. The 8081/100=80.81 target ratio must be acknowledged with a warning about the boundary difference.
3. **Security:** Attack success is randomly sampled as Bernoulli (nominal 15%, with random multiplier) and is not derived from a specified bypass of a defense mechanism. Resistance therefore must be described as model-internal attack outcome, not validated security robustness. Selfish Mining/Bribery/Long Range are not simulated.
4. **EWMA:** Monitoring composite threat = 0.2 * security_monitor.threat_level() + 0.8 * attack intensity (clamped). EWMA recursion α=.30 and alarm if EWMA>.08. Truth label is predefined attack window. These are not held-out calibrated thresholds or attacker-level ground truth.
5. **Reproducibility:** Providing ZIP and fixed seeds is necessary, but not sufficient for `direct reproducibility` in published literature: deposit the code and files, exact runtime deps, seed lists, and versioned data with DOI/archived URL.
6. **6 ms service time:** Is a scheduler's synthetic per-transaction timing component and cannot be inverted as service throughput. μ is the class-dependent nominal processing rate (tx/s), and batch size is scheduler aggregation, not validated physical parallelism.
7. **Comparison:** The new results will generally differ from older published tables. Never silently combine old baseline values with the newer output.
