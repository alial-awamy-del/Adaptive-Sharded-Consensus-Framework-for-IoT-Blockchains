# تشغيل سيناريوهَي المدينة الذكية بملف واحد

يحتوي `smart_city_both_scenarios.py` على المحرك الأصلي لسيناريو 2.8 مليون جهاز، وتوسعة سيناريو 15 مليون جهاز، وتدقيق الطاقة والحمل والطوابير ومقارنة النتائج مع الورقة. **لا يحتاج إلى أي ملف Python آخر**. يحتاج numpy فقط.

## التشغيل في Google Colab

1. ارفع ملف `smart_city_both_scenarios.py` إلى `/content/`.
2. نفذ:

```python
!python /content/smart_city_both_scenarios.py --scenario both --runs 10 --hours 24 --out /content/smart_city_dual_results --resume
```

ينفذ افتراضيًا سيناريو 2.8M في حالات NONE وDOS وDDOS وSYBIL وMALICIOUS_VALIDATOR وDATA_INJECTION وMIXED (70 تشغيلًا)، وسيناريو 15M مع MIXED (10 تشغيلات)، بإجمالي 80 تشغيلًا مدة كل منها 24 ساعة محاكاة.

للاختبار السريع فقط:

```python
!python /content/smart_city_both_scenarios.py --scenario both --runs 1 --hours 1 --out /content/smart_city_test --resume
```

لتشغيل 15M فقط: `--scenario 15M`. لتشغيل 2.8M فقط: `--scenario 2.8M`.

سيحفظ البرنامج `per_run.csv` و`summary_mean_sd.csv` و`manuscript_comparison.csv` و`CONFIG.json` و`REVIEWER_AUDIT.md` في مجلد النتائج؛ وتُحفظ النتائج تدريجيًا بعد كل تشغيل. استعمال `--resume` مشروط بثبات الإعدادات ونص الكود.

## حدود مهمة

- أرقام المخطوطة مراجع للمقارنة وليست أهدافًا للمعايرة؛ لا ضمان لتطابق النتائج.
- أكواد 15M الأصلية التاريخية غير متاحة؛ السيناريو موسع من محرك 2.8M باستخدام المعلمات المعروفة من المخطوطة.
- الطاقة في المحرك تخص طاقة خمول المدققين النشطين وتكلفة المعاملات النموذجية؛ لا تشمل خمول كامل 2.8 أو 15 مليون جهاز.
- المحرك يقص `rho` عند الازدحام، بينما التدقيق يحفظ `raw rho` ويكشف حالات تجاوز الاستقرار.
- قيم المخرجات محاكاة وليست قياسات من بنية تحتية حقيقية.
