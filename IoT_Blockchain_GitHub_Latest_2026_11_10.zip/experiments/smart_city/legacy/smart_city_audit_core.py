#!/usr/bin/env python3
"""Auditable reproduction of the supplied Smart City Singapore simulator.

Baseline mode preserves the supplied equations and parameters. Corrected mode
changes invalid overloaded-queue mathematical reporting; results must be
reported as a distinct sensitivity experiment, not substituted silently.
"""
import argparse, csv, hashlib, json, math, pathlib, random, sys
from dataclasses import asdict
import numpy as np
import smart_city_original as m

ATTACKS = {"NONE":m.AttackType.NONE,"DOS":m.AttackType.DOS,"DDOS":m.AttackType.DDOS,
           "SYBIL":m.AttackType.SYBIL,"MALICIOUS_VALIDATOR":m.AttackType.MALICIOUS_VALIDATOR,
           "DATA_INJECTION":m.AttackType.DATA_INJECTION,"MIXED":m.AttackType.MIXED}


def safe_json(v):
    if isinstance(v, (np.integer,)): return int(v)
    if isinstance(v, (np.floating,)): return float(v)
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)): return None
    return str(v)


def write_csv(path, rows):
    if not rows: return
    cols=list(dict.fromkeys(k for row in rows for k in row))
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_run(seed, attack_name, hours, mode, device_count=2_800_000, shards=10, pool=1000, max_committee=80):
    sim=m.Simulation(seed=seed, attack_type=ATTACKS[attack_name])
    cfg=sim.cfg
    cfg.TOTAL_IOT_DEVICES=device_count;cfg.NUM_SHARDS=shards
    cfg.TOTAL_VALIDATORS_POOL=pool
    cfg.VALIDATORS_PER_SHARD_MAX=max_committee
    cfg.SIMULATION_HOURS=hours
    # Recreate geometry only when different from published 2.8M/10shards/1000pool.
    if (shards,pool)!=(10,1000):
        sim.queues=[m.MMcQueue(i,cfg) for i in range(shards)]
        sim.drops=[m.DropController(cfg) for _ in range(shards)]
        # Re-seed after discarding the default 1,000-candidate pool, so 15M
        # random draws reproduce a simulation initialized directly at 5,000.
        random.seed(seed); np.random.seed(seed)
        sim.pov=m.PoVEngine(cfg)
        sim.hist={i:{k:[] for k in ('time','arrived','processed','rho','Wq_ms','W_ms','power','committee','malicious')} for i in range(shards)}
    original_step=sim.step
    records=[]
    totals={"validator_idle_kwh":0.,"transaction_processing_kwh":0.,"weighted_tx_energy_kwh":0.,"processed":0,"arrived":0,"dropped":0}
    def instrumented_step():
        idx=len(sim.glob['time'])
        start=sim.time
        original_step()
        h=start/3600
        attack=sim.attack_effects(h)
        pm=attack['power_mult']
        dt=cfg.TIME_STEP
        active=sim.glob['validators'][-1]
        processed=sim.glob['proc'][-1]
        arrivals=sum(sim.hist[i]['arrived'][-1] for i in range(shards))
        dropped=sum(q.dropped_total for q in sim.queues) - (instrumented_step.prev_dropped)
        instrumented_step.prev_dropped+=dropped
        idle=active*cfg.POWER_IDLE_KW*dt/3600*pm
        tx=processed*sim.weighted_device_tx_energy()*pm
        actual=sim.glob['energy'][-1]
        if not math.isclose(idle+tx,actual,rel_tol=1e-9,abs_tol=1e-8):
            raise AssertionError(f'Energy budget mismatch: {idle+tx} vs {actual}')
        totals['validator_idle_kwh']+=idle
        totals['transaction_processing_kwh']+=tx
        totals['processed']+=processed
        totals['arrived']+=arrivals
        totals['dropped']+=dropped
        rows=[]
        for i,q in enumerate(sim.queues):
            raw_rho=q.lam/(q.c*q.mu) if q.c>0 and q.mu>0 else float('inf')
            rows.append((raw_rho,sim.hist[i]['rho'][-1]))
        rr=[r[0] for r in rows]
        overloaded=sum(r>=1 for r in rr)
        clipped=sum(raw>=1 and capped<1 for raw,capped in rows)
        backlog=sum(q.backlog for q in sim.queues)
        records.append(dict(seed=seed,scenario=attack_name,step=idx,hour=h,attack_active=attack['active'],
            attack_arrival_multiplier=attack['arrival_mult'],attack_service_multiplier=attack['service_mult'],
            arrived=arrivals,processed=processed,dropped=dropped,backlog=backlog,
            mean_raw_rho=float(np.mean(rr)),max_raw_rho=float(np.max(rr)),
            overloaded_shards=overloaded,rho_clipped_shards=clipped,
            active_validators=active,energy_kwh=actual,validator_idle_kwh=idle,
            transaction_processing_kwh=tx))
    instrumented_step.prev_dropped=0
    sim.step=instrumented_step
    result=sim.run(verbose=False)
    end_backlog=sum(q.backlog for q in sim.queues)
    # Queue does integer truncation; mismatch, if any, must be disclosed rather than patched.
    balance=totals['arrived']-totals['processed']-totals['dropped']-end_backlog
    if abs(balance)>0: print(f'WARNING: queue accounting gap={balance} for {attack_name} seed={seed}',file=sys.stderr)
    result2={k:float(v) if isinstance(v,(float,np.floating)) else int(v) if isinstance(v,(int,np.integer)) else v for k,v in result.items()}
    energy=result['total_energy_kwh']
    baseline_idle_full_fleet_kwh=sum(device_count*p['fraction']*p['power_idle_kw']*hours for p in m.DEVICE_PROFILES.values())
    # This is a hypothetical, NOT a part of the published energy boundary.
    result2.update(dict(seed=seed,scenario=attack_name,mode=mode,hours=hours,devices=device_count,
            shards=shards,validator_pool=pool,arrived_count=totals['arrived'],processed_count=totals['processed'],
            dropped_count=totals['dropped'],pending_end=end_backlog,accounting_gap=balance,
            modeled_validator_idle_kwh=totals['validator_idle_kwh'],
            modeled_transaction_processing_kwh=totals['transaction_processing_kwh'],
            modeled_total_kwh=energy,
            published_boundary_uwh_per_tx=result['energy_per_tx_wh']*1e6,
            target_uwh_per_tx=100,
            target_multiple=result['energy_per_tx_wh']*1e6/100,
            hypothetical_all_device_idle_kwh=baseline_idle_full_fleet_kwh,
            hypothetical_all_device_idle_plus_model_kwh=baseline_idle_full_fleet_kwh+energy,
            hypothetical_all_device_idle_plus_model_uwh_tx=(baseline_idle_full_fleet_kwh+energy)*1e9/max(totals['processed'],1),
            unmodeled_sensor_gateway_edge_cloud_idle='YES; except active validator idle',
            epochs_overloaded=sum(row['overloaded_shards']>0 for row in records),
            max_raw_rho=max(row['max_raw_rho'] for row in records),
            clipped_shard_epochs=sum(row['rho_clipped_shards'] for row in records),
            base_mu_units='per-validator transactions/second; capacity=sum(validator.capacity)',
            batch_factor='none; no measured batching service multiplier'))
    return result2,records


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',default='/content/smart_city_audit_results')
    p.add_argument('--runs',type=int,default=10)
    p.add_argument('--hours',type=int,default=24)
    p.add_argument('--seed-base',type=int,default=None,help='If omitted, uses the ten manuscript-source seeds [42,123,...,2021]')
    p.add_argument('--scenarios',nargs='+',default=list(ATTACKS),choices=list(ATTACKS))
    p.add_argument('--mode',choices=['legacy'],default='legacy',help='Reproduce original simulator while auditing raw metrics')
    p.add_argument('--resume',action='store_true')
    p.add_argument('--write-epoch',action='store_true',help='Save 10-second time records; large outputs')
    p.add_argument('--devices',type=int,default=2_800_000)
    p.add_argument('--shards',type=int,default=10)
    p.add_argument('--pool',type=int,default=1000)
    p.add_argument('--max-committee',type=int,default=80)
    args=p.parse_args()
    if args.runs<1 or args.hours<1: p.error('runs and hours must be positive')
    if args.shards*5>args.pool or args.shards*args.max_committee>args.pool:
        if args.shards*args.max_committee>args.pool:
            print('WARNING: requested maximum total committee size exceeds pool, saturation possible',file=sys.stderr)
    original_config = args.devices==2_800_000 and args.shards==10 and args.pool==1000 and args.max_committee==80
    if not original_config:
        print('WARNING: exploratory alternative setup, not an exact reproduction of the manuscript settings.',file=sys.stderr)
    folder=pathlib.Path(args.out);folder.mkdir(parents=True,exist_ok=True)
    source=pathlib.Path(m.__file__)
    config=dict(vars(args),source_sha256=sha(source),reproduction_of_paper_2_8m=original_config,
                energy_boundary='active validator idle (0.15kW each) + processed-transaction profile energy; attack-power multiplier',
                excluded='idle power of all 2.8M nonvalidator devices; baseline 6.63 and 76.23 uWh from other simulators',
                overload='legacy code clips rho; raw rho logged separately; Erlang-C invalid for raw rho >=1',
                service='mean reciprocal latency is not interchangeable with nominal per-validator capacity')
    (folder/'CONFIG.json').write_text(json.dumps(config,indent=2,default=safe_json),encoding='utf-8')
    out=folder/'per_run.csv'
    original_seeds=[42,123,456,789,1011,1213,1415,1617,1819,2021]
    if args.seed_base is None and args.runs>len(original_seeds):
        p.error("Original source supplies ten seeds. For >10 runs specify --seed-base.")
    saved=[]
    if args.resume and out.exists():
        with out.open(newline='',encoding='utf-8') as f:saved=list(csv.DictReader(f))
    seen={(r['scenario'],int(r['seed'])) for r in saved}
    rows=saved
    for scenario in args.scenarios:
        for k in range(args.runs):
            seed=original_seeds[k] if args.seed_base is None else args.seed_base+k
            if (scenario,seed) in seen:
                print('SKIP',scenario,seed,flush=True);continue
            row,epochs=audit_run(seed,scenario,args.hours,args.mode,args.devices,args.shards,args.pool,args.max_committee)
            rows.append(row)
            write_csv(out,rows)
            if args.write_epoch:
                write_csv(folder/f'epochs_{scenario}_{seed}.csv',epochs)
            print(f"DONE {scenario} seed={seed} throughput={row['avg_processed_tps']:.2f} tx/s energy={row['published_boundary_uwh_per_tx']:.1f} uWh/tx balance_gap={row['accounting_gap']}",flush=True)
    import collections
    summaries=[]
    for attack in args.scenarios:
        subset=[r for r in rows if r['scenario']==attack]
        if not subset:continue
        fields=['avg_arrival_tps','avg_processed_tps','max_processed_tps','total_energy_kwh',
                'published_boundary_uwh_per_tx','avg_wq_ms','avg_resp_ms','avg_validators',
                'modeled_validator_idle_kwh','modeled_transaction_processing_kwh','target_multiple',
                'pending_end','accounting_gap','clipped_shard_epochs','epochs_overloaded']
        z={'scenario':attack,'n':len(subset)}
        for field in fields:
            vals=np.array([float(r[field]) for r in subset])
            z[field+'_mean']=float(np.mean(vals));z[field+'_sd']=float(np.std(vals,ddof=1)) if len(vals)>1 else float('nan')
        summaries.append(z)
    write_csv(folder/'manuscript_comparison_summary.csv',summaries)
    targets={'NONE':dict(avg_processed_tps=13059.55,total_energy_kwh=9117.63,published_boundary_uwh_per_tx=8081),
             'DOS':dict(avg_processed_tps=13168.34,total_energy_kwh=9217.56,published_boundary_uwh_per_tx=8102),
             'DDOS':dict(avg_processed_tps=13320.57,total_energy_kwh=9387.34,published_boundary_uwh_per_tx=8157),
             'SYBIL':dict(avg_processed_tps=13124.83,total_energy_kwh=9199.20,published_boundary_uwh_per_tx=8112),
             'MALICIOUS_VALIDATOR':dict(avg_processed_tps=13103.07,total_energy_kwh=9195.21,published_boundary_uwh_per_tx=8122),
             'DATA_INJECTION':dict(avg_processed_tps=13211.73,total_energy_kwh=9273.26,published_boundary_uwh_per_tx=8124),
             'MIXED':dict(avg_processed_tps=13233.62,total_energy_kwh=9304.99,published_boundary_uwh_per_tx=8138)}
    cmp=[]
    for r in summaries:
        for field,tgt in targets[r['scenario']].items():
            measured=r[field+'_mean'];cmp.append(dict(scenario=r['scenario'],metric=field,manuscript_value=tgt,
                  reproduced_value=measured,difference=measured-tgt,
                  match_within_paper_rounding=(abs(measured-tgt)< (0.02 if field!='published_boundary_uwh_per_tx' else 0.5))))
    write_csv(folder/'manuscript_value_comparison.csv',cmp)
    notes=['# Reviewer-focused interpretation','',
         'Original 2.8M-device smart-city model: active-validator idle energy + per-processed-transaction profile energy, scaled by stress-case power multiplier.',
         'It does NOT integrate idle-energy draw of all 2.8 million IoT devices.',
         'The 6.63 and 76.23 uWh/tx values belong to separately defined models. Do not identify their boundaries without primary sources.',
         '0.0001 Wh/tx = 100 uWh/tx. The published normal-case 0.008081 Wh/tx is 80.81 times this target. The target is not achieved under the smart-city metric.',
         'Legacy queue clips rho >=1; raw overload is audited. The Erlang-C formula is not valid in an overloaded shard.',
         'The six attack cases represent parameterized workload stressors, NOT attack-success counts or proofs of attack resistance.',
         'Claims of exact replication must be checked in manuscript_value_comparison.csv; do not tune parameters post hoc to force agreement.',
         'The 15M/20-shard original source was not supplied; this runner does not verify its published values.',
         'This run preserves legacy equations while exposing raw overload; fix overloaded queue mathematics in a distinct model study if needed.',
         'Original source SHA-256: '+sha(source)]
    (folder/'REVIEWER_INTERPRETATION.md').write_text('\n'.join(notes)+'\n',encoding='utf-8')
    print('Results:',folder)
if __name__=='__main__':main()
