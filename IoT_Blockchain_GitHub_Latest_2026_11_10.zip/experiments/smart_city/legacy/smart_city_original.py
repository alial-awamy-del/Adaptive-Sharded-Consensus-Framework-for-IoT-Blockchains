# -*- coding: utf-8 -*-
"""
SMART CITY SINGAPORE – Sharded PoV & DRoP (M/M/c)
+ Heterogeneous IoT + Priority Traffic + Attack Window + Markov Trust
+ Attack Types (DoS, DDoS, Sybil, Malicious Validator, Data Injection, Mixed)
---------------------------------------------------------------------
تشغيل متعدد البذور ومقارنة جميع أنواع الهجمات مع تقارير مفصلة لكل نوع
"""

import random, math, numpy as np
from dataclasses import dataclass
from typing import Dict, List
from enum import Enum

# ============================================================
# حالات المرور
# ============================================================
class TrafficState(Enum):
    NORMAL = 1
    PEAK_MORNING = 2
    PEAK_EVENING = 3
    RECOVERY = 4

# ============================================================
# Markov Trust States
# ============================================================
class TrustState(Enum):
    TRUSTED = 1
    NEUTRAL = 2
    RISKY = 3
    MALICIOUS = 4

TRUST_FACTOR = {
    TrustState.TRUSTED: 1.00,
    TrustState.NEUTRAL: 0.70,
    TrustState.RISKY: 0.30,
    TrustState.MALICIOUS: 0.00
}

# ============================================================
# Attack Types
# ============================================================
class AttackType(Enum):
    NONE = 0
    DOS = 1
    DDOS = 2
    SYBIL = 3
    MALICIOUS_VALIDATOR = 4
    DATA_INJECTION = 5
    MIXED = 6

# ============================================================
# Device Profiles
# ============================================================
DEVICE_PROFILES = {
    "sensor": {
        "fraction": 0.60,
        "tx_per_hour": 8,
        "capacity": 10,
        "power_idle_kw": 0.0005,
        "power_tx_kwh": 0.000001,
        "description": "Periodic sensing devices"
    },
    "gateway": {
        "fraction": 0.25,
        "tx_per_hour": 20,
        "capacity": 100,
        "power_idle_kw": 0.015,
        "power_tx_kwh": 0.000005,
        "description": "Local aggregation gateways"
    },
    "edge": {
        "fraction": 0.10,
        "tx_per_hour": 35,
        "capacity": 500,
        "power_idle_kw": 0.08,
        "power_tx_kwh": 0.00001,
        "description": "Edge processing nodes"
    },
    "cloud": {
        "fraction": 0.05,
        "tx_per_hour": 50,
        "capacity": 2000,
        "power_idle_kw": 0.30,
        "power_tx_kwh": 0.00002,
        "description": "Cloud-backed validation proxies"
    }
}

# ============================================================
# الإعدادات
# ============================================================
@dataclass
class Config:
    TOTAL_IOT_DEVICES: int = 2_800_000
    PEAK_HOUR_MULTIPLIER: float = 2.5

    NUM_SHARDS: int = 10
    VALIDATORS_PER_SHARD_MAX: int = 80
    VALIDATORS_PER_SHARD_MIN: int = 5
    TOTAL_VALIDATORS_POOL: int = 1000

    BASE_PROCESSING: float = 50.0
    TIME_STEP: float = 10.0

    ALPHA: float = 0.30
    BETA: float = 0.25
    GAMMA: float = 0.25
    THETA: float = 0.20
    DELTA: float = 0.20

    TARGET_RHO: float = 0.65
    MAX_LATENCY_MS: float = 100.0
    ENERGY_WEIGHT: float = 0.3

    POWER_IDLE_KW: float = 0.15

    MAX_QUEUE_LENGTH: int = 2_000_000
    SIMULATION_HOURS: int = 24

    PEAK_MORNING_START: int = 7
    PEAK_MORNING_END: int = 9
    PEAK_EVENING_START: int = 17
    PEAK_EVENING_END: int = 19
    SURGE_MINUTES: int = 30
    RECOVERY_MINUTES: int = 30

    MALICIOUS_FRACTION: float = 0.3
    MALICIOUS_INIT_SEC: float = 0.1
    MALICIOUS_ACT_PROB: float = 0.05
    DETECTION_PROB: float = 0.9

    PRIORITY_CONFIG = {
        "CRITICAL": {"weight": 0.10, "base_latency_ms": 2.0, "deadline_ms": 100},
        "HIGH":     {"weight": 0.20, "base_latency_ms": 4.0, "deadline_ms": 200},
        "MEDIUM":   {"weight": 0.30, "base_latency_ms": 7.0, "deadline_ms": 500},
        "LOW":      {"weight": 0.40, "base_latency_ms": 10.0, "deadline_ms": 1000},
    }

    ATTACK_START_HOUR: int = 12
    ATTACK_END_HOUR: int = 14

# ============================================================
# TrafficManager
# ============================================================
class TrafficManager:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.state = TrafficState.NORMAL
        self.multiplier = 1.0
        self.state_start = 0.0
        self.morning_active = False
        self.evening_active = False

    def update(self, hour: float) -> float:
        h = hour % 24
        if self.cfg.PEAK_MORNING_START <= h < self.cfg.PEAK_MORNING_END:
            if not self.morning_active:
                self.state = TrafficState.PEAK_MORNING
                self.morning_active = True
                self.state_start = hour
            elapsed = (h - self.cfg.PEAK_MORNING_START) * 60.0
            if elapsed < self.cfg.SURGE_MINUTES:
                prog = elapsed / self.cfg.SURGE_MINUTES
                self.multiplier = 1.0 + (self.cfg.PEAK_HOUR_MULTIPLIER - 1.0) * prog
            else:
                self.multiplier = self.cfg.PEAK_HOUR_MULTIPLIER
        elif self.cfg.PEAK_EVENING_START <= h < self.cfg.PEAK_EVENING_END:
            if not self.evening_active:
                self.state = TrafficState.PEAK_EVENING
                self.evening_active = True
                self.state_start = hour
            elapsed = (h - self.cfg.PEAK_EVENING_START) * 60.0
            if elapsed < self.cfg.SURGE_MINUTES:
                prog = elapsed / self.cfg.SURGE_MINUTES
                self.multiplier = 1.0 + (self.cfg.PEAK_HOUR_MULTIPLIER - 1.0) * prog
            else:
                self.multiplier = self.cfg.PEAK_HOUR_MULTIPLIER
        else:
            if self.state == TrafficState.PEAK_MORNING and h >= self.cfg.PEAK_MORNING_END:
                self.state = TrafficState.RECOVERY
                self.morning_active = False
                self.state_start = hour
            elif self.state == TrafficState.PEAK_EVENING and h >= self.cfg.PEAK_EVENING_END:
                self.state = TrafficState.RECOVERY
                self.evening_active = False
                self.state_start = hour
            if self.state == TrafficState.RECOVERY:
                elapsed = (hour - self.state_start) * 60.0
                if elapsed < self.cfg.RECOVERY_MINUTES:
                    prog = elapsed / self.cfg.RECOVERY_MINUTES
                    self.multiplier = self.cfg.PEAK_HOUR_MULTIPLIER - (self.cfg.PEAK_HOUR_MULTIPLIER - 1.0) * prog
                else:
                    self.state = TrafficState.NORMAL
                    self.multiplier = 1.0
            else:
                self.multiplier = 1.0
        return self.multiplier

# ============================================================
# M/M/c Queue
# ============================================================
class MMcQueue:
    def __init__(self, sid: int, cfg: Config):
        self.id = sid
        self.cfg = cfg
        self.c = cfg.VALIDATORS_PER_SHARD_MIN
        self.mu = cfg.BASE_PROCESSING
        self.lam = 0.0
        self.backlog = 0
        self.processed_total = 0
        self.dropped_total = 0

    def set_capacity_from_committee(self, committee: List):
        if committee:
            cap_list = [v.capacity for v in committee]
            self.mu = np.mean(cap_list) if cap_list else self.cfg.BASE_PROCESSING
            self.c = len(committee)
        else:
            self.mu = self.cfg.BASE_PROCESSING
            self.c = 0

    def update_arrival(self, new_lam: float):
        self.lam = 0.7 * self.lam + 0.3 * new_lam

    def rho(self) -> float:
        if self.c == 0 or self.mu == 0:
            return 0.0
        return min(max(self.lam / (self.c * self.mu), 0.0), 0.999999)

    def erlang_metrics(self) -> dict:
        lam, mu, c = self.lam, self.mu, self.c
        if lam <= 1e-12 or mu <= 0 or c <= 0:
            return {"rho": 0.0, "Wq": 0.0, "Lq": 0.0, "ErlangC": 0.0}
        a = lam / mu
        rho_val = a / c
        if rho_val >= 1.0:
            return {"rho": 0.999999, "Wq": float("inf"), "Lq": float("inf"), "ErlangC": 1.0}
        sum_terms = 0.0
        term = 1.0
        for n in range(c):
            if n > 0:
                term *= a / n
            sum_terms += term
        term_c = term * (a / c)
        last = term_c / (1.0 - rho_val)
        P0 = 1.0 / (sum_terms + last)
        EC = last * P0
        Wq = EC / (c * mu - lam)
        Lq = lam * Wq
        return {"rho": rho_val, "Wq": Wq, "Lq": Lq, "ErlangC": EC}

    def step(self, arrivals: int, dt: float) -> dict:
        before = self.backlog
        capacity = self.c * self.mu * dt
        demand = before + arrivals
        processed = min(demand, capacity)
        remaining = demand - processed
        dropped = 0
        if remaining > self.cfg.MAX_QUEUE_LENGTH:
            dropped = remaining - self.cfg.MAX_QUEUE_LENGTH
            remaining = self.cfg.MAX_QUEUE_LENGTH
        self.backlog = int(max(0, remaining))
        self.processed_total += int(processed)
        self.dropped_total += int(dropped)
        return {
            "arrived": arrivals,
            "processed": int(processed),
            "dropped": int(dropped),
            "backlog": self.backlog
        }

# ============================================================
# Validator (Markov Trust)
# ============================================================
class Validator:
    def __init__(self, vid: int, malicious: bool, cfg: Config):
        self.id = vid
        self.capacity = random.uniform(30, 100)
        self.reputation = random.uniform(50, 100)
        self.security = 1.0 if not malicious else cfg.MALICIOUS_INIT_SEC
        self.misbehavior = 0
        self.malicious = malicious
        self.trust_state = TrustState.TRUSTED if not malicious else TrustState.RISKY
        self.total_tx = 0
        self.energy = 0.0

    def update_trust_state(self, attack_pressure: float, dt_hours: float):
        r = random.random()
        p_t2n = (0.02 + 0.10 * attack_pressure) * dt_hours
        p_n2r = (0.04 + 0.15 * attack_pressure) * dt_hours
        p_n2t = 0.10 * dt_hours
        p_r2m = (0.05 + 0.20 * attack_pressure) * dt_hours
        p_r2n = 0.08 * dt_hours
        p_m2r = 0.02 * dt_hours if attack_pressure < 0.2 else 0.0

        if self.trust_state == TrustState.TRUSTED:
            if r < p_t2n:
                self.trust_state = TrustState.NEUTRAL
        elif self.trust_state == TrustState.NEUTRAL:
            if r < p_n2r:
                self.trust_state = TrustState.RISKY
            elif r > 1.0 - p_n2t:
                self.trust_state = TrustState.TRUSTED
        elif self.trust_state == TrustState.RISKY:
            if r < p_r2m:
                self.trust_state = TrustState.MALICIOUS
            elif r > 1.0 - p_r2n:
                self.trust_state = TrustState.NEUTRAL
        elif self.trust_state == TrustState.MALICIOUS:
            if r < p_m2r:
                self.trust_state = TrustState.RISKY

        if self.trust_state == TrustState.TRUSTED:
            self.reputation = min(100, self.reputation + 0.05)
            self.security = min(1.0, self.security + 0.002)
        elif self.trust_state == TrustState.NEUTRAL:
            self.reputation = max(0, self.reputation - 0.02)
        elif self.trust_state == TrustState.RISKY:
            self.reputation = max(0, self.reputation - 0.10)
            self.security = max(0.1, self.security - 0.005)
        elif self.trust_state == TrustState.MALICIOUS:
            self.reputation = max(0, self.reputation - 0.30)
            self.security = max(0.05, self.security - 0.01)
            self.misbehavior += 1

    def score(self, max_cap: float, cfg: Config) -> float:
        cap_norm = self.capacity / max_cap if max_cap > 0 else 0
        rep_norm = self.reputation / 100.0
        trust_norm = TRUST_FACTOR[self.trust_state]
        return (cfg.ALPHA * cap_norm +
                cfg.BETA * rep_norm +
                cfg.GAMMA * self.security +
                cfg.THETA * trust_norm -
                cfg.DELTA * self.misbehavior)

# ============================================================
# PoV Engine
# ============================================================
class PoVEngine:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.validators: Dict[int, Validator] = {}
        total = cfg.TOTAL_VALIDATORS_POOL
        mal_cnt = int(total * cfg.MALICIOUS_FRACTION)
        for i in range(total):
            self.validators[i] = Validator(i, i < mal_cnt, cfg)

    def select_committees(self, sizes: List[int]) -> List[List[Validator]]:
        max_cap = max(v.capacity for v in self.validators.values())
        sorted_v = sorted(self.validators.values(),
                          key=lambda v: v.score(max_cap, self.cfg),
                          reverse=True)
        committees = []
        idx = 0
        for sz in sizes:
            committees.append(sorted_v[idx:idx+sz])
            idx += sz
        return committees

    def update_behavior(self, attack_pressure: float = 0.0, dt_hours: float = 1/360):
        for v in self.validators.values():
            v.update_trust_state(attack_pressure, dt_hours)
            malicious_prob = self.cfg.MALICIOUS_ACT_PROB * dt_hours
            if v.malicious and random.random() < malicious_prob:
                if random.random() < self.cfg.DETECTION_PROB:
                    v.misbehavior += 1
                    v.reputation = max(0, v.reputation - 10)
                    v.security = max(0.05, v.security - 0.1)
                    v.trust_state = TrustState.MALICIOUS

# ============================================================
# DRoP Controller
# ============================================================
class DropController:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.current = cfg.VALIDATORS_PER_SHARD_MIN

    def decide(self, rho: float, lat_ms: float, power_kw: float) -> int:
        err = rho - self.cfg.TARGET_RHO
        lat_factor = 0.0
        if lat_ms > self.cfg.MAX_LATENCY_MS and not math.isinf(lat_ms):
            lat_factor = (lat_ms - self.cfg.MAX_LATENCY_MS) / 10.0
        energy_factor = 0.0
        max_pow = self.cfg.VALIDATORS_PER_SHARD_MAX * self.cfg.POWER_IDLE_KW * 1.5
        if power_kw > max_pow:
            energy_factor = (max_pow - power_kw) / max_pow
        delta = err * 20.0 + lat_factor + self.cfg.ENERGY_WEIGHT * energy_factor * 10.0
        new_val = self.current + int(round(delta))
        new_val = max(self.cfg.VALIDATORS_PER_SHARD_MIN,
                      min(self.cfg.VALIDATORS_PER_SHARD_MAX, new_val))
        max_step = max(1, int(self.current * 0.15))
        change = new_val - self.current
        change = max(-max_step, min(max_step, change))
        self.current += change
        self.current = max(self.cfg.VALIDATORS_PER_SHARD_MIN,
                           min(self.cfg.VALIDATORS_PER_SHARD_MAX, self.current))
        return self.current

# ============================================================
# Simulation
# ============================================================
class Simulation:
    def __init__(self, seed: int = 42, attack_type: AttackType = AttackType.MIXED):
        random.seed(seed)
        np.random.seed(seed)

        self.cfg = Config()
        self.attack_type = attack_type

        self.queues = [MMcQueue(i, self.cfg) for i in range(self.cfg.NUM_SHARDS)]
        self.drops = [DropController(self.cfg) for _ in range(self.cfg.NUM_SHARDS)]
        self.pov = PoVEngine(self.cfg)
        self.traffic = TrafficManager(self.cfg)
        self.time = 0.0

        self.hist = {i: {'time':[], 'arrived':[], 'processed':[], 'rho':[],
                         'Wq_ms':[], 'W_ms':[], 'power':[], 'committee':[], 'malicious':[]}
                     for i in range(self.cfg.NUM_SHARDS)}
        self.glob = {
            'time': [], 'proc': [], 'energy': [], 'mal': [],
            'arrival_tps': [], 'processed_tps': [], 'validators': []
        }

        self.priority_latency = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": []}
        self.priority_arrived = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}

        self.hourly_stats = []
        self.current_hour_buffer = self._new_hour_buffer()
        self.last_recorded_hour = -1
        self.total_energy_kwh = 0.0

    def _new_hour_buffer(self):
        return {
            'arrived': 0, 'processed': 0, 'dropped': 0,
            'rho': [], 'wq': [], 'resp': [], 'malicious': [],
            'priority_latency': {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": []},
            'attack_active': [],
            'attack_types': [],
            'validators': []
        }

    def weighted_device_tx_energy(self) -> float:
        total_weighted_energy = 0.0
        total_tx_weight = 0.0
        
        for dev_type, profile in DEVICE_PROFILES.items():
            tx_weight = profile["fraction"] * profile["tx_per_hour"]
            total_weighted_energy += tx_weight * profile["power_tx_kwh"]
            total_tx_weight += tx_weight
        
        if total_tx_weight > 0:
            return total_weighted_energy / total_tx_weight
        return 0.0

    def attack_effects(self, hour: float) -> dict:
        if not (self.cfg.ATTACK_START_HOUR <= hour < self.cfg.ATTACK_END_HOUR):
            return {
                "active": False,
                "type": AttackType.NONE,
                "arrival_mult": 1.0,
                "service_mult": 1.0,
                "latency_mult": 1.0,
                "power_mult": 1.0,
                "trust_pressure": 0.0
            }

        attack_type = self.attack_type

        if attack_type == AttackType.DOS:
            return {"active": True, "type": attack_type, "arrival_mult": 1.25, "service_mult": 0.95,
                    "latency_mult": 1.10, "power_mult": 1.05, "trust_pressure": 0.3}
        elif attack_type == AttackType.DDOS:
            return {"active": True, "type": attack_type, "arrival_mult": 1.60, "service_mult": 0.90,
                    "latency_mult": 1.25, "power_mult": 1.15, "trust_pressure": 0.5}
        elif attack_type == AttackType.SYBIL:
            return {"active": True, "type": attack_type, "arrival_mult": 1.15, "service_mult": 0.96,
                    "latency_mult": 1.10, "power_mult": 1.08, "trust_pressure": 0.9}
        elif attack_type == AttackType.MALICIOUS_VALIDATOR:
            return {"active": True, "type": attack_type, "arrival_mult": 1.10, "service_mult": 0.85,
                    "latency_mult": 1.20, "power_mult": 1.10, "trust_pressure": 1.0}
        elif attack_type == AttackType.DATA_INJECTION:
            return {"active": True, "type": attack_type, "arrival_mult": 1.35, "service_mult": 0.94,
                    "latency_mult": 1.18, "power_mult": 1.10, "trust_pressure": 0.6}
        elif attack_type == AttackType.MIXED:
            return {"active": True, "type": attack_type, "arrival_mult": 1.40, "service_mult": 0.88,
                    "latency_mult": 1.20, "power_mult": 1.12, "trust_pressure": 0.8}
        return {"active": False, "type": AttackType.NONE, "arrival_mult": 1.0, "service_mult": 1.0,
                "latency_mult": 1.0, "power_mult": 1.0, "trust_pressure": 0.0}

    def split_by_priority(self, total_arrivals: int) -> dict:
        priorities = list(self.cfg.PRIORITY_CONFIG.keys())
        weights = [self.cfg.PRIORITY_CONFIG[p]["weight"] for p in priorities]
        counts = np.random.multinomial(total_arrivals, weights)
        return {p: int(c) for p, c in zip(priorities, counts)}

    def distribute(self, total: int) -> List[int]:
        probs = [1.0/self.cfg.NUM_SHARDS] * self.cfg.NUM_SHARDS
        return list(np.random.multinomial(total, probs))

    def step(self):
        dt = self.cfg.TIME_STEP
        hour = self.time / 3600.0
        mult = self.traffic.update(hour)
        attack = self.attack_effects(hour)

        expected_tps = 0.0
        for dev_type, profile in DEVICE_PROFILES.items():
            num_devices = self.cfg.TOTAL_IOT_DEVICES * profile["fraction"]
            active_devices = num_devices * random.uniform(0.7, 1.0)
            tx_per_second = profile["tx_per_hour"] / 3600.0
            expected_tps += active_devices * tx_per_second
        expected_tps *= mult
        expected_tps *= attack["arrival_mult"]
        total_arrivals = max(0, np.random.poisson(expected_tps * dt))
        arrival_tps = total_arrivals / dt

        priority_counts = self.split_by_priority(total_arrivals)

        attack_pressure = attack["trust_pressure"]
        self.pov.update_behavior(attack_pressure=attack_pressure, dt_hours=dt/3600.0)

        arrivals_shard = self.distribute(total_arrivals)

        sizes = []
        for i, q in enumerate(self.queues):
            predicted_lam = arrivals_shard[i] / dt if dt > 0 else 0.0
            mu_ref = max(q.mu, self.cfg.BASE_PROCESSING)
            predicted_size = int(math.ceil(predicted_lam / (self.cfg.TARGET_RHO * mu_ref))) if mu_ref > 0 else self.cfg.VALIDATORS_PER_SHARD_MIN

            met = q.erlang_metrics()
            wq_ms = met["Wq"] * 1000.0 if not math.isinf(met["Wq"]) else 1000.0
            power_est = q.c * self.cfg.POWER_IDLE_KW
            drop_size = self.drops[i].decide(q.rho(), wq_ms, power_est)

            sz = max(predicted_size, drop_size)
            sz = max(self.cfg.VALIDATORS_PER_SHARD_MIN,
                     min(self.cfg.VALIDATORS_PER_SHARD_MAX, sz))
            self.drops[i].current = sz
            sizes.append(sz)

        committees = self.pov.select_committees(sizes)
        total_active_validators = sum(len(comm) for comm in committees)
        self.glob['validators'].append(total_active_validators)

        total_processed = 0
        total_dropped = 0
        total_mal = 0

        device_tx_energy = self.weighted_device_tx_energy()

        for i, q in enumerate(self.queues):
            arr = arrivals_shard[i]
            comm = committees[i]
            q.set_capacity_from_committee(comm)
            q.mu *= attack["service_mult"]

            new_lam = arr / dt if dt > 0 else 0.0
            q.update_arrival(new_lam)
            res = q.step(arr, dt)

            if comm:
                total_comm_capacity = sum(v.capacity for v in comm)
                for v in comm:
                    share = v.capacity / total_comm_capacity if total_comm_capacity > 0 else 0
                    tx_v = int(res["processed"] * share)
                    v.total_tx += tx_v
                    v.energy += (
                        self.cfg.POWER_IDLE_KW * dt / 3600.0 +
                        tx_v * device_tx_energy
                    )

            mal_cnt = sum(1 for v in comm if v.malicious or v.trust_state == TrustState.MALICIOUS)
            total_mal += mal_cnt

            met = q.erlang_metrics()
            wq_ms = met["Wq"] * 1000.0 if not math.isinf(met["Wq"]) else 1000.0
            if math.isinf(met["Wq"]) or q.mu <= 0:
                resp_ms = 1000.0
            else:
                resp_ms = (met["Wq"] + 1.0 / q.mu) * 1000.0

            self.hist[i]['time'].append(hour)
            self.hist[i]['arrived'].append(arr)
            self.hist[i]['processed'].append(res["processed"])
            self.hist[i]['rho'].append(met["rho"])
            self.hist[i]['Wq_ms'].append(wq_ms)
            self.hist[i]['W_ms'].append(resp_ms)
            self.hist[i]['power'].append(q.c * self.cfg.POWER_IDLE_KW)
            self.hist[i]['committee'].append(len(comm))
            self.hist[i]['malicious'].append(mal_cnt)

            total_processed += res["processed"]
            total_dropped += res["dropped"]

        processed_tps = total_processed / dt
        total_power_kw = sum(q.c * self.cfg.POWER_IDLE_KW for q in self.queues)

        energy_step = (
            (total_power_kw * dt / 3600.0) +
            (total_processed * device_tx_energy)
        ) * attack["power_mult"]
        self.total_energy_kwh += energy_step

        self.glob['time'].append(hour)
        self.glob['proc'].append(total_processed)
        self.glob['energy'].append(energy_step)
        self.glob['mal'].append(total_mal)
        self.glob['arrival_tps'].append(arrival_tps)
        self.glob['processed_tps'].append(processed_tps)

        self.current_hour_buffer['arrived'] += total_arrivals
        self.current_hour_buffer['processed'] += total_processed
        self.current_hour_buffer['dropped'] += total_dropped
        avg_rho = np.mean([q.rho() for q in self.queues])
        avg_wq = np.mean([self.hist[i]['Wq_ms'][-1] for i in range(self.cfg.NUM_SHARDS)])
        avg_resp = np.mean([self.hist[i]['W_ms'][-1] for i in range(self.cfg.NUM_SHARDS)])
        self.current_hour_buffer['rho'].append(avg_rho)
        self.current_hour_buffer['wq'].append(avg_wq)
        self.current_hour_buffer['resp'].append(avg_resp)
        self.current_hour_buffer['malicious'].append(total_mal)
        self.current_hour_buffer['validators'].append(total_active_validators)
        self.current_hour_buffer['attack_types'].append(attack["type"].name if attack["active"] else "NONE")

        for p, count in priority_counts.items():
            if count > 0:
                base_lat = self.cfg.PRIORITY_CONFIG[p]["base_latency_ms"]
                priority_lat = (avg_wq + base_lat) * attack["latency_mult"]
                self.priority_latency[p].append(priority_lat)
                self.priority_arrived[p] += count
                self.current_hour_buffer['priority_latency'][p].append(priority_lat)

        self.current_hour_buffer['attack_active'].append(attack["active"])

        self.time += dt

        current_hour = int(self.time / 3600)
        if current_hour > self.last_recorded_hour and self.last_recorded_hour >= 0:
            attack_types_in_hour = [t for t in self.current_hour_buffer['attack_types'] if t != "NONE"]
            primary_attack = attack_types_in_hour[0] if attack_types_in_hour else "NONE"
            
            self.hourly_stats.append({
                'hour': self.last_recorded_hour,
                'arrived': self.current_hour_buffer['arrived'],
                'processed': self.current_hour_buffer['processed'],
                'dropped': self.current_hour_buffer['dropped'],
                'avg_rho': np.mean(self.current_hour_buffer['rho']),
                'avg_wq': np.mean(self.current_hour_buffer['wq']),
                'avg_resp': np.mean(self.current_hour_buffer['resp']),
                'critical_latency': np.mean(self.current_hour_buffer['priority_latency']['CRITICAL']) if self.current_hour_buffer['priority_latency']['CRITICAL'] else 0,
                'high_latency': np.mean(self.current_hour_buffer['priority_latency']['HIGH']) if self.current_hour_buffer['priority_latency']['HIGH'] else 0,
                'medium_latency': np.mean(self.current_hour_buffer['priority_latency']['MEDIUM']) if self.current_hour_buffer['priority_latency']['MEDIUM'] else 0,
                'low_latency': np.mean(self.current_hour_buffer['priority_latency']['LOW']) if self.current_hour_buffer['priority_latency']['LOW'] else 0,
                'malicious': int(np.max(self.current_hour_buffer['malicious'])),
                'attack_active': any(self.current_hour_buffer['attack_active']),
                'attack_type': primary_attack,
                'total_validators': int(np.mean(self.current_hour_buffer['validators'])),
                'avg_c_per_shard': np.mean(self.current_hour_buffer['validators']) / self.cfg.NUM_SHARDS
            })
            self.current_hour_buffer = self._new_hour_buffer()
        self.last_recorded_hour = current_hour

    def run(self, verbose=True):
        steps = int(self.cfg.SIMULATION_HOURS * 3600 / self.cfg.TIME_STEP)
        for s in range(steps):
            self.step()
        if self.current_hour_buffer['rho']:
            attack_types_in_hour = [t for t in self.current_hour_buffer['attack_types'] if t != "NONE"]
            primary_attack = attack_types_in_hour[0] if attack_types_in_hour else "NONE"
            
            self.hourly_stats.append({
                'hour': self.last_recorded_hour,
                'arrived': self.current_hour_buffer['arrived'],
                'processed': self.current_hour_buffer['processed'],
                'dropped': self.current_hour_buffer['dropped'],
                'avg_rho': np.mean(self.current_hour_buffer['rho']),
                'avg_wq': np.mean(self.current_hour_buffer['wq']),
                'avg_resp': np.mean(self.current_hour_buffer['resp']),
                'critical_latency': np.mean(self.current_hour_buffer['priority_latency']['CRITICAL']) if self.current_hour_buffer['priority_latency']['CRITICAL'] else 0,
                'high_latency': np.mean(self.current_hour_buffer['priority_latency']['HIGH']) if self.current_hour_buffer['priority_latency']['HIGH'] else 0,
                'medium_latency': np.mean(self.current_hour_buffer['priority_latency']['MEDIUM']) if self.current_hour_buffer['priority_latency']['MEDIUM'] else 0,
                'low_latency': np.mean(self.current_hour_buffer['priority_latency']['LOW']) if self.current_hour_buffer['priority_latency']['LOW'] else 0,
                'malicious': int(np.max(self.current_hour_buffer['malicious'])),
                'attack_active': any(self.current_hour_buffer['attack_active']),
                'attack_type': primary_attack,
                'total_validators': int(np.mean(self.current_hour_buffer['validators'])),
                'avg_c_per_shard': np.mean(self.current_hour_buffer['validators']) / self.cfg.NUM_SHARDS
            })

        if verbose:
            self.print_detailed_report()

        total_processed = sum(self.glob['proc'])
        energy_per_tx_wh = (self.total_energy_kwh * 1000) / total_processed if total_processed > 0 else 0
        rho_exceed = sum(
            1 for i in range(self.cfg.NUM_SHARDS)
            for r in self.hist[i]['rho']
            if r > 0.90
        )
        hourly_validators = [h['total_validators'] for h in self.hourly_stats]
        step_validators = self.glob['validators']

        return {
            'avg_arrival_tps': np.mean(self.glob['arrival_tps']),
            'avg_processed_tps': np.mean(self.glob['processed_tps']),
            'max_arrival_tps': np.max(self.glob['arrival_tps']),
            'max_processed_tps': np.max(self.glob['processed_tps']),
            'total_processed': total_processed,
            'total_energy_kwh': self.total_energy_kwh,
            'energy_per_tx_wh': energy_per_tx_wh,
            'avg_wq_ms': np.mean([v for i in range(self.cfg.NUM_SHARDS) for v in self.hist[i]['Wq_ms']]),
            'avg_resp_ms': np.mean([v for i in range(self.cfg.NUM_SHARDS) for v in self.hist[i]['W_ms']]),
            'avg_malicious': np.mean(self.glob['mal']),
            'max_malicious': max(self.glob['mal']),
            'dropped_total': sum(h['dropped'] for h in self.hourly_stats),
            'rho_exceed': rho_exceed,
            'critical_latency': np.mean(self.priority_latency['CRITICAL']) if self.priority_latency['CRITICAL'] else 0,
            'high_latency': np.mean(self.priority_latency['HIGH']) if self.priority_latency['HIGH'] else 0,
            'medium_latency': np.mean(self.priority_latency['MEDIUM']) if self.priority_latency['MEDIUM'] else 0,
            'low_latency': np.mean(self.priority_latency['LOW']) if self.priority_latency['LOW'] else 0,
            'avg_validators': np.mean(step_validators),
            'max_validators': np.max(step_validators),
            'avg_hourly_validators': np.mean(hourly_validators),
            'max_hourly_avg_validators': np.max(hourly_validators),
            'avg_c_per_shard': np.mean([h['avg_c_per_shard'] for h in self.hourly_stats]) if self.hourly_stats else 0,
            'attack_type_used': self.attack_type.value
        }

    def get_phase(self, hour: int) -> str:
        if 10 <= hour < self.cfg.ATTACK_START_HOUR:
            return "PRE"
        elif self.cfg.ATTACK_START_HOUR <= hour < self.cfg.ATTACK_END_HOUR:
            return "DURING"
        elif self.cfg.ATTACK_END_HOUR <= hour < 16:
            return "POST"
        else:
            return "IGNORE"

    def print_device_deployment_summary(self):
        active_ratio = 0.85

        print("\n📡 IoT Device Deployment, Throughput, and Energy Summary:")
        print("-" * 125)
        print(f"{'Device Type':<12} | {'Fraction':>8} | {'Devices':>14} | {'Tx/hour':>8} | {'Approx Arrival TPS @85%':>22} | {'Tx Energy':>12} | {'Approx Energy/hour':>20}")
        print("-" * 125)

        total_tps = 0.0
        total_energy_kwh_per_hour = 0.0

        for dev_type, profile in DEVICE_PROFILES.items():
            devices = int(self.cfg.TOTAL_IOT_DEVICES * profile["fraction"])
            active_devices = devices * active_ratio
            tx_per_hour_total = active_devices * profile["tx_per_hour"]
            approx_tps = tx_per_hour_total / 3600.0
            tx_energy_wh = profile["power_tx_kwh"] * 1000.0
            energy_kwh_per_hour = tx_per_hour_total * profile["power_tx_kwh"]
            total_tps += approx_tps
            total_energy_kwh_per_hour += energy_kwh_per_hour
            print(f"{dev_type:<12} | {profile['fraction']*100:>7.1f}% | {devices:>14,} | {profile['tx_per_hour']:>8} | {approx_tps:>22,.2f} | {tx_energy_wh:>9.3f} Wh | {energy_kwh_per_hour:>17,.2f} kWh")

        print("-" * 125)
        print(f"{'TOTAL':<12} | {'100.0%':>8} | {self.cfg.TOTAL_IOT_DEVICES:>14,} | {'--':>8} | {total_tps:>22,.2f} | {'--':>12} | {total_energy_kwh_per_hour:>17,.2f} kWh")

    def print_detailed_report(self):
        total_proc = sum(self.glob['proc'])
        total_energy = self.total_energy_kwh
        energy_per_tx_wh = (total_energy * 1000) / total_proc if total_proc > 0 else 0

        all_wq = []
        all_resp = []
        for i in range(self.cfg.NUM_SHARDS):
            all_wq.extend(self.hist[i]['Wq_ms'])
            all_resp.extend(self.hist[i]['W_ms'])
        avg_wq = np.mean(all_wq)
        avg_resp = np.mean(all_resp)
        avg_arrival_tps = np.mean(self.glob['arrival_tps'])
        avg_processed_tps = np.mean(self.glob['processed_tps'])
        max_arrival_tps = np.max(self.glob['arrival_tps'])
        max_processed_tps = np.max(self.glob['processed_tps'])
        avg_mal = np.mean(self.glob['mal'])
        max_mal = max(self.glob['mal'])

        print("\n" + "="*60)
        print("📊 تقرير الأداء النهائي")
        print("="*60)
        print(f"🎯 نوع الهجوم المستخدم: {self.attack_type.name}")
        print("="*60)

        self.print_device_deployment_summary()

        print(f"\n• متوسط معدل الوصول: {avg_arrival_tps:,.2f} TPS")
        print(f"• متوسط معدل المعالجة: {avg_processed_tps:,.2f} TPS")
        print(f"• أقصى معدل وصول: {max_arrival_tps:,.2f} TPS")
        print(f"• أقصى معدل معالجة: {max_processed_tps:,.2f} TPS")
        print(f"• إجمالي المُعالجة: {total_proc:,} tx")
        print(f"• متوسط Wq (انتظار): {avg_wq:.2f} ms")
        print(f"• متوسط Response (W): {avg_resp:.2f} ms")
        print(f"• إجمالي الطاقة: {total_energy:.2f} kWh")
        print(f"• استهلاك الطاقة لكل معاملة: {energy_per_tx_wh:.6f} Wh/tx")
        print(f"• متوسط الخبيثين في اللجان: {avg_mal:.1f} (أقصى {max_mal})")

        if self.hourly_stats:
            print("\n📋 ملخص كل ساعة:")
            print("-"*150)
            print(f"{'ساعة':>4} | {'الوارد':>14} | {'المُعالج':>10} | {'المسقط':>8} | {'ρ':>6} | {'Wq':>6} | {'W':>6} | {'Crit.':>6} | {'High':>6} | {'Med.':>6} | {'Low':>6} | {'خبيثين':>7} | {'مدققين':>8} | {'c/shard':>8} | {'هجوم':>6} | {'نوع الهجوم':>12}")
            print("-"*150)
            for h in self.hourly_stats:
                avg_c_per_shard = h.get('avg_c_per_shard', h['total_validators'] / self.cfg.NUM_SHARDS)
                attack_display = '✅' if h['attack_active'] else '❌'
                attack_type_display = h.get('attack_type', 'NONE')[:10]
                print(f"{h['hour']+1:>4} | {h['arrived']:>14,} | {h['processed']:>10,} | {h['dropped']:>8,} | {h['avg_rho']:>6.3f} | {h['avg_wq']:>6.2f} | {h['avg_resp']:>6.2f} | {h['critical_latency']:>6.2f} | {h['high_latency']:>6.2f} | {h['medium_latency']:>6.2f} | {h['low_latency']:>6.2f} | {h['malicious']:>7} | {h['total_validators']:>8} | {avg_c_per_shard:>8.1f} | {attack_display:>6} | {attack_type_display:>12}")

        print("\n🛡️ هجوم: مقارنة محلية عادلة (Pre:10-12, During:12-14, Post:14-16)")
        phase_data = {"PRE": [], "DURING": [], "POST": []}
        for h in self.hourly_stats:
            phase = self.get_phase(h['hour'])
            if phase in phase_data:
                phase_data[phase].append(h)

        def mean_metric(rows, key):
            return np.mean([r[key] for r in rows]) if rows else 0.0
        def sum_metric(rows, key):
            return np.sum([r[key] for r in rows]) if rows else 0.0
        def phase_summary(rows):
            if not rows:
                return {"arrival_tps":0, "processed_tps":0, "rho":0, "wq":0, "resp":0, "dropped":0, "critical":0, "high":0, "medium":0, "low":0, "validators":0}
            total_arrived = sum_metric(rows, 'arrived')
            total_processed = sum_metric(rows, 'processed')
            total_hours = len(rows)
            return {
                "arrival_tps": total_arrived / (total_hours * 3600),
                "processed_tps": total_processed / (total_hours * 3600),
                "rho": mean_metric(rows, 'avg_rho'),
                "wq": mean_metric(rows, 'avg_wq'),
                "resp": mean_metric(rows, 'avg_resp'),
                "dropped": sum_metric(rows, 'dropped'),
                "critical": mean_metric(rows, 'critical_latency'),
                "high": mean_metric(rows, 'high_latency'),
                "medium": mean_metric(rows, 'medium_latency'),
                "low": mean_metric(rows, 'low_latency'),
                "validators": mean_metric(rows, 'total_validators')
            }

        pre = phase_summary(phase_data["PRE"])
        during = phase_summary(phase_data["DURING"])
        post = phase_summary(phase_data["POST"])

        def pct_change(x, ref):
            return 0.0 if ref == 0 else ((x - ref) / ref) * 100.0

        print(f"{'Metric':<25} | {'Pre-Attack':>12} | {'During':>12} | {'Post':>12} | {'Δ During vs Pre':>15}")
        print("-"*85)
        print(f"{'Arrival TPS':<25} | {pre['arrival_tps']:>12,.2f} | {during['arrival_tps']:>12,.2f} | {post['arrival_tps']:>12,.2f} | {pct_change(during['arrival_tps'], pre['arrival_tps']):>14.2f}%")
        print(f"{'Processed TPS':<25} | {pre['processed_tps']:>12,.2f} | {during['processed_tps']:>12,.2f} | {post['processed_tps']:>12,.2f} | {pct_change(during['processed_tps'], pre['processed_tps']):>14.2f}%")
        print(f"{'Utilization rho':<25} | {pre['rho']:>12.3f} | {during['rho']:>12.3f} | {post['rho']:>12.3f} | {pct_change(during['rho'], pre['rho']):>14.2f}%")
        print(f"{'Wq ms':<25} | {pre['wq']:>12.2f} | {during['wq']:>12.2f} | {post['wq']:>12.2f} | {pct_change(during['wq'], pre['wq']):>14.2f}%")
        print(f"{'Response W ms':<25} | {pre['resp']:>12.2f} | {during['resp']:>12.2f} | {post['resp']:>12.2f} | {pct_change(during['resp'], pre['resp']):>14.2f}%")
        print(f"{'Dropped tx':<25} | {pre['dropped']:>12,.0f} | {during['dropped']:>12,.0f} | {post['dropped']:>12,.0f} | {'--':>15}")
        print(f"{'Critical latency ms':<25} | {pre['critical']:>12.2f} | {during['critical']:>12.2f} | {post['critical']:>12.2f} | {pct_change(during['critical'], pre['critical']):>14.2f}%")
        print(f"{'High latency ms':<25} | {pre['high']:>12.2f} | {during['high']:>12.2f} | {post['high']:>12.2f} | {pct_change(during['high'], pre['high']):>14.2f}%")
        print(f"{'Medium latency ms':<25} | {pre['medium']:>12.2f} | {during['medium']:>12.2f} | {post['medium']:>12.2f} | {pct_change(during['medium'], pre['medium']):>14.2f}%")
        print(f"{'Low latency ms':<25} | {pre['low']:>12.2f} | {during['low']:>12.2f} | {post['low']:>12.2f} | {pct_change(during['low'], pre['low']):>14.2f}%")
        print(f"{'Active Validators':<25} | {pre['validators']:>12.0f} | {during['validators']:>12.0f} | {post['validators']:>12.0f} | {pct_change(during['validators'], pre['validators']):>14.2f}%")

        trust_counts = {"TRUSTED":0, "NEUTRAL":0, "RISKY":0, "MALICIOUS":0}
        for v in self.pov.validators.values():
            trust_counts[v.trust_state.name] += 1
        print("\n🔐 Markov Trust State Distribution:")
        for state, count in trust_counts.items():
            print(f"  {state}: {count}")

        rho_exceed = sum(1 for i in range(self.cfg.NUM_SHARDS) for r in self.hist[i]['rho'] if r > 0.90)
        print(f"\n⚡ تحليل الذروة: أقصى TPS={max_arrival_tps:,.2f}, تجاوز ρ>0.90 = {rho_exceed} مرة")
        print("="*60)

# ============================================================
# تشغيل متعدد البذور لنوع هجوم واحد
# ============================================================
def run_multiple_seeds_for_attack(seeds_list: List[int], attack_type: AttackType, verbose: bool = True):
    results = {}
    
    for seed in seeds_list:
        print(f"\n  Seed {seed}...", end=" ", flush=True)
        sim = Simulation(seed=seed, attack_type=attack_type)
        res = sim.run(verbose=verbose)  # verbose=True لطباعة التقرير الكامل
        for k, v in res.items():
            results.setdefault(k, []).append(v)
        print("✓")
    
    stats = {}
    for k, values in results.items():
        stats[k] = {
            'mean': np.mean(values),
            'std': np.std(values)
        }
    return stats

def print_stats(stats: dict):
    print(f"{'Metric':<35} {'Mean':>15} {'Std':>15}")
    print("-"*70)
    
    attack_map = {0: "NONE", 1: "DOS", 2: "DDOS", 3: "SYBIL", 4: "MALICIOUS_VALIDATOR", 5: "DATA_INJECTION", 6: "MIXED"}
    
    for key, title in labels.items():
        if key in stats:
            s = stats[key]
            if key == 'energy_per_tx_wh':
                print(f"{title:<35} {s['mean']:>15.6f} {s['std']:>15.6f}")
            elif key == 'attack_type_used':
                attack_name = attack_map.get(int(round(s['mean'])), "UNKNOWN")
                print(f"{title:<35} {attack_name:>15} {s['std']:>15.2f}")
            else:
                print(f"{title:<35} {s['mean']:>15.2f} {s['std']:>15.2f}")

labels = {
    'avg_arrival_tps': 'Avg Arrival TPS',
    'avg_processed_tps': 'Avg Processed TPS',
    'max_arrival_tps': 'Max Arrival TPS',
    'max_processed_tps': 'Max Processed TPS',
    'total_processed': 'Total Processed Tx',
    'total_energy_kwh': 'Total Energy (kWh)',
    'energy_per_tx_wh': 'Energy per Tx (Wh/tx)',
    'avg_wq_ms': 'Avg Wq (ms)',
    'avg_resp_ms': 'Avg Response (ms)',
    'avg_malicious': 'Avg Malicious in Committees',
    'max_malicious': 'Max Malicious',
    'dropped_total': 'Total Dropped Tx',
    'rho_exceed': 'ρ > 0.90 Events',
    'critical_latency': 'Critical Latency (ms)',
    'high_latency': 'High Latency (ms)',
    'medium_latency': 'Medium Latency (ms)',
    'low_latency': 'Low Latency (ms)',
    'avg_validators': 'Avg Active Validators (step)',
    'max_validators': 'Max Active Validators (step)',
    'avg_hourly_validators': 'Avg Hourly Validators',
    'max_hourly_avg_validators': 'Max Hourly Avg Validators',
    'avg_c_per_shard': 'Avg c/shard',
    'attack_type_used': 'Attack Type'
}

# ============================================================
# الرئيسي: تشغيل جميع أنواع الهجمات مع تقارير مفصلة
# ============================================================
if __name__ == "__main__":
    seeds = [42, 123, 456, 789, 1011, 1213, 1415, 1617, 1819, 2021]
    
    attack_types = [
        AttackType.DOS,
        AttackType.DDOS,
        AttackType.SYBIL,
        AttackType.MALICIOUS_VALIDATOR,
        AttackType.DATA_INJECTION,
        AttackType.MIXED
    ]
    
    all_results = {}
    
    for attack_type in attack_types:
        print("\n" + "="*90)
        print(f"🎯 Running Scenario: {attack_type.name}")
        print("="*90)
        
        stats = run_multiple_seeds_for_attack(seeds, attack_type, verbose=True)  # verbose=True لطباعة التقرير
        all_results[attack_type.name] = stats
        
        print(f"\n📊 Summary Statistics for {attack_type.name}:")
        print_stats(stats)
        print("\n" + "-"*70)
    
    # طباعة جدول مقارن ملخص لجميع أنواع الهجمات
    print("\n" + "="*90)
    print("📈 COMPARATIVE SUMMARY ACROSS ALL ATTACK TYPES")
    print("="*90)
    
    print(f"\n{'Metric':<30}", end="")
    for at in attack_types:
        print(f"{at.name[:12]:>12}", end="")
    print()
    print("-"*90)
    
    comparison_metrics = ['avg_arrival_tps', 'avg_processed_tps', 'avg_resp_ms', 'total_energy_kwh', 'energy_per_tx_wh']
    
    for metric in comparison_metrics:
        print(f"{labels.get(metric, metric):<30}", end="")
        for at in attack_types:
            if at.name in all_results and metric in all_results[at.name]:
                val = all_results[at.name][metric]['mean']
                if metric == 'energy_per_tx_wh':
                    print(f"{val:>12.6f}", end="")
                else:
                    print(f"{val:>12.2f}", end="")
            else:
                print(f"{'N/A':>12}", end="")
        print()
    
    print("="*90)
    print("\n✅ Simulation completed for all attack types.")