#!/usr/bin/env python3
"""15M IoT-device reproducibility & reviewer audit for manuscript §5.4.3.

Uses supplied 2.8M original engine without tuning and specifies only the
15M configuration parameters explicitly documented in manuscript Table 23.
Does not assert exact reconstruction of missing original 15M simulator.
"""
import argparse, csv, json, pathlib, hashlib, sys
import numpy as np
from smart_city_audit_core import audit_run, write_csv

MANUSCRIPT = {
  'avg_processed_tps': (71825.75,30.0),
  'avg_arrival_tps': (71825.75,30.0),
  'max_processed_tps': (159998.5,1350.0),
  'total_processed_billion': (6.206,0.003),
  'avg_resp_ms': (12.30,0.07),
  'published_boundary_uwh_per_tx': (8219.0,4.0),
  'avg_validators': (1489.4,6.5),
  'max_validators': (3607.8,22.0),
  'avg_c_per_shard': (74.47,0.33),
}
SEEDS = [42,123,456,789,1011,1213,1415,1617,1819,2021]

def load_csv(path):
    if not path.exists(): return []
    with open(path,newline='',encoding='utf-8') as fh: return list(csv.DictReader(fh))

def metrics_summary(rows):
    targets=[]
    for metric,(expected,manuscript_sd) in MANUSCRIPT.items():
        if metric=='total_processed_billion': vals=np.array([float(r['total_processed'])/1e9 for r in rows])
        else: vals=np.array([float(r[metric]) for r in rows])
        actual=float(np.mean(vals)) if len(vals) else float('nan')
        sample_sd=float(np.std(vals,ddof=1)) if len(vals)>1 else float('nan')
        targets.append(dict(metric=metric,manuscript_mean=expected,manuscript_sd=manuscript_sd,
            reproduced_mean=actual,reproduced_sd=sample_sd,difference=actual-expected,
            status='NOT_TESTED' if not len(vals) else 'COMPARE_NOT_FORCE'))
    return targets

def phase_name(hour):
    if 7<=hour<9: return 'MORNING_PEAK'
    if 12<=hour<14: return 'MIXED_ATTACK'
    if 17<=hour<19: return 'EVENING_PEAK'
    if 9<=hour<10 or 19<=hour<20: return 'RECOVERY_AFTER_PEAK'
    if 14<=hour<16: return 'POST_ATTACK'
    return 'OTHER_NORMAL'

def summarise_epochs(rows,seed):
    phase_group={}
    for r in rows:
        phase=phase_name(float(r['hour']))
        phase_group.setdefault(phase,[]).append(r)
    out=[]
    for phase,z in phase_group.items():
        ticks=len(z)
        out.append(dict(seed=seed,phase=phase,epoch_count=ticks,
            mean_arrival_tps=sum(int(v['arrived']) for v in z)/(ticks*10),
            mean_processed_tps=sum(int(v['processed']) for v in z)/(ticks*10),
            mean_active_validators=float(np.mean([float(v['active_validators']) for v in z])),
            mean_raw_shard_rho=float(np.mean([float(v['mean_raw_rho']) for v in z])),
            peak_raw_shard_rho=float(np.max([float(v['max_raw_rho']) for v in z])),
            overloaded_epochs=sum(int(v['overloaded_shards'])>0 for v in z),
            total_energy_kwh=sum(float(v['energy_kwh']) for v in z),
            total_processed=sum(int(v['processed']) for v in z),
            total_arrivals=sum(int(v['arrived']) for v in z)))
    return out

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',default='/content/smart_city_15m_results')
    ap.add_argument('--runs',type=int,default=10)
    ap.add_argument('--hours',type=int,default=24)
    ap.add_argument('--resume',action='store_true')
    ap.add_argument('--save-epoch',action='store_true')
    ap.add_argument('--seed-base',type=int,default=None)
    args=ap.parse_args()
    if not 1<=args.runs<=10 and args.seed_base is None: ap.error('Original source only contains 10 seeds; provide --seed-base for more.')
    if args.runs<1 or args.hours<1 or args.hours>24:ap.error('--runs >=1, --hours from 1 to 24')
    out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True)
    source=pathlib.Path(__file__).with_name('smart_city_original.py')
    config=dict(total_iot_devices=15_000_000,shards=20,validator_candidate_pool=5000,
        min_validators_per_shard=5,max_validators_per_shard=250,
        duration_hours=args.hours,time_step_seconds=10,target_rho=0.65,
        attack_window_hours=[12,14],scenario='MIXED',runs=args.runs,
        original_seeds=SEEDS,seed_base=args.seed_base,
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        provenance='2.8M engine adapted to Table 23 15M configuration; original 15M source missing',
        energy_boundary='active validator idle + per processed transaction device-profile cost, adjusted by attack power multiplier',
        energy_excludes='all unselected sensor/gateway/edge/cloud idle electricity',
        m_m_c_warning='original queue clips rho >=1; raw rho independently audited; Erlang-C not valid if raw rho >=1',
        manuscript_targets_not_calibration=True)
    config_path=out/'CONFIG.json'
    if args.resume and config_path.exists():
        old=json.loads(config_path.read_text(encoding='utf8'))
        for key in ('total_iot_devices','shards','validator_candidate_pool',
                    'min_validators_per_shard','max_validators_per_shard',
                    'duration_hours','scenario','seed_base','source_sha256'):
            if old.get(key)!=config.get(key):
                ap.error(f'Cannot resume with changed parameter {key}. Select a new --out directory.')
    config_path.write_text(json.dumps(config,indent=2),encoding='utf8')
    target=out/'per_run.csv'; rows=load_csv(target) if args.resume else []
    if rows and not args.resume: ap.error('Output exists; use --resume or a new --out folder.')
    done={int(r['seed']) for r in rows}
    phase_rows=load_csv(out/'phase_per_run.csv') if args.resume else []
    print('15M model: 20 shards / 5000 candidates / 5–250 validators per shard / MIXED attack / 24 h',flush=True)
    for i in range(args.runs):
        seed=SEEDS[i] if args.seed_base is None else args.seed_base+i
        if seed in done:
            print('SKIP completed seed',seed,flush=True);continue
        print('START seed',seed,flush=True)
        result,epochs=audit_run(seed,'MIXED',args.hours,'legacy',15_000_000,20,5000,250)
        result['total_processed_billion']=float(result['total_processed'])/1e9
        result['configuration_provenance']='adaptation; not validated exact original 15M source'
        if int(result['accounting_gap'])!=0:
            print('WARNING nonzero balance:',result['accounting_gap'],flush=True)
        rows.append(result)
        write_csv(target,rows)
        phase_rows.extend(summarise_epochs(epochs,seed))
        write_csv(out/'phase_per_run.csv',phase_rows)
        if args.save_epoch:write_csv(out/f'epoch_seed_{seed}.csv',epochs)
        print('DONE seed',seed,'TPS',round(result['avg_processed_tps'],2),
              'Wh/tx',round(result['energy_per_tx_wh'],8),
              'validators',round(result['avg_validators'],2),
              'queue balance',result['accounting_gap'],flush=True)
    write_csv(out/'manuscript_comparison.csv',metrics_summary(rows))
    audit=[
      '# 15M Smart City reviewer audit',
      f'Completed {len(rows)} of {args.runs} runs. Duration: {args.hours} simulated hours per run.',
      'Configuration originates in manuscript Table 23, not in supplied 2.8M source.',
      'Never tune input parameters to force manuscript results.',
      'Compare only 24-hour runs with paper Tables 28/29.',
      'Legacy published energy boundary includes active-validator idle plus weighted per-processed-tx costs, not the idle energy of 15 million devices.',
      'Original queue clips rho and uses special reporting for overload; audit raw rho from epoch data.',
      'A scenario with 5000 validator candidates is not a validated 5000-validator deployment.',
      'No atomic protocol or network-stack execution is modeled.',
      'Section 5.4.3 energy target 0.0001 Wh/tx (100 uWh/tx) vs paper 0.008219 Wh/tx (8219 uWh/tx): 82.19x target; do not claim target achieved.',
      'Manuscript values are reference targets, never constraints on output.',
      'Exact 15M reproducibility cannot be established without historical code and settings.',
    ]
    (out/'REVIEWER_AUDIT.md').write_text('\n'.join(audit)+'\n',encoding='utf8')
    print('Saved:',out,flush=True)

if __name__=='__main__':main()
